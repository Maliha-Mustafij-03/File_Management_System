<?php
// Database connection setup
$conn = new mysqli('localhost', 'root', '', 'edmsdb');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch department and sub-department data based on the IDs from the GET request
$departmentId = $_GET['department_id'];
$subDepartmentId = $_GET['sub_department_id'];

$query = "SELECT * FROM tblnotes WHERE department_id = ? AND sub_department_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('ii', $departmentId, $subDepartmentId);
$stmt->execute();
$result = $stmt->get_result();

$notes = [];
while ($row = $result->fetch_assoc()) {
    $notes[] = $row;
}

// Return the data in a readable format
if (!empty($notes)) {
    foreach ($notes as $note) {
        echo "<div class='note-detail'>";
        echo "<strong>Title:</strong> " . $note['noteTitle'] . "<br>";
        echo "<strong>Description:</strong> " . $note['noteDescription'] . "<br>";
        echo "<strong>File:</strong> <a href='" . $note['filePath'] . "' target='_blank'>View File</a><br>";
        echo "<strong>Date:</strong> " . $note['date'] . "<br>";
        echo "</div><br>";
    }
} else {
    echo "No data found for this department and sub-department.";
}

$conn->close();
?>
