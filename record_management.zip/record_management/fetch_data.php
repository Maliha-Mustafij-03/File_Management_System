<?php
include_once('includes/config.php');
session_start();

if (!isset($_SESSION["edmsid"])) {
    echo "<p class='text-danger'>Unauthorized access.</p>";
    exit;
}

if (isset($_POST['category'])) {
    $category = $_POST['category'];
    $conn = new mysqli('localhost', 'root', '', 'edmsdb');

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $query = "SELECT id, স্মারক_নং, ফাইলের_নাম, এন্ট্রি_তারিখ FROM tbl_records WHERE category='$category'";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        echo "<table class='table table-striped'>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>স্মারক নং</th>
                        <th>ফাইলের নাম</th>
                        <th>এন্ট্রি করার তারিখ</th>
                    </tr>
                </thead>
                <tbody>";

        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>" . $row['id'] . "</td>
                    <td>" . $row['স্মারক_নং'] . "</td>
                    <td>" . $row['ফাইলের_নাম'] . "</td>
                    <td>" . $row['এন্ট্রি_তারিখ'] . "</td>
                </tr>";
        }

        echo "</tbody></table>";
    } else {
        echo "<p class='text-danger'>No records found.</p>";
    }
}
?>
