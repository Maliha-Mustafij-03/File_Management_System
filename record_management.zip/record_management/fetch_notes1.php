<?php
include_once('includes/config.php');

$department_id = $_GET['department_id'] ?? null;
$sub_department_id = $_GET['sub_department_id'] ?? null;
$category = $_GET['category'] ?? null;
$date_filter = $_GET['date_filter'] ?? 'all'; // Default to 'all' if not set

// Check for required parameters
if (!$department_id || !$sub_department_id) {
    echo "<p style='color: red; font-weight: bold; text-align: center;'>Invalid request. Department or Sub-department ID missing.</p>";
    exit;
}

// If no category is selected, fetch distinct note categories for the given department and sub-department
if (!$category) {
    // Adjusted query to fetch category details from tblcategory
    $query = "
        SELECT DISTINCT c.categoryName, c.id 
        FROM tblnotes n
        INNER JOIN tblcategory c ON n.id = c.id 
        WHERE n.department_id = ? AND n.sub_department_id = ?";
    
    $stmt = $con->prepare($query);
    $stmt->bind_param("ii", $department_id, $sub_department_id);
    $stmt->execute();
    $result = $stmt->get_result();
    ?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Notes Categories</title>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f4f4f4;
                margin: 20px;
                text-align: center;
            }

            .container {
                width: 90%;
                margin: auto;
                background: white;
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            }

            h2 {
                color: #2d572c;
            }

            .folder {
                background: linear-gradient(145deg, #ffffff, #f8f8f8);
                color: rgb(18, 98, 27);
                padding: 20px;
                margin: 15px;
                display: inline-block;
                border-radius: 12px;
                cursor: pointer;
                width: 180px;
                height: 120px;
                transition: background-color 0.3s, transform 0.3s, box-shadow 0.3s;
                box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
                position: relative;
            }

            .folder:hover {
                background: linear-gradient(145deg, #f8f8f8, #ffffff);
                transform: scale(1.05);
                box-shadow: 0 12px 30px rgba(0, 0, 0, 0.2);
            }

            .folder:active {
                background-color: #285a32;
                transform: scale(1);
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            }

            .folder-title {
                font-size: 14px;
                text-align: center;
                margin-top: 10px;
                font-weight: bold;
                color: rgb(18, 98, 27);
                letter-spacing: 1px;
            }

            .folder .folder-icon {
                font-size: 20px;
                display: block;
                margin-bottom: 10px;
                text-align: center;
            }
        </style>
    </head>

    <body>
        <div class="container">
            <h2>Note Categories</h2>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <div class="folder" onclick="window.location.href='fetch_notes.php?department_id=<?= $department_id ?>&sub_department_id=<?= $sub_department_id ?>&category=<?= urlencode($row['categoryName']) ?>&category_id=<?= $row['id'] ?>'">
                    <div class="folder-icon"><i class="fas fa-folder"></i></div>
                    <div class="folder-title"><?= htmlspecialchars($row['categoryName']) ?> (ID: <?= $row['id'] ?>)</div>
                </div>
            <?php } ?>
        </div>
    </body>

    </html>
    <?php
    exit;
}

// If category is selected, fetch the notes for that category
$date_condition = "";
if ($date_filter === 'today') {
    $date_condition = "AND DATE(date) = CURDATE()";
} elseif ($date_filter === 'last7days') {
    $date_condition = "AND date >= CURDATE() - INTERVAL 7 DAY";
} elseif ($date_filter === 'next7days') {
    $date_condition = "AND date <= CURDATE() + INTERVAL 7 DAY";
}

$query = "
    SELECT noteTitle, noteDescription, date, filePath 
    FROM tblnotes 
    WHERE department_id = ? 
    AND sub_department_id = ? 
    AND noteCategory = ? 
    $date_condition";
    
$stmt = $con->prepare($query);
$stmt->bind_param("iis", $department_id, $sub_department_id, $category);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notes</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 20px;
            text-align: center;
        }

        .container {
            width: 90%;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #2d572c;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        a.download-link {
            color: #007bff;
            text-decoration: none;
            font-weight: bold;
        }

        a.download-link:hover {
            text-decoration: underline;
        }

        .filter-btn {
            background-color: #007bff;
            color: white;
            padding: 5px 10px;
            border: none;
            cursor: pointer;
        }

        .filter-btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Notes in <?= htmlspecialchars($category) ?></h2>

        <!-- Filter Button -->
        <div class="date-filter-container">
            <label for="filter">Filter by date:</label><br>
            <input type="radio" name="dateFilter" value="today" <?= $date_filter === 'today' ? 'checked' : '' ?>> Today
            <input type="radio" name="dateFilter" value="last7days" <?= $date_filter === 'last7days' ? 'checked' : '' ?>> Last 7 Days
            <input type="radio" name="dateFilter" value="next7days" <?= $date_filter === 'next7days' ? 'checked' : '' ?>> Next 7 Days
            <input type="radio" name="dateFilter" value="all" <?= $date_filter === 'all' ? 'checked' : '' ?>> All Data
            <button class="filter-btn" onclick="applyFilter()">Apply Filter</button>
        </div>

        <!-- Display filtered notes -->
        <?php if ($result->num_rows > 0) { ?>
            <table>
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Date</th>
                        <th>Attachment</th>
                    </tr>
                </thead>
                <tbody id="notesTableBody">
                    <?php while ($row = $result->fetch_assoc()) { ?>
                        <tr>
                            <td><?= htmlspecialchars($row['noteTitle']) ?></td>
                            <td><?= htmlspecialchars($row['noteDescription']) ?></td>
                            <td><?= htmlspecialchars($row['date']) ?></td>
                            <td>
                                <?php if (!empty($row['filePath'])) { ?>
                                    <a class="download-link" href="<?= htmlspecialchars($row['filePath']) ?>" target="_blank">Download</a>
                                <?php } else { ?>
                                    No file
                                <?php } ?>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        <?php } else { ?>
            <p style="color: red; font-weight: bold;">No notes found.</p>
        <?php } ?>

        <!-- Close Button (Now redirects to dashboard.php) -->
        <button class="close-btn" onclick="window.location.href='dashboard.php'">Back to Dashboard</button>
    </div>

    <script>
        function applyFilter() {
            var selectedFilter = document.querySelector("input[name='dateFilter']:checked").value;
            window.location.href = "fetch_notes.php?department_id=<?= $department_id ?>&sub_department_id=<?= $sub_department_id ?>&category=<?= urlencode($category) ?>&date_filter=" + selectedFilter;
        }
    </script>
</body>

</html>

<?php
$stmt->close();
$con->close();
?>
