<?php
include_once('includes/config.php');

if (isset($_GET['department_id'])) {
    $department_id = $_GET['department_id'];

    // Query to fetch sub-departments based on department_id
    $query = mysqli_query($con, "SELECT id, name FROM sub_departments WHERE department_id = '$department_id'");

    // Check if sub-departments exist and output them
    if (mysqli_num_rows($query) > 0) {
        while ($row = mysqli_fetch_assoc($query)) {
            echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
        }
    } else {
        echo "<option value=''>No sub-departments available</option>";
    }
}
?>
