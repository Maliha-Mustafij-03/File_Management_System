<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "edmsdb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables for filters
$department_id = isset($_GET['department_id']) ? $_GET['department_id'] : '';
$sub_department_id = isset($_GET['sub_department_id']) ? $_GET['sub_department_id'] : '';

// SQL query to get department options for dropdown
$department_sql = "SELECT id, name FROM departments";
$department_result = $conn->query($department_sql);

// SQL query to get sub-department options for dropdown
$sub_department_sql = "SELECT id, name FROM sub_departments";
$sub_department_result = $conn->query($sub_department_sql);

// Build the query to fetch filtered notes
$sql = "SELECT n.*, d.name as department_name, s.name as sub_department_name FROM tblnotes n 
        JOIN departments d ON n.department_id = d.id 
        JOIN sub_departments s ON n.sub_department_id = s.id WHERE 1";

// Add department filter if provided
if (!empty($department_id)) {
    $sql .= " AND n.department_id = " . $conn->real_escape_string($department_id);
}

// Add sub-department filter if provided
if (!empty($sub_department_id)) {
    $sql .= " AND n.sub_department_id = " . $conn->real_escape_string($sub_department_id);
}

// Execute the query
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Filter Notes</title>
</head>
<body>

<h2>Filter Notes by Department and Sub-Department</h2>

<form method="get" action="">
    <label for="department_id">Select Department:</label>
    <select name="department_id" id="department_id">
        <option value="">-- Select Department --</option>
        <?php
        // Populate department dropdown
        if ($department_result->num_rows > 0) {
            while ($row = $department_result->fetch_assoc()) {
                $selected = $row['id'] == $department_id ? 'selected' : '';
                echo "<option value='" . $row['id'] . "' $selected>" . $row['name'] . "</option>";
            }
        }
        ?>
    </select>

    <br><br>

    <label for="sub_department_id">Select Sub-Department:</label>
    <select name="sub_department_id" id="sub_department_id">
        <option value="">-- Select Sub-Department --</option>
        <?php
        // Populate sub-department dropdown
        if ($sub_department_result->num_rows > 0) {
            while ($row = $sub_department_result->fetch_assoc()) {
                $selected = $row['id'] == $sub_department_id ? 'selected' : '';
                echo "<option value='" . $row['id'] . "' $selected>" . $row['name'] . "</option>";
            }
        }
        ?>
    </select>

    <br><br>

    <button type="submit">Filter Notes</button>
</form>

<hr>

<?php
// Check if any notes were found and display them
if ($result->num_rows > 0) {
    echo "<h3>Filtered Notes:</h3>";
    while ($row = $result->fetch_assoc()) {
        echo "<div>";
        echo "<strong>Title:</strong> " . htmlspecialchars($row['noteTitle']) . "<br>";
        echo "<strong>Category:</strong> " . htmlspecialchars($row['noteCategory']) . "<br>";
        echo "<strong>Date:</strong> " . htmlspecialchars($row['date']) . "<br>";
        echo "<strong>Department:</strong> " . htmlspecialchars($row['department_name']) . "<br>";
        echo "<strong>Sub-Department:</strong> " . htmlspecialchars($row['sub_department_name']) . "<br>";
        echo "<strong>Description:</strong> " . htmlspecialchars($row['noteDescription']) . "<br>";
        echo "<hr>";
        echo "</div>";
    }
} else {
    echo "No notes found for the selected filters.";
}
?>

</body>
</html>

<?php
// Close the connection
$conn->close();
?>