<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="Professional Web Design" />
    <meta name="author" content="Your Name" />
    <title>রেকর্ড সংগ্রহ</title>
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    <link href="css/styles.css" rel="stylesheet" />
    <style>
        /* Basic Reset */
        body, h1, h2, h3, p, ul {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        /* Global Styles */
        body {
            background-color: #f4f7fc;
            color: #333;
            line-height: 1.6;
        }

        /* Navbar Styles */
        .navbar {
            background-color: #1e3d58;
            padding: 20px;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .navbar a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            padding: 10px 20px;
            margin: 0 15px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .navbar a:hover {
            background-color: #ff6f61;
        }

        /* Main Section */
        .main-container {
            padding: 30px;
            max-width: 1200px;
            margin: auto;
        }

        /* Header Image */
        .header-image {
            width: 100%;
            height: 300px;
            object-fit: cover;
            border-radius: 10px;
            margin-bottom: 30px;
        }

        /* Clock */
        .clock {
            font-size: 2.5rem;
            font-weight: bold;
            color: #ff6f61;
            text-align: center;
            margin-top: 20px;
            animation: pulse 1.5s infinite;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }

        /* Visit Counter Box */
        .visit-counter {
            background-color: #1e3d58;
            color: white;
            font-size: 2rem;
            padding: 20px;
            text-align: center;
            margin-top: 20px;
            border-radius: 10px;
            width: 300px;
            margin-left: auto;
            margin-right: auto;
        }

        /* About Us Section */
        .about-us {
            background-color: #ffffff;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            margin-top: 30px;
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .about-us img {
            width: 200px;
            height: 200px;
            border-radius: 8px;
            object-fit: cover;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .about-us h3 {
            color: #333;
            font-size: 2rem;
            margin-bottom: 10px;
        }

        .about-us p {
            color: #555;
            font-size: 1.2rem;
            line-height: 1.6;
        }

        /* Services Section */
        .services {
            display: flex;
            justify-content: space-around;
            margin-top: 50px;
            text-align: center;
        }

        .service-item {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 25%;
            transition: transform 0.3s ease;
        }

        .service-item:hover {
            transform: scale(1.05);
        }

        .service-item i {
            font-size: 3rem;
            color: #ff6f61;
            margin-bottom: 15px;
        }

        .service-item h4 {
            font-size: 1.5rem;
            color: #333;
        }

        .service-item p {
            font-size: 1.1rem;
            color: #555;
        }

        /* Map Section */
        .map-container {
            margin-top: 40px;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 15px;
        }

        .map-container iframe {
            width: 100%;
            height: 400px;
            border: none;
            border-radius: 8px;
        }

        /* Contact Us Section */
        .contact-form {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-top: 50px;
        }

        .contact-form input, .contact-form textarea {
            width: 100%;
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 1.1rem;
        }

        .contact-form button {
            background-color: #ff6f61;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            font-size: 1.2rem;
            cursor: pointer;
        }

        .contact-form button:hover {
            background-color: #e94e47;
        }

        /* Footer Styles */
        .footer {
            background-color: #1e3d58;
            color: white;
            text-align: center;
            padding: 20px 0;
            position: fixed;
            bottom: 0;
            width: 100%;
            font-size: 1rem;
        }

        /* Testimonial Section */
        .testimonials {
            background-color: #ff6f61;
            color: white;
            padding: 50px;
            margin-top: 50px;
            text-align: center;
        }

        .testimonial-item {
            margin-bottom: 20px;
            font-size: 1.2rem;
        }

        .testimonial-item p {
            font-style: italic;
        }

        /* Button Container for Home, Login, Registration */
        .button-container {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 30px;
        }

        .button-container a {
            background-color: #ff6f61;
            color: white;
            padding: 15px 30px;
            border-radius: 8px;
            font-size: 1.2rem;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .button-container a:hover {
            background-color: #e94e47;
        }
    </style>
</head>
<body>

<!-- Button Container for Home, Login, Registration -->
        <div class="button-container">
            <a href="index.php">হোম পেজ</a>
            <a href="registration.php">রেজিস্ট্রেশন</a>
            <a href="login.php">লগইন</a>
        </div>

    <!-- Main Content -->
    <div class="main-container">
        <!-- Header Image -->
        <img src="assets/img/banner.jpg" class="header-image" alt="Header Image" />

        <!-- Day and Date with Clock -->
        <div class="clock" id="day-date-clock"></div>

        <!-- Visit Counter in Blue Box -->
        <div class="visit-counter">
            <span id="visit-count">Loading...</span> Visits
        </div>

        

        <!-- About Us Section -->
        <div class="about-us">
            <img src="assets/img/pd_sir.jpg" alt="PD Sir" />
            <div>
                <h3>আমাদের সম্পর্কে</h3>
                <p>আমরা একটি উন্নত প্রযুক্তি ব্যবহার করে সহজ, দ্রুত এবং নিরাপদভাবে ডেটা সংরক্ষণ এবং পরিচালনা করার উদ্দেশ্যে কাজ করছি। আমাদের লক্ষ্য হলো ব্যবহারকারীদের জন্য একটি সহজ এবং নির্ভরযোগ্য সিস্টেম তৈরি করা যা তথ্য সংগ্রহ এবং প্রক্রিয়াকরণ সহজ করবে।</p>
            </div>
        </div>

        <!-- Services Section -->
        <div class="services">
            <div class="service-item">
                <i class="fas fa-database"></i>
                <h4>ডেটা স্টোরেজ</h4>
                <p>সুরক্ষিত এবং দ্রুত ডেটা স্টোরেজ সিস্টেম।</p>
            </div>
            <div class="service-item">
                <i class="fas fa-lock"></i>
                <h4>নিরাপত্তা</h4>
                <p>আপনার ডেটা নিরাপদ রাখার জন্য সর্বশেষ প্রযুক্তি ব্যবহৃত।</p>
            </div>
            <div class="service-item">
                <i class="fas fa-cogs"></i>
                <h4>স্বয়ংক্রিয় প্রক্রিয়া</h4>
                <p>স্বয়ংক্রিয় সিস্টেম যা দ্রুত এবং সহজে কাজ সম্পাদন করে।</p>
            </div>
        </div>

        <!-- Map Section -->
        <div class="map-container">
            <h3>আমাদের অবস্থান</h3>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3651.7520719446736!2d90.36935771541866!3d23.810570794736174!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755c758f22d53bf%3A0x14a20960250327ab!2sElection%20Commission%2C%20Agargaon%2C%20Dhaka%2C%20Bangladesh!5e0!3m2!1sen!2sus!4v1674704307882!5m2!1sen!2sus" width="100%" height="400" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
        </div>

        <!-- Testimonials Section -->
        <div class="testimonials">
            <h3>মন্তব্য</h3>
            <div class="testimonial-item">
                <p>"এই সিস্টেমটি ব্যবহার করা খুবই সহজ এবং দক্ষ!"</p>
            </div>
            <div class="testimonial-item">
                <p>"আমার কাজের গতি অনেক বেড়ে গেছে এই প্রযুক্তির কারণে।"</p>
            </div>
        </div>

    </div>

    <!-- Footer -->
    <div class="footer">
        <p>© 2025 Digital File System | সব অধিকার সংরক্ষিত</p>
    </div>

    <!-- JavaScript for Clock, Day/Date, and Counter -->
    <script>
        function updateClock() {
            const now = new Date();
            const hours = now.getHours().toString().padStart(2, '0');
            const minutes = now.getMinutes().toString().padStart(2, '0');
            const seconds = now.getSeconds().toString().padStart(2, '0');
            const day = now.toLocaleString('bn-BD', { weekday: 'long' });
            const date = now.toLocaleDateString('bn-BD');

            document.getElementById('day-date-clock').textContent = `${day}, ${date} - ${hours}:${minutes}:${seconds}`;
        }

        setInterval(updateClock, 1000);
        updateClock(); // Initial call to display clock and date

        // Visitor Counter
        function updateVisitorCount() {
            let count = localStorage.getItem('visitCount') || 0;
            count = parseInt(count) + 1;
            localStorage.setItem('visitCount', count);
            document.getElementById('visit-count').textContent = count;
        }

        updateVisitorCount(); // Update visit count on page load
    </script>

</body>
</html>
