<?php
session_start();
include_once('includes/config.php');
if(strlen($_SESSION["department_id"])==0 || strlen($_SESSION["sub_department_id"])==0) {
    header('location:logout.php');
} else {

    // For updating the note
    if(isset($_POST['submit'])) {
        $nid = $_GET['noteid'];
        $department_id = $_SESSION["department_id"];
        $sub_department_id = $_SESSION["sub_department_id"];
        $noteTitle = $_POST['noteTitle'];
        $noteCategory = $_POST['noteCategory'];
        $noteDescription = $_POST['noteDescription'];
        $remark = $_POST['remark'];

        // Updating the note in tblnotes
        $updateQuery = "UPDATE tblnotes SET noteTitle='$noteTitle', noteCategory='$noteCategory', noteDescription='$noteDescription' WHERE id='$nid' AND department_id='$department_id' AND sub_department_id='$sub_department_id'";
        mysqli_query($con, $updateQuery);

        // Insert the remark into tblnoteshistory (create new record for the remark)
        mysqli_query($con, "INSERT INTO tblnoteshistory(noteId, department_id, sub_department_id, noteDetails) VALUES('$nid', '$department_id', '$sub_department_id', '$remark')");

        echo "<script>alert('নোট সফলভাবে আপডেট হয়েছে।');</script>";
        echo "<script>window.location.href='manage-notes.php'</script>";
    }

    // For deleting the note history (remark)
    if($_GET['del']) {
        $nid = $_GET['nhid'];
        $department_id = $_SESSION["department_id"];
        $sub_department_id = $_SESSION["sub_department_id"];
        mysqli_query($con, "DELETE FROM tblnoteshistory WHERE id ='$nid' AND department_id='$department_id' AND sub_department_id='$sub_department_id'");
        echo "<script>alert('তথ্য মুছে গেছে।');</script>";
        echo "<script>window.location.href='manage-notes.php'</script>";
    }

    // For updating a remark
    if(isset($_POST['update_remark'])) {
        $remark_id = $_POST['remark_id'];
        $updated_remark = $_POST['updated_remark'];
        
        // Update the remark in tblnoteshistory
        mysqli_query($con, "UPDATE tblnoteshistory SET noteDetails='$updated_remark' WHERE id='$remark_id'");

        echo "<script>alert('মন্তব্য সফলভাবে আপডেট হয়েছে।');</script>";
        echo "<script>window.location.href='view-note.php?noteid=" . $_GET['noteid'] . "'</script>";
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>ই-ডাটা</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>

    <style>
        /* Colorful Styling */
        body {
            background-color: #f0f8ff;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .breadcrumb-item a {
            color: #007bff;
        }
        .breadcrumb-item.active {
            color: #ff6347;
        }
        .card-header {
            background: linear-gradient(90deg, #00c6ff 0%, #0072ff 100%);
            color: white;
            font-size: 20px;
            font-weight: bold;
            border-radius: 10px 10px 0 0;
        }
        .card-body {
            background-color: #f7f7f7;
            padding: 2rem;
            border-radius: 0 0 10px 10px;
        }
        .btn-primary {
            background: linear-gradient(90deg, #56ccf2 0%, #2f80ed 100%);
            border-color: #2f80ed;
            font-weight: bold;
        }
        .btn-primary:hover {
            background: linear-gradient(90deg, #00b4d8 0%, #2f80ed 100%);
            border-color: #1f69c1;
        }
        .btn-danger {
            background-color: #ff4d4d;
            border-color: #ff4d4d;
            font-weight: bold;
        }
        .btn-danger:hover {
            background-color: #ff1a1a;
            border-color: #ff1a1a;
        }
        .table th {
            background-color: #ffecb3;
            color: #333;
        }
        .table td {
            background-color: #ffffff;
            color: #333;
        }
        .modal-content {
            background: #f9f9f9;
            border-radius: 10px;
        }
        .modal-header {
            background-color: #2f80ed;
            color: white;
        }
        .modal-footer button {
            border-radius: 5px;
        }
    </style>
</head>
<body class="sb-nav-fixed">
    <?php include_once('includes/header.php'); ?>
    <div id="layoutSidenav">
        <?php include_once('includes/leftbar.php'); ?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">নোট আপডেট</h1>
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item"><a href="index.html">ড্যাশবোর্ড</a></li>
                        <li class="breadcrumb-item"><a href="manage-notes.php">নোট পরিচালনা</a></li>
                        <li class="breadcrumb-item active">নোট আপডেট</li>
                    </ol>
                    <div class="card mb-4">
                        <div class="card-header">
                            <i class="fas fa-edit me-1"></i> নোট আপডেট করুন
                        </div>
                        <div class="card-body">
                            <?php 
                            $department_id = $_SESSION["department_id"];
                            $sub_department_id = $_SESSION["sub_department_id"];
                            $nid = $_GET['noteid'];
                            $query = mysqli_query($con, "SELECT * FROM tblnotes WHERE department_id='$department_id' AND sub_department_id='$sub_department_id' AND id='$nid'");
                            while($row = mysqli_fetch_array($query)) {
                            ?>  
                            <form method="post" name="editNote" enctype="multipart/form-data">
                                <div class="mb-3">
                                    <label for="noteTitle" class="form-label">স্মারক নং</label>
                                    <input type="text" class="form-control" id="noteTitle" name="noteTitle" value="<?php echo htmlentities($row['noteTitle']); ?>" required>
                                </div>

                                <div class="mb-3">
                                    <label for="noteCategory" class="form-label">ফাইলের নাম</label>
                                    <input type="text" class="form-control" id="noteCategory" name="noteCategory" value="<?php echo htmlentities($row['noteCategory']); ?>" required>
                                </div>

                                <div class="mb-3">
                                    <label for="noteDescription" class="form-label">বিষয়</label>
                                    <textarea class="form-control" id="noteDescription" name="noteDescription" rows="3" required><?php echo htmlentities($row['noteDescription']); ?></textarea>
                                </div>

                                <!-- Fetch the most recent remark from tblnoteshistory -->
                                <?php
                                    // Fetch the latest remark for this note
                                    $remarkQuery = mysqli_query($con, "SELECT * FROM tblnoteshistory WHERE noteId='$nid' AND department_id='$department_id' AND sub_department_id='$sub_department_id' ORDER BY postingDate DESC LIMIT 1");
                                    $remarkData = mysqli_fetch_array($remarkQuery);
                                    $latestRemark = $remarkData ? $remarkData['noteDetails'] : ''; // If no remark found, set it to empty
                                ?>
                                <div class="mb-3">
                                    <label for="remark" class="form-label">আপনার মন্তব্য</label>
                                    <textarea class="form-control" id="remark" name="remark" rows="3" required><?php echo htmlentities($latestRemark); ?></textarea>
                                </div>

                                <div class="mb-3">
                                    <label for="noteFile" class="form-label">ফাইল আপলোড করুন</label>
                                    <input type="file" class="form-control" id="noteFile" name="noteFile">
                                    <?php if($row['filePath'] != "") { ?>
                                        <div class="mt-2">
                                            <strong>Uploaded File:</strong> <a href="<?php echo htmlentities($row['filePath']); ?>" target="_blank">Download File</a>
                                        </div>
                                    <?php } ?>
                                </div>

                                <button type="submit" class="btn btn-primary" name="submit">সংরক্ষন</button>
                            </form>
                            <?php } ?>

                            <h5 class="mt-4">আগের মন্তব্যসমূহ</h5>
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>মন্তব্য</th>
                                        <th>তারিখ</th>
                                        <th>অ্যাকশন</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    // Fetch all previous remarks for the note
                                    $ret = mysqli_query($con, "SELECT * FROM tblnoteshistory WHERE noteId='$nid' AND department_id='$department_id' AND sub_department_id='$sub_department_id'");
                                    while($history = mysqli_fetch_array($ret)) {
                                    ?>
                                    <tr>
                                        <td><?php echo htmlentities($history['noteDetails']); ?></td>
                                        <td><?php echo htmlentities($history['postingDate']); ?></td>
                                        <td>
                                            <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editModal" data-remark-id="<?php echo $history['id']; ?>" data-remark-details="<?php echo htmlentities($history['noteDetails']); ?>">এডিট করুন</button>
                                        </td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>

            <!-- Modal for editing remark -->
            <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <form method="post">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="editModalLabel">মন্তব্য এডিট করুন</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <input type="hidden" id="remark_id" name="remark_id">
                                <textarea class="form-control" id="updated_remark" name="updated_remark" rows="5" required></textarea>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">বন্ধ</button>
                                <button type="submit" class="btn btn-primary" name="update_remark">আপডেট করুন</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <?php include_once('includes/footer.php'); ?>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>

    <script>
        // This script will pre-populate the modal with the remark data when "Edit" button is clicked
        const editModal = document.getElementById('editModal');
        editModal.addEventListener('show.bs.modal', function(event) {
            const button = event.relatedTarget;
            const remarkId = button.getAttribute('data-remark-id');
            const remarkDetails = button.getAttribute('data-remark-details');
            
            // Populate the modal fields
            document.getElementById('remark_id').value = remarkId;
            document.getElementById('updated_remark').value = remarkDetails;
        });
    </script>
</body>
</html>
<?php } ?>
