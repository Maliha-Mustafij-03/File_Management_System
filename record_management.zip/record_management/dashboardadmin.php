<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'edmsdb');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch departments
$departmentQuery = "SELECT id, name FROM departments";
$departmentResult = $conn->query($departmentQuery);

// Handle Search
$searchQuery = "";
if (isset($_GET['search'])) {
    $searchTerm = $_GET['search'];
    $searchQuery = "WHERE noteCategory LIKE '%$searchTerm%' OR noteTitle LIKE '%$searchTerm%' OR noteDescription LIKE '%$searchTerm%'";
}

// Fetch filtered notes
$notesQuery = "SELECT * FROM tblnotes $searchQuery";
if (isset($_GET['sub_department_id'])) {
    $sub_department_id = $_GET['sub_department_id'];
    $notesQuery .= " AND sub_department_id = $sub_department_id";
}
$notesResult = $conn->query($notesQuery);

// Handle Deletion
if (isset($_GET['delete_note'])) {
    $note_id = $_GET['delete_note'];

    // Delete note query
    $deleteQuery = "DELETE FROM tblnotes WHERE id = $note_id";
    if ($conn->query($deleteQuery) === TRUE) {
        echo "<script>alert('Note deleted successfully.'); window.location.href = window.location.pathname;</script>";
    } else {
        echo "<script>alert('Error deleting note.');</script>";
    }
}

// Close connection
$conn->close();
?>

<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: 'Poppins', sans-serif;
        background-color: #f4f7fa;
        color: #333;
        padding: 20px;
    }

    .container {
        width: 80%;
        margin: 0 auto;
        background-color: #fff;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 12px 24px rgba(0, 0, 0, 0.1);
        background: linear-gradient(145deg, #ffffff, #f3f3f3);
    }

    h1 {
        text-align: center;
        font-size: 2.5rem;
        margin-bottom: 20px;
        color: #333;
        text-transform: uppercase;
        font-weight: 700;
    }

    h2 {
        margin-top: 40px;
        font-size: 1.75rem;
        color: #0066cc;
        text-transform: uppercase;
        margin-bottom: 10px;
    }

    form {
        margin-bottom: 30px;
        display: flex;
        flex-direction: column;
        gap: 20px;
    }

    .form-group {
        margin-bottom: 20px;
    }

    label {
        font-size: 1.2rem;
        font-weight: 600;
        display: block;
        margin-bottom: 10px;
        color: #333;
    }

    .department-buttons,
    .sub-department-buttons {
        display: flex;
        flex-wrap: wrap;
        gap: 15px;
    }

    .department-button,
    .sub-department-button {
        padding: 12px 24px;
        background-color: #0066cc;
        color: white;
        border: none;
        font-size: 1.1rem;
        border-radius: 6px;
        cursor: pointer;
        transition: background-color 0.3s, transform 0.2s;
    }

    .department-button:hover,
    .sub-department-button:hover {
        background-color: #005bb5;
        transform: scale(1.05);
    }

    .department-button:active,
    .sub-department-button:active {
        transform: scale(0.95);
    }

    .btn-primary {
        background-color: #0066cc;
        border: none;
        color: white;
        font-size: 1.2rem;
        padding: 10px 20px;
        border-radius: 8px;
        transition: background-color 0.3s;
    }

    .btn-primary:hover {
        background-color: #005bb5;
    }

    table.table {
        width: 100%;
        margin-top: 30px;
        border-collapse: collapse;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
    }

    table.table th,
    table.table td {
        padding: 15px;
        text-align: left;
        border-bottom: 1px solid #ddd;
        font-size: 1.1rem;
    }

    table.table th {
        background-color: #0066cc;
        color: white;
        font-weight: bold;
    }

    table.table tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    table.table tr:hover {
        background-color: #f1f1f1;
    }

    .no-notes {
        text-align: center;
        font-size: 1.2rem;
        color: #666;
    }

    .search-bar {
        padding: 16px 30px;
        width: 70%;
        font-size: 1.4rem;
        border-radius: 6px;
        border: 1px solid #ddd;
        outline: none;
        transition: all 0.3s ease;
    }

    .search-bar:focus {
        border-color: #0066cc;
        box-shadow: 0 0 8px rgba(0, 102, 204, 0.5);
    }

    .search-btn {
        padding: 16px 30px;
        background-color: #0066cc;
        color: white;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-size: 1.5rem;
        font-weight: bold;
        transition: all 0.3s ease;
        margin-left: 15px;
    }

    .search-btn:hover {
        background-color: #005bb5;
        transform: scale(1.05);
    }

    .search-btn:active {
        transform: scale(0.95);
    }

    .action-buttons {
        display: flex;
        gap: 15px;
    }

    .view-note-btn {
        background-color: #28a745;
        color: white;
        border: none;
        padding: 12px 24px;
        border-radius: 6px;
        font-size: 1.2rem;
        font-weight: bold;
        transition: all 0.3s ease;
    }

    .view-note-btn:hover {
        background-color: #218838;
        transform: scale(1.05);
    }

    .view-note-btn:active {
        transform: scale(0.95);
    }

    .delete-btn {
        background-color: #dc3545;
        color: white;
        border: none;
        padding: 12px 24px;
        border-radius: 6px;
        font-size: 1.2rem;
        font-weight: bold;
        transition: all 0.3s ease;
    }

    .delete-btn:hover {
        background-color: #c82333;
        transform: scale(1.05);
    }

    .delete-btn:active {
        transform: scale(0.95);
    }
</style>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Department and Sub-Department Filter</title>
</head>

<body>
    <div class="container">
        <h1>Filter Notes by Department and Sub-Department</h1>

        <!-- Department and Sub-Department Selection Form -->
        <form method="GET" id="filterForm">
            <!-- Search Bar -->
            <div style="display: flex; justify-content: space-between;">
                <input type="text" name="search" class="search-bar" placeholder="Search by Category, Title or Description..." value="<?php echo isset($searchTerm) ? $searchTerm : ''; ?>">
                <button type="submit" class="search-btn">Search</button>
            </div>

            <!-- Department Buttons -->
            <div class="form-group">
                <label for="department_id">Department:</label>
                <div class="department-buttons">
                    <?php
                    while ($department = $departmentResult->fetch_assoc()) {
                        echo "<button type='button' class='department-button' data-department-id='" . $department['id'] . "'>" . $department['name'] . "</button>";
                    }
                    ?>
                </div>
            </div>

            <!-- Sub-Department Buttons (Initially hidden) -->
            <div class="form-group" id="sub-department-group" style="display: none;">
                <label for="sub_department_id">Sub-Department:</label>
                <div class="sub-department-buttons" id="sub-department-buttons">
                    <!-- Sub-department buttons will be populated here -->
                </div>
            </div>

            <button type="submit" class="btn btn-primary">Filter Notes</button>
        </form>

        <!-- Display Filtered Notes -->
        <h2>Filtered Notes:</h2>
        <?php
        if ($notesResult && $notesResult->num_rows > 0) {
            echo "<table class='table'>
                    <thead>
                        <tr>
                            <th>Note ID</th>
                            <th>Category</th>
                            <th>Title</th>
                            <th>Date</th>
                            <th>Description</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>";

            while ($note = $notesResult->fetch_assoc()) {
                echo "<tr>
                        <td>" . $note['id'] . "</td>
                        <td>" . $note['noteCategory'] . "</td>
                        <td>" . $note['noteTitle'] . "</td>
                        <td>" . $note['date'] . "</td>
                        <td>" . nl2br($note['noteDescription']) . "</td>
                        <td class='action-buttons'>
                            <a href='view-note.php?noteid=" . $note['id'] . "' class='view-note-btn'>View Note</a>
                            <a href='?delete_note=" . $note['id'] . "' class='delete-btn' onclick='return confirm(\"Are you sure you want to delete this note?\")'>Delete</a>
                        </td>
                      </tr>";
            }

            echo "</tbody></table>";
        } else {
            echo "<p class='no-notes'>No notes found for the selected criteria.</p>";
        }
        ?>
    </div>

    <!-- jQuery and AJAX script -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        // Fetch sub-departments based on department selection
        $('.department-button').click(function () {
            var department_id = $(this).data('department-id');
            $('#sub-department-buttons').empty(); // Clear any previous sub-department buttons
            $('#sub-department-group').show(); // Show sub-department buttons

            $.ajax({
                url: 'fetch_subdepartments.php',
                type: 'GET',
                data: { department_id: department_id },
                success: function (response) {
                    var subDepartments = JSON.parse(response);

                    if (subDepartments.length === 0) {
                        $('#sub-department-buttons').append('<p>No sub-departments available</p>');
                    } else {
                        subDepartments.forEach(function (subDepartment) {
                            $('#sub-department-buttons').append('<button type="button" class="sub-department-button" data-sub-department-id="' + subDepartment.id + '">' + subDepartment.name + '</button>');
                        });
                    }
                }
            });
        });

        // Handle sub-department button click
        $(document).on('click', '.sub-department-button', function () {
            var sub_department_id = $(this).data('sub-department-id');
            // Set the sub-department ID as a GET parameter
            window.location.href = '?sub_department_id=' + sub_department_id;
        });
    </script>
</body>

</html>
