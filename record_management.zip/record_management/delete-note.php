<?php
session_start();
include_once('includes/config.php');

// Redirect if session is not set
if (strlen($_SESSION["edmsid"]) == 0) {
    header('location:logout.php');
    exit;
}

// Ensure the note ID is passed
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $note_id = $_GET['id']; // Get the note ID to delete
    $department_id = $_SESSION['department_id']; // Get department from session
    $sub_department_id = $_SESSION['sub_department_id']; // Get sub-department from session

    // Check if the note belongs to the current department and sub-department
    $checkQuery = "SELECT * FROM tblnotes WHERE id = '$note_id' AND department_id = '$department_id' AND sub_department_id = '$sub_department_id'";
    $result = mysqli_query($con, $checkQuery);

    if (mysqli_num_rows($result) > 0) {
        // If note exists, delete it
        $deleteQuery = "DELETE FROM tblnotes WHERE id = '$note_id' AND department_id = '$department_id' AND sub_department_id = '$sub_department_id'";
        
        if (mysqli_query($con, $deleteQuery)) {
            // Deleting associated history
            $deleteHistoryQuery = "DELETE FROM tblnoteshistory WHERE noteId = '$note_id' AND department_id = '$department_id' AND sub_department_id = '$sub_department_id'";
            mysqli_query($con, $deleteHistoryQuery);

            echo "<script>alert('নোট সফলভাবে মুছে ফেলা হয়েছে।');</script>";
            echo "<script>window.location.href='manage-notes.php';</script>"; // Redirect to the notes management page
        } else {
            echo "<script>alert('নোট মুছে ফেলার সময় সমস্যা হয়েছে।');</script>";
            echo "<script>window.location.href='manage-notes.php';</script>";
        }
    } else {
        // If note doesn't belong to the current department/sub-department
        echo "<script>alert('এই নোটটি মুছে ফেলার অনুমতি নেই।');</script>";
        echo "<script>window.location.href='manage-notes.php';</script>";
    }
} else {
    echo "<script>alert('নোটের আইডি পাওয়া যায়নি।');</script>";
    echo "<script>window.location.href='manage-notes.php';</script>";
}
?>
