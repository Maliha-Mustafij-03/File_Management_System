<?php 
session_start();
include_once('includes/config.php');

// Check if the user is logged in
if (strlen($_SESSION["edmsid"]) == 0) {
    header('location:logout.php');
} else {
    // Check if the form is submitted for updating
    if (isset($_POST['submit'])) {
        // Capture form data
        $category = mysqli_real_escape_string($con, $_POST['category']);
        $sub_category = mysqli_real_escape_string($con, $_POST['sub_category']);
        $createdby = $_SESSION["edmsid"];
        $category_id = intval($_GET['id']);  // Get category ID from URL

        // Check if the sub_category_id exists in the sub_departments table
        $check_sub_category_query = mysqli_query($con, "SELECT id FROM sub_departments WHERE id = '$sub_category'");
        if (mysqli_num_rows($check_sub_category_query) > 0) {
            // Update the category
            $sql = mysqli_query($con, "UPDATE tblcategory SET categoryName='$category', sub_category_id='$sub_category', createdBy='$createdby' WHERE id='$category_id'");

            if ($sql) {
                echo "<script>alert('ফাইলের নাম সফলতার সাথে আপডেট হয়েছে');</script>";
                echo "<script>window.location.href='manage-categories.php'</script>";
            } else {
                echo "<script>alert('ডাটা আপডেট করতে ত্রুটি হয়েছে: " . mysqli_error($con) . "');</script>";
            }
        } else {
            echo "<script>alert('Invalid Sub-Category selected. Please try again.');</script>";
        }
    }

    // Fetch category details to pre-populate the form
    $category_id = intval($_GET['id']);
    $query = mysqli_query($con, "SELECT * FROM tblcategory WHERE id='$category_id'");
    $category_data = mysqli_fetch_array($query);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>ই-ডাটা</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Custom CSS Styles -->
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f7f7f7;
            color: #333;
            margin: 0;
            padding: 0;
        }

        /* Header */
        .sb-nav-fixed {
            background-color: #5a2d86;
            color: white;
            padding: 10px 20px;
            border-bottom: 2px solid #ddd;
        }

        .sb-nav-fixed .breadcrumb-item a {
            color: #f1c40f;
            text-decoration: none;
        }

        .sb-nav-fixed .breadcrumb-item.active {
            color: #ddd;
        }

        .container-fluid {
            margin-top: 30px;
        }

        /* Card Style */
        .card {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            padding: 25px;
            margin-bottom: 30px;
        }

        .card-header {
            background-color: #5a2d86;
            color: #fff;
            font-size: 24px;
            padding: 20px;
            border-radius: 8px;
        }

        .card-body {
            padding: 20px;
        }

        /* Form */
        .form-control {
            font-size: 16px;
            padding: 10px 15px;
            border-radius: 5px;
            border: 1px solid #ccc;
            margin-bottom: 15px;
            width: 100%;
            background-color: #f9f9f9;
            transition: 0.3s ease;
        }

        .form-control:focus {
            border-color: #f1c40f;
            box-shadow: 0 0 5px rgba(241, 196, 15, 0.5);
        }

        /* Button */
        .btn {
            background-color: #5a2d86;
            color: white;
            border: none;
            padding: 12px 25px;
            font-size: 18px;
            border-radius: 5px;
            cursor: pointer;
            transition: 0.3s ease;
        }

        .btn:hover {
            background-color: #f1c40f;
            color: #333;
        }

        /* Dropdowns */
        select {
            font-size: 16px;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            background-color: #f9f9f9;
            transition: 0.3s ease;
        }

        select:focus {
            border-color: #f1c40f;
            box-shadow: 0 0 5px rgba(241, 196, 15, 0.5);
        }

        /* Hover Effects */
        .row:hover {
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
            background-color: #f9f9f9;
        }

        /* Footer */
        footer {
            background-color: #333;
            color: #fff;
            padding: 20px 0;
            text-align: center;
        }

        footer a {
            color: #f1c40f;
            text-decoration: none;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .container-fluid {
                padding: 15px;
            }

            .card-header {
                font-size: 20px;
            }

            .form-control, select, .btn {
                font-size: 14px;
                padding: 8px;
            }
        }
    </style>
</head>

<body>
    <?php include_once('includes/header.php'); ?>
    <div id="layoutSidenav">
        <?php include_once('includes/leftbar.php'); ?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid">
                    <h1 class="mt-4" style="font-size: 32px; font-weight: 700; color: #5a2d86;">ফাইলের নাম আপডেট করুন</h1>
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item"><a href="index.html">ড্যাশবোর্ড</a></li>
                        <li class="breadcrumb-item active">ফাইলের নাম আপডেট করুন</li>
                    </ol>

                    <div class="card">
                        <div class="card-header">ফাইলের নাম আপডেট করুন</div>
                        <div class="card-body">
                            <form method="post">
                                <!-- Department Dropdown -->
                                <div class="row mb-3">
                                    <div class="col-2">বিভাগ</div>
                                    <div class="col-4">
                                        <select name="department" id="department" class="form-control" required>
                                            <option value="">Select Department</option>
                                        </select>
                                    </div>
                                </div>

                                <!-- Sub-Department Dropdown -->
                                <div class="row mb-3">
                                    <div class="col-2">সাব-ভাগ</div>
                                    <div class="col-4">
                                        <select name="sub_category" id="sub-department" class="form-control" required disabled>
                                            <option value="">Select Sub-Department</option>
                                        </select>
                                    </div>
                                </div>

                                <!-- Category Input (Pre-populated) -->
                                <div class="row mb-3">
                                    <div class="col-2">ফাইলের নাম</div>
                                    <div class="col-4">
                                        <input type="text" name="category" class="form-control" value="<?php echo htmlentities($category_data['categoryName']); ?>" required>
                                    </div>
                                </div>

                                <!-- Submit Button -->
                                <div class="row">
                                    <div class="col-2">
                                        <button type="submit" name="submit" class="btn">আপডেট করুন</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </main>
            <?php include_once('includes/footer.php'); ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>

    <!-- Department and Sub-Department Dropdown Logic -->
    <script>
        $(document).ready(function () {
            const departments = [
                {
                    id: "1",
                    name: "PD",
                    sub_departments: [
                        { id: "6", name: "DPD (Communication)" },
                        { id: "8", name: "DPD (Evaluation and Monitoring)" },
                    ],
                },
                {
                    id: "2",
                    name: "APD (Ops)",
                    sub_departments: [
                        { id: "2", name: "DPD (DBA)" },
                        { id: "7", name: "DPD (Finance)" },
                    ],
                },
                {
                    id: "3",
                    name: "APD (Admin)",
                    sub_departments: [
                        { id: "3", name: "DPD (Admin)" },
                        { id: "4", name: "DPD (Asset)" },
                        { id: "5", name: "DPD (Procurement)" },
                    ],
                },
            ];

            let departmentDropdown = $("#department");
            departments.forEach((department) => {
                departmentDropdown.append(new Option(department.name, department.id));
            });

            $("#department").change(function () {
                let departmentId = $(this).val();
                let subDepartmentDropdown = $("#sub-department");
                subDepartmentDropdown
                    .html('<option value="">Select Sub-Department</option>')
                    .prop("disabled", true);

                if (departmentId) {
                    let selectedDepartment = departments.find(
                        (dept) => dept.id === departmentId
                    );
                    selectedDepartment.sub_departments.forEach((subDept) => {
                        subDepartmentDropdown.append(
                            new Option(subDept.name, subDept.id)
                        );
                    });
                    subDepartmentDropdown.prop("disabled", false);
                }
            });
        });
    </script>

</body>

</html>
