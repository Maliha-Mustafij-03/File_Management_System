<?php
// Start session and include configuration file
session_start();
error_reporting(0);
include_once('includes/config.php');

// Redirect to logout if the session is not set
if (strlen($_SESSION["edmsid"]) == 0) {
    header('location:logout.php');
    exit;
}

// Database connection setup
$conn = new mysqli('localhost', 'root', '', 'edmsdb');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch department and sub-department details
$departments = [];
$sub_departments = [];
$query = "SELECT * FROM departments";
$departments_result = $conn->query($query);
while ($row = $departments_result->fetch_assoc()) {
    $departments[] = $row;
}

foreach ($departments as $department) {
    $query = "SELECT * FROM sub_departments WHERE department_id = " . $department['id'];
    $sub_department_result = $conn->query($query);
    while ($sub_department = $sub_department_result->fetch_assoc()) {
        $sub_departments[$department['id']][] = $sub_department;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>ই-ডাটা | ড্যাশবোর্ড</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/fontawesome-free/css/all.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <style>
        body {
            background-color: #f4f5f7;
            /* Light gray background for the entire page */
        }

        .org-tree {
            padding-left: 0;
            list-style-type: none;
        }

        .org-tree li {
            margin: 10px 0;
        }

        .org-tree button {
            background-color: #1f65ab;
            /* Professional blue for department buttons */
            border: none;
            color: #fff;
            /* White text */
            font-size: 1.2rem;
            text-align: left;
            width: 40%;
            padding: 12px 15px;
            /* Better padding for consistent spacing */
            border-radius: 8px;
            /* Softer rounded corners */
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            /* Subtle shadow for depth */
            transition: all 0.3s ease;
            /* Smooth hover transition */
            cursor: pointer;
        }

        .org-tree button:hover {
            background-color: #f8c210;
            /* Yellow hover color for departments */
            transform: scale(1.05);
            /* Slight zoom-in effect */
            box-shadow: 0px 6px 10px rgba(0, 0, 0, 0.15);
            /* Slightly more pronounced shadow */
        }

        .org-tree button:active {
            background-color: #ffffff;
            /* Even lighter for active state */
            transform: scale(0.98);
            /* Slight shrink effect on click */
            box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.1);
            /* Reduce shadow for active state */
        }

        .sub-department {
            margin-left: 30px;
            display: none;
            background-color: #ffffff;
            /* White background for sub-departments */
            padding-left: 10px;
            padding-top: 5px;
            border-radius: 5px;
        }

        .active-sub-department {
            display: block;
        }

        .card {
            background-color: #343a40;
            /* Dark card background */
            color: #fff;
            /* White text */
            border-radius: 8px;
            box-shadow: 0px 6px 15px rgba(0, 0, 0, 0.1);
            /* Subtle shadow for card depth */
        }

        .card-header {
            background-color: #179338;
            /* Green background for card headers */
        }

        .card-body {
            background: linear-gradient(-45deg, #f9a8d4, #a1c4fd, #fbc2eb, #f6d9b7);
            background-size: 400% 400%;
            /* For animation effect */
            animation: gradientAnimation 10s ease infinite;
        }

        @keyframes gradientAnimation {
            0% {
                background-position: 0% 50%;
            }

            50% {
                background-position: 100% 50%;
            }

            100% {
                background-position: 0% 50%;
            }
        }

        .card a {
            color: #f8c210;
            /* Yellow links in the footer */
            text-decoration: none;
        }

        .card-footer a:hover {
            color: #fff;
            /* White hover color for links */
        }

        .table-striped tbody tr:nth-child(odd) {
            background-color: #ffffff;
            /* White background for odd rows */
        }

        .table-striped tbody tr:nth-child(even) {
            background-color: #f4f5f7;
            /* Light gray background for even rows */
        }

        .table-striped th {
            background-color: #4bbf6b;
            /* Green background for table headers */
            color: #fff;
            /* White text */
        }

        .table-striped td {
            color: #333;
            /* Darker text color for readability */
        }

        .btn-primary {
            background-color: #179338;
            border-color: #179338;
        }

        .btn-primary:hover {
            background-color: #148f2e;
            border-color: #148f2e;
        }

        .btn-danger {
            background-color: #dc3545;
            border-color: #dc3545;
        }

        .btn-danger:hover {
            background-color: #c82333;
            border-color: #c82333;
        }
    </style>

</head>

<body class="sb-nav-fixed">
    <?php include_once('includes/header.php'); ?>
    <div id="layoutSidenav">
        <?php include_once('includes/leftbar.php'); ?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">ড্যাশবোর্ড</h1>
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item active">ড্যাশবোর্ড</li>
                    </ol>
                    <hr />

                    <!-- Organogram for departments and sub-departments -->
                    <div class="row">
                        <div class="col-lg-12 mb-4">
                            <div class="org-tree">
                                <?php foreach ($departments as $department) { ?>
                                    <li class="department">
                                        <button type="button" class="btn btn-outline-warning"
                                            onclick="toggleSubDepartment(<?php echo $department['id']; ?>)">
                                            <?php echo $department['name']; ?>
                                        </button>

                                        <!-- Sub-department buttons -->
                                        <div id="sub-department-<?php echo $department['id']; ?>" class="sub-department">
                                            <ul>
                                                <?php
                                                if (isset($sub_departments[$department['id']])) {
                                                    foreach ($sub_departments[$department['id']] as $sub_department) {
                                                ?>
                                                        <li>
                                                            <button type="button" class="btn btn-outline-warning">
                                                                <?php echo $sub_department['name']; ?>
                                                            </button>
                                                        </li>
                                                <?php }
                                                } ?>
                                            </ul>
                                        </div>
                                    </li>
                                <?php } ?>
                            </div>
                        </div>
                    </div>

                    <!-- Dashboard Content -->
                    <div class="row">
                        <?php
                        $userid = $_SESSION["edmsid"];
                        $ret = mysqli_query($con, "SELECT id FROM tblcategory WHERE createdBy='$userid'");
                        $listedcategories = mysqli_num_rows($ret);

                        $query = mysqli_query($con, "SELECT * FROM tblnotes WHERE createdBy='$userid'");
                        $totalnotes = mysqli_num_rows($query);
                        ?>

                        <div class="col-lg-6 col-xl-4 mb-4">
                            <div class="card bg-primary text-white h-100">
                                <div class="card-header">
                                    <i class="fas fa-file-alt"></i> ফাইলের নাম
                                </div>
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div class="me-3">
                                            <div class="text-white-75 small">বিভাগের ফাইল সংখ্যা</div>
                                            <div class="text-lg fw-bold"><?php echo $listedcategories; ?></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <a href="manage-categories.php">বিস্তারিত দেখুন</a>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-6 col-xl-4 mb-4">
                            <div class="card bg-success text-white h-100">
                                <div class="card-header">
                                    <i class="fas fa-database"></i> সর্বমোট এন্ট্রি করা ডাটা
                                </div>
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div class="me-3">
                                            <div class="text-white-75 small">এন্ট্রি করা ডাটা</div>
                                            <div class="text-lg fw-bold"><?php echo $totalnotes; ?></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <a href="manage-notes.php">বিস্তারিত দেখুন</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card mb-4">
                        <div class="card-header">
                            <i class="fas fa-table me-1"></i>
                            নতুন এন্ট্রি করা ডাটা
                        </div>
                        <?php include_once('search.php'); ?>
                        <div class="card-body">
                            <table id="datatablesSimple" class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>স্মারক নং</th>
                                        <th>ফাইলের নাম</th>
                                        <th>এন্ট্রি করার তারিখ</th>
                                        <th>কাজ</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $query = mysqli_query($con, "SELECT * FROM tblnotes WHERE createdBy='$userid'");
                                    $cnt = 1;
                                    while ($row = mysqli_fetch_array($query)) {
                                    ?>
                                        <tr>
                                            <td><?php echo htmlentities($cnt); ?></td>
                                            <td><?php echo htmlentities($row['noteTitle']); ?></td>
                                            <td><?php echo htmlentities($row['noteCategory']); ?></td>
                                            <td> <?php echo htmlentities($row['creationDate']); ?></td>
                                            <td>
                                                <a href="view-note.php?noteid=<?php echo $row['id']; ?>"
                                                    class="btn btn-info btn-xs d-inline-flex align-items-center px-2 py-1">
                                                    <i class="fas fa-eye me-1"></i> বিস্তারিত
                                                </a>
                                                <a href="manage-notes.php?id=<?php echo $row['id']; ?>&del=delete"
                                                    onClick="return confirm('আপনি কি তথ্য মুছে দিতে চান?')"
                                                    class="btn btn-danger btn-xs d-inline-flex align-items-center px-2 py-1">
                                                    <i class="fas fa-trash-alt me-1"></i> মুছুন
                                                </a>
                                            </td>
                                            <!-- <style>
                                                .btn-xs {
                                                    font-size: 0.75rem;
                                                    /* Smaller font size */
                                                    padding: 2px 6px;
                                                    /* Smaller padding */
                                                    border-radius: 4px;
                                                    /* Adjusted border radius */
                                                }
                                            </style> /* Extra-small button size */
 -->



                                        </tr>
                                    <?php $cnt++;
                                    } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
            <?php include_once('includes/footer.php'); ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="assets/demo/chart-area-demo.js"></script>
    <script src="assets/demo/chart-bar-demo.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
    <script src="js/datatables-simple-demo.js"></script>

    <!-- JavaScript to toggle sub-department visibility -->
    <script>
        function toggleSubDepartment(departmentId) {
            var subDept = document.getElementById('sub-department-' + departmentId);
            if (subDept.classList.contains('active-sub-department')) {
                subDept.classList.remove('active-sub-department');
            } else {
                subDept.classList.add('active-sub-department');
            }
        }
    </script>

</body>

</html>