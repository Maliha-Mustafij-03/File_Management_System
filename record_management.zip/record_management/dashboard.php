<?php
// Start session and include configuration file
session_start();
error_reporting(0);
include_once('includes/config.php');

// Redirect to logout if session is not set
if (strlen($_SESSION["edmsid"]) == 0) {
    header('location:logout.php');
    exit;
}

// Database connection setup
$conn = new mysqli('localhost', 'root', '', 'edmsdb');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch departments and sub-departments in one query
$departments = [];
$query = "SELECT d.id AS department_id, d.name AS department_name, 
                 s.id AS sub_id, s.name AS sub_name 
          FROM departments d 
          LEFT JOIN sub_departments s ON d.id = s.department_id";
$result = $conn->query($query);

while ($row = $result->fetch_assoc()) {
    // Initialize department if not already set
    if (!isset($departments[$row['department_id']])) {
        $departments[$row['department_id']] = [
            'id' => $row['department_id'],
            'name' => $row['department_name'],
            'sub_departments' => []
        ];
    }

    // Add sub-department if available
    if (!empty($row['sub_id'])) {
        $departments[$row['department_id']]['sub_departments'][] = [
            'id' => $row['sub_id'],
            'name' => $row['sub_name']
        ];
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>ই-ডাটা | ড্যাশবোর্ড</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/fontawesome-free/css/all.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
   

    <style>
        body {
            background-color: #f4f5f7;
        }

        .org-tree {
            padding-left: 0;
            list-style-type: none;
        }

        .org-tree li {
            margin: 10px 0;
        }

        .org-tree button {
            background-color: #1f65ab;
            border: none;
            color: #fff;
            font-size: 1.2rem;
            text-align: left;
            width: 40%;
            padding: 12px 15px;
            border-radius: 8px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .org-tree button:hover {
            background-color: #f8c210;
            transform: scale(1.05);
            box-shadow: 0px 6px 10px rgba(0, 0, 0, 0.15);
        }

        .org-tree button:active {
            background-color: #ffffff;
            transform: scale(0.98);
            box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.1);
        }

        .sub-department {
            margin-left: 30px;
            display: none;
            background-color: #ffffff;
            padding-left: 10px;
            padding-top: 5px;
            border-radius: 5px;
        }

        .active-sub-department {
            display: block;
        }

        .card {
            background-color: #343a40;
            color: #fff;
            border-radius: 8px;
            box-shadow: 0px 6px 15px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background-color: #179338;
        }

        .card-body {
            background: linear-gradient(-45deg, #f9a8d4, #a1c4fd, #fbc2eb, #f6d9b7);
            background-size: 400% 400%;
            animation: gradientAnimation 10s ease infinite;
        }

        @keyframes gradientAnimation {
            0% {
                background-position: 0% 50%;
            }

            50% {
                background-position: 100% 50%;
            }

            100% {
                background-position: 0% 50%;
            }
        }

        .card a {
            color: #f8c210;
        }

        .card-footer a:hover {
            color: #fff;
        }

        .table-striped tbody tr:nth-child(odd) {
            background-color: #ffffff;
        }

        .table-striped tbody tr:nth-child(even) {
            background-color: #f4f5f7;
        }

        .table-striped th {
            background-color: #4bbf6b;
            color: #fff;
        }

        .table-striped td {
            color: #333;
        }

        .btn-primary {
            background-color: #179338;
            border-color: #179338;
        }

        .btn-primary:hover {
            background-color: #148f2e;
            border-color: #148f2e;
        }

        .btn-danger {
            background-color: #dc3545;
            border-color: #dc3545;
        }

        .btn-danger:hover {
            background-color: #c82333;
            border-color: #c82333;
        }
    </style>
</head>

<body class="sb-nav-fixed">
    <?php include_once('includes/header.php'); ?>
    <div id="layoutSidenav">
        <?php include_once('includes/leftbar.php'); ?>
        <div id="layoutSidenav_content">
            <main>
                <!-- <div class="container-fluid px-4">
                    <h1 class="mt-4">ড্যাশবোর্ড</h1>
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item active">ড্যাশবোর্ড</li>
                    </ol>
                    <hr /> -->
                    <?php include_once('demo1.php'); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
                    
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
