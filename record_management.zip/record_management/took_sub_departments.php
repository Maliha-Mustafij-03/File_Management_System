<?php
include_once('includes/config.php');

if (isset($_GET['department_id'])) {
    $department_id = intval($_GET['department_id']);
    $query = "SELECT id, name FROM sub_departments WHERE department_id = $department_id";
    $result = mysqli_query($con, $query);

    echo '<option value="">Select Sub-Department</option>';
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
    }
}
?>
