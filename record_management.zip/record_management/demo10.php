<?php
// Database Connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "edmsdb";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch category data from tblcategory
$category_sql = "SELECT DISTINCT id, categoryName FROM tblcategory";
$category_result = $conn->query($category_sql);

// Fetch department and sub-department data from tblnotes
$department_sql = "SELECT DISTINCT department_id FROM tblnotes";
$department_result = $conn->query($department_sql);
?>

<!DOCTYPE html>
<html lang="bn">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>প্রকল্পের অর্গানোগ্রাম</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: #ffffff;
        }

        .title-bar {
            background-color: #165016;
            padding: 10px;
            font-size: 20px;
            font-weight: bold;
            color: white;
            border: 2px solid white;
        }

        .chart,
        .category-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            margin-top: 20px;
        }

        .box,
        .category-box {
            background-color: #2d572c;
            color: white;
            padding: 15px;
            border-radius: 5px;
            margin: 10px;
            width: 220px;
            text-align: center;
            font-weight: bold;
            cursor: pointer;
            border: 2px solid white;
            transition: 0.3s;
        }

        .box:hover,
        .category-box:hover {
            background-color: #1b3e1b;
        }

        .sub-box {
            background-color: rgb(30, 99, 30);
            color: #fff;
            padding: 10px;
            border-radius: 5px;
            margin: 5px;
            width: 180px;
            text-align: center;
            cursor: pointer;
            border: 4px solid black;
        }

        .sub-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            display: none;
        }

        .data-container {
            margin-top: 20px;
            padding: 20px;
            background-color: #f8f9fa;
            border-radius: 5px;
            display: none;
            text-align: left;
        }

        .active {
            background-color: rgb(30, 145, 30);
        }

        .link-box {
            text-decoration: none;
            color: white;
        }

        .link-box:hover {
            color: #ffeb3b;
        }
    </style>
</head>

<body>

    <div class="title-bar">প্রকল্পের অর্গানোগ্রাম</div>

   

    <!-- Dynamic Data Display -->
    <div id="categoryData" class="data-container"></div>

    <!-- Organization Chart -->
    <div class="chart">
        <div class="box" onclick="toggleSubMenu('director', this)">
            <a href="#" class="link-box">PD</a>
        </div>
        <div id="director" class="sub-container">
            <div class="sub-box" onclick="toggleSubMenu('admin_finance', this)">
                <a href="#" class="link-box">APD(Admin)</a>
            </div>
            <div class="sub-box" onclick="toggleSubMenu('admin_com', this)">
                <a href="#" class="link-box">DPD(Communication)</a>
            </div>
            <div class="sub-box" onclick="toggleSubMenu('security', this)">
                <a href="#" class="link-box">DPD(Security and Common Services)</a>
            </div>
            <div class="sub-box" onclick="toggleSubMenu('operations', this)">
                <a href="#" class="link-box">APD(Ops)</a>
            </div>
        </div>
    </div>

    <!-- Placeholder for Sub-menus -->
    <div id="admin_finance" class="sub-container">
        <div class="sub-box" onclick="fetchFiles(3, 1)">DPD(Evaluation and Monitoring)</div>
        <div class="sub-box" onclick="fetchFiles(3, 2)">DPD(Admin)</div>
        <div class="sub-box" onclick="fetchFiles(3, 3)">DPD(Finance)</div>
        <div class="sub-box" onclick="fetchFiles(3, 4)">DPD(Asset)</div>
    </div>

    <div id="operations" class="sub-container">
        <div class="sub-box" onclick="fetchFiles(2, 5)">DPD(Procurement)</div>
        <div class="sub-box" onclick="fetchFiles(2, 6)">DPD(Personalization)</div>
        <div class="sub-box" onclick="fetchFiles(2, 7)">DPD(DBA)</div>
        <div class="sub-box" onclick="fetchFiles(2, 8)">DPD(ICT)</div>
        <div class="sub-box" onclick="fetchFiles(2, 9)">DPD(Software Management)</div>
    </div>

    <script>
        function toggleSubMenu(id, element) {
            var submenu = document.getElementById(id);
            var allBoxes = document.querySelectorAll('.box, .sub-box');

            if (submenu.style.display === "none" || submenu.style.display === "") {
                submenu.style.display = "flex";
                element.classList.add("active");
            } else {
                submenu.style.display = "none";
                element.classList.remove("active");
            }

            allBoxes.forEach(box => box.classList.remove('active'));
            element.classList.add('active');
        }

        function fetchCategoryData(categoryId) {
            $.ajax({
                url: "fetch_category_data.php",
                type: "GET",
                data: {
                    category_id: categoryId
                },
                success: function(response) {
                    $("#categoryData").html(response).slideDown();
                }
            });
        }

        function fetchFiles(departmentId, subDepartmentId) {
            $.ajax({
                url: 'fetch_notes.php',
                method: 'GET',
                data: {
                    department_id: departmentId,
                    sub_department_id: subDepartmentId
                },
                success: function(response) {
                    $("#categoryData").html(response).slideDown();
                }
            });
        }
    </script>

</body>

</html>