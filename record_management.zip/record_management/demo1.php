<?php
session_start();
include_once('includes/config.php');

// Fetch department and sub-department data after login
$department_id = $_SESSION['department_id'] ?? null;
$sub_department_id = $_SESSION['sub_department_id'] ?? null;
$role = $_SESSION['role'] ?? null; // Assuming role is stored in session

$has_full_access = false;

// Check if the user is PD (Assuming PD role or specific department ID for PD)
if ($role === 'PD' || ($department_id == 1 && $sub_department_id == 14)) {
    $has_full_access = true;
}

$has_limited_access = false;

// Allow other users to access their assigned department & sub-department
if (!$has_full_access && !empty($department_id) && !empty($sub_department_id)) {
    $has_limited_access = true;
}

?>

<!DOCTYPE html>
<html lang="bn">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project Organogram</title>
    <script src="https://d3js.org/d3.v6.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: left;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .tree-container {
            width: 120%;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 10px;
            box-sizing: border-box;
            overflow: hidden;
        }

        svg {
            width: 100%;
            height: 100%;
            border: 1px solid #ddd;
            border-radius: 10px;
            background-color: #fff;
        }
.node rect.active {
    fill: green; /* Active color */
}

.node rect.inactive {
    fill: grey; /* Inactive color (grey outside, red inside) */
}

.node rect {
    fill: red; /* Default color (red inside) */
    stroke: #fff;
    stroke-width: 4px;
    cursor: pointer;
    width: 190px;
    height: 200px;
    rx: 20px;
    ry: 20px;
    transition: all 0.3s ease;
}

.node rect:hover {
    transform: scale(1.05);
}

.node text {
    font-size: 35px;
    fill: white;
    font-weight: bold;
    pointer-events: none;
    text-anchor: middle;
    dominant-baseline: middle;
}


        .link {
            fill: none;
            stroke: #4CAF50;
            stroke-width: 2px;
            opacity: 0.9;
            transition: stroke 0.3s ease;
        }

        .link:hover {
            stroke-width: 4px;
        }

         .popup {
            display: none;
            position: fixed;
            top: 55%;
            left: 60%;
            transform: translate(-50%, -50%);
            width: 70%;
            height: 90%;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.2);
            text-align: left;
            z-index: 1000;
            overflow-y: auto;
        }

        .popup h2 {
            font-size: 18px;
            margin-bottom: 15px;
        }

        .popup-close {
            background: red;
            color: white;
            padding: 8px;
            border: none;
            cursor: pointer;
            float: right;
        }

        .popup-close:hover {
            color: #e74c3c;
        }

    </style>
</head>

<body>
    <div class="tree-container">
        <svg viewBox="0 0 3500 1000" preserveAspectRatio="xMidYMid meet"></svg>
    </div>

    <div id="notesPopup" class="popup">
        <button class="popup-close" onclick="closePopup()">X</button>
        <h2>Record Data</h2>
        <div class="popup-content" id="notesContent"></div>
    </div>

    <script>
        const treeData = {
            name: "PD",
            children: [
                {
                    name: "APD (ADMIN)",
                    department_id: 1,
                    sub_department_id: 14,
                    children: [
                        { name: "DPD(ADMIN)", department_id: 3, sub_department_id: 3 },
                        { name: "DPD (FINANCE)", department_id: 3, sub_department_id: 7 },
                        { name: "DPD (ASSET)", department_id: 3, sub_department_id: 4 },
                        { name: "DPD(SECURITY AND COMMON SERVICES)", department_id: 3, sub_department_id: 9 },
                        { name: "DPD (PROCUREMENT)", department_id: 3, sub_department_id: 5 }
                    ]
                },
                { name: "DPD (MONITORING AND EVALUATION)", department_id: 1, sub_department_id: 8 },
                { name: "DPD (COMMUNICATION)", department_id: 1, sub_department_id: 6 },
                {
                    name: "APD(OPS)",
                    department_id: 1,
                    sub_department_id: 12,
                    children: [
                        { name: "DPD (PERSONALIZATION)", department_id: 2, sub_department_id: 1 },
                        { name: "DPD (DBA)", department_id: 2, sub_department_id: 2 },
                        { name: "DPD (ICT)", department_id: 2, sub_department_id: 10 },
                        { name: "DPD(SOFTWARE MANAGEMENT)", department_id: 2, sub_department_id: 11 }
                    ]
                }
            ]
        };

        const svg = d3.select("svg"),
            width = 3500,
            height = 1000,
            g = svg.append("g").attr("transform", "translate(50,50)");

        const treeLayout = d3.tree().size([width - 450, height - 150]);
        const root = d3.hierarchy(treeData);
        treeLayout(root);

        const link = g.selectAll(".link")
            .data(root.links())
            .enter()
            .append("path")
            .attr("class", "link")
            .attr("d", d3.linkVertical()
                .x(d => d.x)
                .y(d => d.y + 60)
            );

        const node = g.selectAll(".node")
            .data(root.descendants())
            .enter()
            .append("g")
            .attr("class", "node")
            .attr("transform", d => `translate(${d.x},${d.y})`)
            .on("click", function(event, d) {
                checkPermission(d.data.department_id, d.data.sub_department_id, d.data.name);
            });

        function getTextWidth(text, fontSize = 10) {
            const canvas = document.createElement("canvas");
            const context = canvas.getContext("2d");
            context.font = `${fontSize}px Arial`;
            return context.measureText(text).width + 70;
        }

       node.append("rect")
    .attr("x", d => -(getTextWidth(d.data.name) / 2))
    .attr("y", -40)
    .attr("width", d => getTextWidth(d.data.name))
    .attr("height", 40)
    .attr("rx", 60)
    .attr("ry", 60)
    .attr("class", function(d) {
        // Check if the node has limited or full access for initial state
        const userDeptId = <?php echo json_encode($department_id); ?>;
        const userSubDeptId = <?php echo json_encode($sub_department_id); ?>;
        const hasFullAccess = <?php echo json_encode($has_full_access); ?>;
        const hasLimitedAccess = <?php echo json_encode($has_limited_access); ?>;

        if (hasFullAccess || (hasLimitedAccess && d.data.department_id == userDeptId && d.data.sub_department_id == userSubDeptId)) {
            return "active";  // If the user has access, set active class.
        } else {
            return "inactive"; // If not, set inactive class.
        }
    });


        node.append("text")
            .attr("dy", 10)
            .attr("text-anchor", "middle")
            .attr("x", 0)
            .attr("y", 10)
            .text(d => d.data.name);


        function checkPermission(deptId, subDeptId, nodeName) {
            const userDeptId = <?php echo json_encode($department_id); ?>;
            const userSubDeptId = <?php echo json_encode($sub_department_id); ?>;
            const hasFullAccess = <?php echo json_encode($has_full_access); ?>;
            const hasLimitedAccess = <?php echo json_encode($has_limited_access); ?>;

            if (hasFullAccess || (hasLimitedAccess && deptId == userDeptId && subDeptId == userSubDeptId)) {
                fetchNotes(deptId, subDeptId, nodeName);
            } else {
                alert("You do not have permission to view this data.");
            }
        }

        function fetchNotes(departmentId, subDepartmentId, nodeName) {
            $.ajax({
                url: 'fetch_notes.php',
                method: 'GET',
                data: {
                    department_id: departmentId,
                    sub_department_id: subDepartmentId
                },
                success: function(response) {
                    $('#notesContent').html(`<h3>${nodeName}</h3>${response}`);
                    $('#notesPopup').fadeIn();
                }
            });
        }
function wrapText(text, maxCharsPerLine) {
    const lines = [];
    for (let i = 0; i < text.length; i += maxCharsPerLine) {
        lines.push(text.substring(i, i + maxCharsPerLine));
    }
    return lines;
}

node.each(function(d) {
    const node = d3.select(this);
    const lines = wrapText(d.data.name, 11);  // Wrap text every 8 characters

    const height = lines.length * 30 + 40;  // Adjust height based on line count
    const width = Math.max(...lines.map(line => getTextWidth(line, 18)));  // Adjust width based on the longest line

    // Update the rect (box) to fit the wrapped text
    node.select("rect")
        .attr("width", width)
        .attr("height", height)
        .attr("x", -width / 2)
        .attr("y", -height / 2);

    // Remove any existing text (to avoid duplication)
    node.selectAll("text").remove();

    // Append the wrapped text, each line in its own <text> element
    node.selectAll("text")
        .data(lines)
        .enter()
        .append("text")
        .attr("dy", (d, i) => (i - (lines.length - 1) / 2) * 30)  // Positioning each line of text
        .attr("x", 0)
        .attr("y", 0)
        .text(d => d)
        .style("font-size", "18px")  // Increased font size
        .style("fill", "#fff")
        .style("text-anchor", "middle");
});

        function closePopup() {
            $('#notesPopup').fadeOut();
        }
    </script>

</body>
</html>
