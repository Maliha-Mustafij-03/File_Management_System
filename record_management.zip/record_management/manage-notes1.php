<?php
session_start();
require_once 'includes/config.php'; // Ensure this file exists and defines $conn

// Ensure user is logged in and retrieve department and sub-department from session
$department_id = isset($_SESSION["department_id"]) ? $_SESSION["department_id"] : '';
$sub_department_id = isset($_SESSION["sub_department_id"]) ? $_SESSION["sub_department_id"] : '';

// Check if department and sub-department are set
if (empty($department_id) || empty($sub_department_id)) {
    die("Unauthorized access. Department or sub-department not set.");
}

// Handle category deletion
if (isset($_GET['delete_id'])) {
    $category_id = intval($_GET['delete_id']);

    // Prepare DELETE query with department and sub-department restriction
    if ($stmt = $conn->prepare("DELETE FROM tblcategory WHERE id = ? AND department_id = ? AND sub_department_id = ?")) {
        $stmt->bind_param("iii", $category_id, $department_id, $sub_department_id);
        if ($stmt->execute()) {
            echo "<script>alert('Category deleted successfully.'); window.location.href='manage-category.php';</script>";
        } else {
            echo "<script>alert('Error deleting category.');</script>";
        }
        $stmt->close();
    } else {
        echo "<script>alert('Database error: Unable to prepare statement.');</script>";
    }
}

// Fetch categories based on department and sub-department
if ($stmt = $con->prepare("SELECT id, categoryName, createdBy, creationDate FROM tblcategory WHERE department_id = ? AND sub_department_id = ?")) {
    $stmt->bind_param("ii", $department_id, $sub_department_id);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    die("Database error: Unable to fetch categories.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Categories</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <h2>Manage Categories</h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Category Name</th>
            <th>Created By</th>
            <th>Creation Date</th>
            <th>Action</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?php echo htmlspecialchars($row['id']); ?></td>
            <td><?php echo htmlspecialchars($row['categoryName']); ?></td>
            <td><?php echo htmlspecialchars($row['createdBy']); ?></td>
            <td><?php echo htmlspecialchars($row['creationDate']); ?></td>
            <td>
                <a href="edit-category.php?id=<?php echo $row['id']; ?>">Edit</a> | 
                <a href="manage-category.php?delete_id=<?php echo $row['id']; ?>" 
                   onclick="return confirm('Are you sure you want to delete this category?');">Delete</a>
            </td>
        </tr>
        <?php } ?>
    </table>

</body>
</html>

<?php
$stmt->close();
$con->close();
?>
