

<!DOCTYPE html>
<html lang="bn">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project Organogram</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            background-color: #f3f4f6; /* Light background for a modern look */
            color: #2c3e50;
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
        }

        h1 {
            background-color: #2980b9; /* Vibrant blue background */
            color: white;
            padding: 20px;
            font-size: 2.5em;
            margin-bottom: 30px;
            font-weight: bold;
            text-align: center;
            border-radius: 5px;
            letter-spacing: 2px;
        }

        .chart {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
        }

        .box {
            background-color: #3498db; /* Vibrant blue for active buttons */
            padding: 20px 30px;
            margin: 10px;
            border-radius: 10px;
            color: white;
            font-weight: bold;
            text-transform: uppercase;
            font-size: 1.2em;
            border: 3px solid #2980b9;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }

        .box:hover {
            background-color: #2980b9;
            transform: translateY(-5px);
            box-shadow: 0px 8px 20px rgba(0, 0, 0, 0.15);
        }

        .sub-box {
            background-color: #e74c3c; /* Bright red for sub-boxes */
            color: white;
            border: 2px solid #c0392b;
            padding: 15px 25px;
            margin: 10px;
            border-radius: 8px;
            cursor: pointer;
            font-weight: bold;
            transition: background-color 0.3s, transform 0.2s ease;
            font-size: 1.1em;
        }

        .sub-box:hover {
            background-color: #c0392b;
            transform: translateY(-5px);
        }

        .line {
            width: 2px;
            height: 50px;
            background-color: #3498db;
            margin: 10px auto;
        }

        .horizontal-line {
            width: 100px;
            height: 2px;
            background-color: #3498db;
            margin: 20px auto;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
        }

        .container div {
            flex: 1;
            min-width: 200px;
            margin: 20px;
            display: flex;
            justify-content: center;
        }

        .popup {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 80%;
            background: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
            z-index: 1000;
            text-align: left;
            color: #2c3e50;
            font-size: 1.2em;
            overflow-y: auto;
        }

        .popup h2 {
            font-size: 2em;
            margin-bottom: 20px;
            font-weight: bold;
            color: #2980b9;
        }

        .popup-close {
            background: #e74c3c;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            font-weight: bold;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            position: absolute;
            top: 20px;
            right: 20px;
        }

        .popup-close:hover {
            background: #c0392b;
        }

        .inactive {
            background-color: #95a5a6;
            color: #7f8c8d;
            cursor: not-allowed;
            opacity: 0.6;
            border: 2px solid #7f8c8d;
        }

        @media screen and (max-width: 768px) {
            .container {
                flex-direction: column;
            }

            .popup {
                width: 90%;
                padding: 20px;
            }

            .box,
            .sub-box {
                font-size: 1em;
                padding: 15px;
            }
        }
    </style>
</head>

<body>
    <h1>Project Organogram</h1>
    <div class="chart">
        <!-- PD Box -->
        <div class="box <?php echo ($department_id == 1 && $sub_department_id == 14) ? 'active' : 'inactive'; ?>"
            onclick="toggleSubMenu('director', this)">PD</div>

        <div class="line"></div>

        <div class="container">
            <!-- APD OPS and ADMIN -->
            <div class="box <?php echo ($department_id == 1 && $sub_department_id == 14) || ($department_id == 1 && $sub_department_id == 12) ? 'active' : 'inactive'; ?>"
                onclick="toggleSubMenu('operations', this)">APD (OPS)</div>
            <div class="horizontal-line"></div>

            <div class="box <?php echo ($department_id == 1 && $sub_department_id == 14) || ($department_id == 1 && $sub_department_id == 13) ? 'active' : 'inactive'; ?>"
                onclick="toggleSubMenu('admin_finance', this)">APD (ADMIN)</div>
        </div>

        <div class="line"></div>

        <div class="container">
            <!-- DPD Communication and Evaluation -->
            <div class="box <?php echo ($department_id == 1 && $sub_department_id == 14) || ($department_id == 1 && $sub_department_id == 6) ? 'active' : 'inactive'; ?>"
                onclick="fetchNotes(1, 6)">DPD (Communication)</div>
            <div class="horizontal-line"></div>

            <div class="box <?php echo ($department_id == 1 && $sub_department_id == 14) || ($department_id == 1 && $sub_department_id == 8) ? 'active' : 'inactive'; ?>"
                onclick="fetchNotes(1, 8)">DPD (Evaluation and Monitoring)</div>
        </div>

        <div class="line"></div>

        <div class="container">
            <!-- DPD Personalization, DBA, ICT, etc. -->
            <div class="box <?php echo ($department_id == 1 && $sub_department_id == 14) || ($department_id == 2 && $sub_department_id == 1) ? 'active' : 'inactive'; ?>"
                onclick="fetchNotes(2, 1)">DPD (Personalization)</div>
            <div class="box <?php echo ($department_id == 1 && $sub_department_id == 14) || ($department_id == 2 && $sub_department_id == 2) ? 'active' : 'inactive'; ?>"
                onclick="fetchNotes(2, 2)">DPD (DBA)</div>
            <div class="box <?php echo ($department_id == 1 && $sub_department_id == 14) || ($department_id == 2 && $sub_department_id == 10) ? 'active' : 'inactive'; ?>"
                onclick="fetchNotes(2, 10)">DPD (ICT)</div>
            <div class="box <?php echo ($department_id == 1 && $sub_department_id == 14) || ($department_id == 2 && $sub_department_id == 11) ? 'active' : 'inactive'; ?>"
                onclick="fetchNotes(2, 11)">DPD (Software Management)</div>
            <div class="box <?php echo ($department_id == 1 && $sub_department_id == 14) || ($department_id == 3 && $sub_department_id == 3) ? 'active' : 'inactive'; ?>"
                onclick="fetchNotes(3, 3)">DPD (Admin)</div>
        </div>

        <div class="line"></div>

        <div class="container">
            <!-- DPD Finance, Asset, Procurement, etc. -->
            <div class="box <?php echo ($department_id == 1 && $sub_department_id == 14) || ($department_id == 3 && $sub_department_id == 7) ? 'active' : 'inactive'; ?>"
                onclick="fetchNotes(3, 7)">DPD (Finance)</div>
            <div class="box <?php echo ($department_id == 1 && $sub_department_id == 14) || ($department_id == 3 && $sub_department_id == 4) ? 'active' : 'inactive'; ?>"
                onclick="fetchNotes(3, 4)">DPD (Asset)</div>
            <div class="box <?php echo ($department_id == 1 && $sub_department_id == 14) || ($department_id == 3 && $sub_department_id == 9) ? 'active' : 'inactive'; ?>"
                onclick="fetchNotes(3, 9)">DPD (Security and Common Services)</div>
            <div class="box <?php echo ($department_id == 1 && $sub_department_id == 14) || ($department_id == 3 && $sub_department_id == 5) ? 'active' : 'inactive'; ?>"
                onclick="fetchNotes(3, 5)">DPD (Procurement)</div>
        </div>
    </div>

    <!-- Popup for Notes -->
    <div id="notesPopup" class="popup">
        <button class="popup-close" onclick="closePopup()">X</button>
        <h2>Record Data</h2>
        <div class="popup-content" id="notesContent"></div>
    </div>

    <script>
        function toggleSubMenu(id, element) {
            var submenu = document.getElementById(id);
            submenu.style.display = submenu.style.display === "flex" ? "none" : "flex";
            element.classList.toggle("active");
        }

        function fetchNotes(departmentId, subDepartmentId) {
            var button = event.target;
            if (button.classList.contains('inactive')) {
                return;
            }

            $.ajax({
                url: 'fetch_notes.php',
                method: 'GET',
                data: {
                    department_id: departmentId,
                    sub_department_id: subDepartmentId
                },
                success: function(response) {
                    $('#notesContent').html(response);
                    $('#notesPopup').fadeIn();
                }
            });
        }

        function closePopup() {
            $('#notesPopup').fadeOut();
        }
    </script>
</body>

</html>
