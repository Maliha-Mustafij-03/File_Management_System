<?php
$conn = new mysqli('localhost', 'root', '', 'edmsdb');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$department_id = $_GET['department_id'];
$sub_department_id = $_GET['sub_department_id'];

$query = "SELECT * FROM sub_departments WHERE department_id = ? AND id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("ii", $department_id, $sub_department_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "Result: " . $row['name'] . "<br>";
    }
} else {
    echo "No results found.";
}
?>
