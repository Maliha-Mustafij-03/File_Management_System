<?php
// Include the database connection file
include 'includes/config.php'; // Ensure correct path

// Get the department and sub-department IDs from the GET request
$department_id = isset($_GET['department_id']) ? (int)$_GET['department_id'] : 0;
$sub_department_id = isset($_GET['sub_department_id']) ? (int)$_GET['sub_department_id'] : 0;

// Validate input
if ($department_id > 0 && $sub_department_id > 0) {
    if ($conn) {
        // Fetch categories based on department and sub-department ID
        $sql = "SELECT id, categoryName FROM tblcategory WHERE department_id = ? AND sub_department_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $department_id, $sub_department_id);
        $stmt->execute();
        $result = $stmt->get_result();

        // Store results in an array
        $categories = [];
        while ($row = $result->fetch_assoc()) {
            $categories[] = $row;
        }

        // Return JSON response
        echo json_encode($categories);

        // Close the prepared statement
        $stmt->close();
    } else {
        echo json_encode(['error' => 'Database connection failed']);
    }
} else {
    echo json_encode([]); // Return empty response if invalid parameters
}

// Close the database connection
$conn->close();
?>
