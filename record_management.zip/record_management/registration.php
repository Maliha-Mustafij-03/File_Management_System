<?php
include_once('includes/config.php');

// Fetch departments
$departmentsQuery = "SELECT * FROM departments";
$departmentsResult = mysqli_query($con, $departmentsQuery);
$departments = mysqli_fetch_all($departmentsResult, MYSQLI_ASSOC);

// Initialize an empty array for sub-departments
$subDepartments = [];

// If a department is selected, fetch the sub-departments
if (isset($_GET['department_id'])) {
    $departmentId = $_GET['department_id'];

    // Prepare the query to prevent SQL injection
    $query = "SELECT * FROM sub_departments WHERE department_id = ?";

    // Initialize the prepared statement
    if ($stmt = mysqli_prepare($con, $query)) {
        // Bind the parameter (department_id) to the statement
        mysqli_stmt_bind_param($stmt, "i", $departmentId);

        // Execute the statement
        mysqli_stmt_execute($stmt);

        // Get the result
        $result = mysqli_stmt_get_result($stmt);

        // Fetch sub-departments
        $subDepartments = mysqli_fetch_all($result, MYSQLI_ASSOC);

        // Close the prepared statement
        mysqli_stmt_close($stmt);
    } else {
        echo '<option value="">Error with database query</option>';
    }
} else {
    // If no department is selected, set an empty option for sub-departments
    $subDepartments = [];
}

// Handle form submission
if (isset($_POST['register'])) {
    // Get form data
    $firstName = mysqli_real_escape_string($con, $_POST['firstName']);
    $lastName = mysqli_real_escape_string($con, $_POST['lastName']);
    $emailId = mysqli_real_escape_string($con, $_POST['emailId']);
    $mobileNumber = mysqli_real_escape_string($con, $_POST['mobileNumber']);

    // Corrected: Use md5() on the password string directly
    $userPassword = md5($_POST['userPassword']);  // Password hashing

    $departmentId = $_POST['department'];
    $subDepartmentId = $_POST['sub_department'];

    // Insert into the database
    $insertQuery = "INSERT INTO tblregistration (firstName, lastName, emailId, mobileNumber, userPassword, department_id, sub_department_id) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)";

    if ($stmt = mysqli_prepare($con, $insertQuery)) {
        // Bind parameters
        mysqli_stmt_bind_param($stmt, "sssssss", $firstName, $lastName, $emailId, $mobileNumber, $userPassword, $departmentId, $subDepartmentId);

        if (mysqli_stmt_execute($stmt)) {
            echo "User registered successfully!";
        } else {
            echo "Error: " . mysqli_error($con);
        }

        // Close the prepared statement
        mysqli_stmt_close($stmt);
    } else {
        echo "Error preparing the statement: " . mysqli_error($con);
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>নতুন অ্যাকাউন্ট নিবন্ধন</title>
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>

    <!-- JavaScript to refresh the page with the selected department -->
    <script>
        function updateSubDepartments() {
            var departmentId = document.getElementById('inputDepartment').value;
            window.location.href = '?department_id=' + departmentId; // Refresh page with the selected department
        }
    </script>

    <style>
        body {
            background: url('assets/img/banner.jpg') no-repeat center center fixed;
            /* Background Image */
            background-size: cover;
            font-family: 'Roboto', sans-serif;
            margin: 0;
            color: #000;
        }

        .container {
            max-width: 1000px;
            margin-top: 50px;
        }

        .card {
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 4px 25px rgba(0, 0, 0, 0.1);
            padding: 60px;
            background-color: rgba(255, 255, 255, 0.9);
            width: 90%;
            margin: auto;
        }

        .card-header {
            background-color: #28a745;
            color: white;
            padding: 30px;
            text-align: center;
            font-size: 30px;
        }

        .card-body {
            padding: 40px;
            background-color: #fff;
        }

        .form-floating input,
        .form-floating select {
            border-radius: 8px;
            padding: 15px;
            color: #000;
            background-color: #fff;
        }

        .form-floating input {
            border: 1px solid #ccc;
            font-size: 18px;
        }

        .form-floating label {
            color: #000;
        }

        .form-floating input::placeholder {
            color: #999;
        }

        .form-floating input:focus,
        .form-floating select:focus {
            border-color: #28a745;
            box-shadow: 0 0 8px rgba(40, 167, 69, 0.5);
        }

        .btn-primary {
            background-color: #28a745;
            border: none;
            padding: 15px 25px;
            font-size: 18px;
            border-radius: 8px;
            width: 100%;
        }

        .btn-primary:hover {
            background-color: #218838;
        }

        .footer-link {
            text-align: center;
            padding: 10px;
            font-size: 14px;
        }

        .small a {
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            background-color: #006400;
            border-radius: 5px;
            font-weight: bold;
        }

        .small a:hover {
            background-color: #004d00;
            text-decoration: none;
        }

        .logo {
            width: 150px;
            display: block;
            margin: 20px auto;
        }

        @media (max-width: 768px) {
            .card {
                padding: 25px;
            }

            .container {
                padding: 10px;
            }
        }
    </style>
</head>

<body>
    <div id="layoutAuthentication">
        <div id="layoutAuthentication_content">
            <main>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-8">
                            <div class="card shadow-lg border-0 rounded-lg mt-5">
                                <div class="card-header">
                                    <h3 class="font-weight-light my-4">নতুন অ্যাকাউন্ট নিবন্ধন</h3>
                                </div>
                                <div class="card-body">
                                    <form method="post">
                                        <!-- Department Dropdown -->
                                        <div class="form-floating mb-3">
                                            <select class="form-control" id="inputDepartment" name="department" required onchange="updateSubDepartments()">
                                                <option value="">-- Select Department --</option>
                                                <?php foreach ($departments as $department) { ?>
                                                    <option value="<?php echo $department['id']; ?>" <?php echo (isset($_GET['department_id']) && $_GET['department_id'] == $department['id']) ? 'selected' : ''; ?>>
                                                        <?php echo $department['name']; ?>
                                                    </option>
                                                <?php } ?>
                                            </select>
                                            <label for="inputDepartment">বিভাগ</label>
                                        </div>

                                        <!-- Sub-department Dropdown -->
                                        <div class="form-floating mb-3">
                                            <select class="form-control" id="inputSubDepartment" name="sub_department" required>
                                                <option value="">-- Select Sub-department --</option>
                                                <?php foreach ($subDepartments as $subDepartment) { ?>
                                                    <option value="<?php echo $subDepartment['id']; ?>">
                                                        <?php echo $subDepartment['name']; ?>
                                                    </option>
                                                <?php } ?>
                                            </select>
                                            <label for="inputSubDepartment">সাব-বিভাগ</label>
                                        </div>

                                        <!-- User Info Fields -->
                                        <div class="form-floating mb-3">
                                            <input class="form-control" id="inputFirstName" type="text" name="firstName" placeholder="প্রথম নাম" required />
                                            <label for="inputFirstName">প্রথম নাম</label>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <input class="form-control" id="inputLastName" type="text" name="lastName" placeholder="শেষ নাম" required />
                                            <label for="inputLastName">শেষ নাম</label>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <input class="form-control" id="inputEmail" type="email" name="emailId" placeholder="ই-মেইল" required />
                                            <label for="inputEmail">ই-মেইল</label>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <input class="form-control" id="inputMobile" type="text" name="mobileNumber" placeholder="মোবাইল নম্বর" required />
                                            <label for="inputMobile">মোবাইল নম্বর</label>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <input class="form-control" id="inputPassword" type="password" name="userPassword" placeholder="পাসওয়ার্ড" required />
                                            <label for="inputPassword">পাসওয়ার্ড</label>
                                        </div>

                                        <button class="btn btn-primary" type="submit" name="register">নিবন্ধন করুন</button>
                                        <footer class="footer-link">
                                            <div class="small">
                                                <a href="index.php">হোমপেইজে ফেরত যান</a>
                                            </div>
                                        </footer>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
</body>

</html>