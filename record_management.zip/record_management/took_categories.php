<?php
include_once('includes/config.php');

if (isset($_GET['sub_department_id']) && isset($_GET['department_id'])) {
    $sub_department_id = intval($_GET['sub_department_id']);
    $department_id = intval($_GET['department_id']);

    $query = "SELECT id, categoryName FROM tblcategory WHERE sub_department_id = $sub_department_id AND department_id = $department_id";
    $result = mysqli_query($con, $query);

    echo '<option value="">Select Category</option>';
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<option value='" . $row['id'] . "'>" . $row['categoryName'] . "</option>";
    }
}
?>
