 <?php
session_start();
include_once('includes/config.php');

// Fetch department and sub-department data after login
$department_id = null;
$sub_department_id = null;
$has_full_access = false;

if (isset($_SESSION['edmsid'])) {
    $department_id = $_SESSION['department_id'];
    $sub_department_id = $_SESSION['sub_department_id'];

    // Check if the user is PD (Assuming department_id = 1 and sub_department_id = 14 for PD)
    if ($department_id == 1 && $sub_department_id == 14) {
        $has_full_access = true;
    }
}
?>
 
<!DOCTYPE html>
<html lang="bn">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project Organogram</title>
    <script src="https://d3js.org/d3.v6.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: #ffffff;
            margin: 0;
            padding: 0;
        }

        .tree-container {
            width: 100%;
            height: 800px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        svg {
            width: 100%;
            height: 600px;
        }

        .node rect {
            fill: #2d572c;
            stroke: #fff;
            stroke-width: 2px;
            cursor: pointer;
        }

        .node text {
            font-size: 15px;
            fill: white;
            font-weight: bold;
            pointer-events: none;
            text-align: left;
        }

        .link {
            fill: none;
            stroke: #000000;
            stroke-width: 2px;
        }

        .popup {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: white;
            padding: 20px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.5);
            z-index: 1000;
        }

        .popup-close {
            position: absolute;
            top: 5px;
            right: 10px;
            cursor: pointer;
            font-size: 18px;
        }
    </style>
</head>

<body>
    <div class="tree-container">
        <svg viewBox="0 0 1000 600" preserveAspectRatio="xMidYMid meet"></svg>
    </div>

    <!-- Popup for Notes -->
    <div id="notesPopup" class="popup">
        <button class="popup-close" onclick="closePopup()">X</button>
        <h2>Record Data</h2>
        <div class="popup-content" id="notesContent"></div>
    </div>

    <script>
        const treeData = {
            name: "PD",
            children: [
                {
                    name: "APD (ADMIN)",
                    department_id: 1,
                    sub_department_id: 14,
                    children: [
                        { name: "DPD (ADMIN)", department_id: 3, sub_department_id: 3 },
                        { name: "DPD (FINANCE)", department_id: 3, sub_department_id: 7 },
                        { name: "DPD (ASSET)", department_id: 3, sub_department_id: 4 },
                        { name: "DPD (SECURITY AND COMMON SERVICES)", department_id: 3, sub_department_id: 9 },
                        { name: "DPD (PROCUREMENT)", department_id: 3, sub_department_id: 5 }
                    ]
                },
                { name: "DPD (MONITORING AND EVALUATION)", department_id: 1, sub_department_id: 8 },
                { name: "DPD (COMMUNICATION)", department_id: 1, sub_department_id: 6 },
                {
                    name: "APD (OPS)",
                    department_id: 1,
                    sub_department_id: 12,
                    children: [
                        { name: "DPD (PERSONALIZATION)", department_id: 2, sub_department_id: 1 },
                        { name: "DPD (DBA)", department_id: 2, sub_department_id: 2 },
                        { name: "DPD (ICT)", department_id: 2, sub_department_id: 10 },
                        { name: "DPD (SOFTWARE MANAGEMENT)", department_id: 2, sub_department_id: 11 }
                    ]
                }
            ]
        };

        const svg = d3.select("svg"),
            width = 1000,
            height = 600,
            g = svg.append("g").attr("transform", "translate(50,50)");

        const treeLayout = d3.tree().size([width - 200, height - 250]);
        const root = d3.hierarchy(treeData);
        treeLayout(root);

        const link = g.selectAll(".link")
            .data(root.links())
            .enter()
            .append("path")
            .attr("class", "link")
            .attr("d", d3.linkVertical()
                .x(d => d.x)
                .y(d => d.y + 30)
            );

        const node = g.selectAll(".node")
            .data(root.descendants())
            .enter()
            .append("g")
            .attr("class", "node")
            .attr("transform", d => `translate(${d.x},${d.y})`)
            .on("click", function(event, d) {
                checkPermission(d.data.department_id, d.data.sub_department_id, d.data.name);
            });

        function getTextWidth(text, fontSize = 14) {
            const canvas = document.createElement("canvas");
            const context = canvas.getContext("2d");
            context.font = `${fontSize}px Arial`;
            return context.measureText(text).width + 50;
        }

        node.append("rect")
            .attr("x", d => -(getTextWidth(d.data.name) / 2))
            .attr("y", -20)
            .attr("width", d => getTextWidth(d.data.name))
            .attr("height", 40)
            .attr("rx", 10)
            .attr("ry", 10);

        node.append("text")
            .attr("dy", 5)
            .attr("text-anchor", "middle")
            .attr("x", 0)
            .attr("y", 5)
            .text(d => d.data.name);

         function checkPermission(deptId, subDeptId, nodeName) {
            const userDeptId = <?php echo json_encode($department_id); ?>;
            const userSubDeptId = <?php echo json_encode($sub_department_id); ?>;
            const hasFullAccess = <?php echo json_encode($has_full_access); ?>;

            if (hasFullAccess || (deptId === userDeptId && subDeptId === userSubDeptId)) {
                fetchNotes(deptId, subDeptId, nodeName);
            } else {
             alert("You do not have permission to view this data.");
            }
         }


        function fetchNotes(departmentId, subDepartmentId, nodeName) {
            $.ajax({
                url: 'fetch_notes.php',
                method: 'GET',
                data: {
                    department_id: departmentId,
                    sub_department_id: subDepartmentId
                },
                success: function(response) {
                    $('#notesContent').html(`<h3>${nodeName}</h3>${response}`);
                    $('#notesPopup').fadeIn();
                }
            });
        }

        function closePopup() {
            $('#notesPopup').fadeOut();
        }
    </script>
</body>
</html>
