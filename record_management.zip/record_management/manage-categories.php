<?php session_start();
include_once('includes/config.php');
if(strlen($_SESSION["department_id"])==0 || strlen($_SESSION["sub_department_id"])==0) {
    header('location:logout.php');
} else {
    

    // For deleting    
    if ($_GET['del']) {
        $catid = $_GET['id'];
        $userid = $_SESSION["edmsid"];
        mysqli_query($con, "delete from tblcategory where id ='$catid' and createdBy='$userid'");
        echo "<script>window.location.href='manage-categories.php'</script>";
    }
?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>ই-ডাটা</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>

        <!-- Custom Styles for a Bold and Luxurious Look -->
        <style>
            body {
                font-family: 'Poppins', sans-serif;
                background-color: #F4F5F9;
                color: #4A4A4A;
                margin: 0;
                padding: 0;
            }

            /* Header */
            .sb-nav-fixed {
                background-color: #5A2D86; /* Dark Purple */
                color: white;
                padding: 15px 0;
            }

            .sb-nav-fixed .breadcrumb-item a {
                color: #F1C40F; /* Gold */
                text-decoration: none;
                font-weight: 600;
            }

            .sb-nav-fixed .breadcrumb-item.active {
                color: #B3B6B7;
            }

            .container-fluid {
                margin-top: 40px;
            }

            /* Card Design */
            .card {
                background-color: #FFFFFF;
                border-radius: 15px;
                box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
                margin-bottom: 30px;
                padding: 20px;
                transition: all 0.3s ease;
            }

            .card:hover {
                transform: translateY(-5px);
                box-shadow: 0 20px 50px rgba(0, 0, 0, 0.15);
            }

            .card-header {
                background-color: #5A2D86; /* Dark Purple */
                color: #fff;
                font-size: 22px;
                font-weight: 600;
                padding: 20px;
                border-radius: 10px;
            }

            .card-body {
                padding: 30px;
            }

            table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 20px;
            }

            th, td {
                padding: 20px;
                text-align: left;
                font-size: 18px;
                font-weight: 500;
            }

            th {
                background-color: #F1C40F; /* Gold */
                color: white;
            }

            td {
                background-color: #fff;
                color: #4A4A4A;
                border-bottom: 1px solid #E6E6E6;
            }

            /* Hover effects for table rows */
            tr:hover {
                background-color: #F9F9F9;
            }

            td a {
                color: #5A2D86;
                text-decoration: none;
                transition: all 0.3s ease;
                font-weight: 600;
            }

            td a:hover {
                color: #F1C40F;
                text-decoration: underline;
            }

            /* Action Icons */
            .action-icons i {
                font-size: 20px;
                margin-right: 20px;
                cursor: pointer;
                transition: color 0.3s ease, transform 0.3s ease;
            }

            .action-icons i:hover {
                transform: scale(1.2);
                color: #F1C40F;
            }

            /* Success and Error Alerts */
            .alert {
                padding: 15px;
                margin-bottom: 20px;
                border-radius: 5px;
                font-weight: 600;
                font-size: 18px;
            }

            .alert-success {
                background-color: #2ECC71;
                color: #fff;
            }

            .alert-error {
                background-color: #E74C3C;
                color: #fff;
            }

            .breadcrumb {
                background-color: transparent;
                padding-left: 0;
                font-size: 18px;
                font-weight: 600;
            }

            .breadcrumb-item a {
                color: #5A2D86; /* Purple */
            }

            .breadcrumb-item.active {
                color: #B3B6B7;
            }

            /* Responsive Design */
            @media (max-width: 768px) {
                th, td {
                    font-size: 16px;
                    padding: 15px;
                }

                .action-icons i {
                    font-size: 18px;
                }

                .card-header {
                    font-size: 20px;
                    padding: 15px;
                }

                .breadcrumb-item {
                    font-size: 16px;
                }
            }
        </style>
    </head>

    <body class="sb-nav-fixed">
        <?php include_once('includes/header.php'); ?>
        <div id="layoutSidenav">
            <?php include_once('includes/leftbar.php'); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4" style="font-size: 32px; font-weight: 700;">নতুন ফাইলের নাম সংযোজন</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="index.html">হোম পেজ</a></li>
                            <li class="breadcrumb-item active">নতুন ফাইলের নাম সংযোজন</li>
                        </ol>

                        <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                ফাইলের নামসমূহ
                            </div>
                            <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>ফাইলের নাম</th>
                                            <th>ফাইল তৈরী করার তারিখ</th>
                                            <th>কাজ</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $userid = $_SESSION["edmsid"];
                                        $query = mysqli_query($con, "select id,categoryName,creationDate from tblcategory where createdBy='$userid'");
                                        $cnt = 1;
                                        while ($row = mysqli_fetch_array($query)) {
                                        ?>
                                            <tr>
                                                <td><?php echo htmlentities($cnt); ?></td>
                                                <td><?php echo htmlentities($row['categoryName']); ?></td>
                                                <td><?php echo htmlentities($row['creationDate']); ?></td>
                                                <td>
                                                    <div class="action-icons">
                                                        <a href="edit-category.php?id=<?php echo $row['id'] ?>"><i class="fas fa-edit"></i></a>
                                                        <a href="manage-categories.php?id=<?php echo $row['id'] ?>&del=delete" onClick="return confirm('আপনি কি ডাটা মুছে ফেলতে চান?')"><i class="fa fa-trash" aria-hidden="true"></i></a>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php $cnt = $cnt + 1; } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
                <?php include_once('includes/footer.php'); ?>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>

    </html>
<?php } ?>
