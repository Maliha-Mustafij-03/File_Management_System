<?php
session_start();
include_once('includes/config.php');

if(strlen($_SESSION["edmsid"]) == 0) {   
    header('location:logout.php');
} else {
    // For deleting    
    if(isset($_GET['del'])) {
        $nid = $_GET['id'];
        $department_id = $_SESSION["department_id"];
        $sub_department_id = $_SESSION["sub_department_id"];
        mysqli_query($con,"delete from tblnotes where id ='$nid' and department_id='$department_id' and sub_department_id='$sub_department_id'");
        mysqli_query($con,"delete from tblnoteshistory where noteId ='$nid' and department_id='$department_id' and sub_department_id='$sub_department_id'");
        echo "<script>alert('তথ্যটি মুছে গেছে।');</script>";
        echo "<script>window.location.href='manage-notes.php'</script>";
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>ই-ডাটা</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        /* Folder-style */
        .folder-item {
            cursor: pointer;
            background-color: #f7f7f7;
            color: #333;
            padding: 25px;
            margin: 20px;
            border-radius: 10px;
            font-weight: bold;
            display: inline-block;
            width: 160px;
            text-align: center;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.15);
            transition: all 0.3s ease-in-out;
            position: relative;
            overflow: hidden;
            border: 2px solid #ccc;
        }

        .folder-item:hover {
            background-color: #e1e1e1;
            box-shadow: 0 8px 18px rgba(0, 0, 0, 0.25);
            transform: translateY(-5px);
        }

        .folder-icon {
            font-size: 70px;
            margin-bottom: 20px;
            color: #007bff;
            position: relative;
            z-index: 1;
        }

        .folder-name {
            font-size: 18px;
            font-weight: bold;
            color: #333;
            text-transform: uppercase;
            margin-top: 10px;
        }

        /* Modal Styling */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            padding-top: 0;
            cursor: default;
        }

        .modal-content {
            background-color: #fff;
            margin: 50px auto;
            padding: 20px;
            width: 90%;
            max-width: 1200px;
            border-radius: 10px;
            overflow: hidden;
            position: relative;
        }

        .close {
            color: #aaa;
            font-size: 40px;
            font-weight: bold;
            position: absolute;
            top: 10px;
            right: 20px;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        /* Date filter container */
        .date-filter-container {
            margin-bottom: 20px;
        }

        /* Filter button */
        .filter-btn {
            background-color: #007bff;
            color: white;
            padding: 5px 10px;
            border: none;
            cursor: pointer;
        }

        .filter-btn:hover {
            background-color: #0056b3;
        }

        /* Modal Table Styling */
        .modal-table {
            width: 100%;
            border-collapse: collapse;
        }

        .modal-table th, .modal-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        .modal-table th {
            background-color: #f1f1f1;
        }

        /* Styling for No Data Available */
        .no-data {
            text-align: center;
            padding: 20px;
            font-size: 18px;
            color: #666;
        }
    </style>
</head>
<body class="sb-nav-fixed">
    <?php include_once('includes/header.php'); ?>
    <div id="layoutSidenav">
        <?php include_once('includes/leftbar.php'); ?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">বিস্তারিত রেকর্ড</h1>
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item"><a href="index.html">হোমপেজ</a></li>
                        <li class="breadcrumb-item active">বিস্তারিত রেকর্ড</li>
                    </ol>
                    <div class="card mb-4">
                        <div class="card-header">
                            <i class="fas fa-table me-1"></i> রেকর্ড এর বিস্তারিত
                        </div>
                        <div class="card-body">
                            <!-- Category Filters (Folders) -->
                            <div>
                                <?php 
                                $department_id = $_SESSION["department_id"];
                                $sub_department_id = $_SESSION["sub_department_id"];
                                $categoryQuery = mysqli_query($con, "SELECT DISTINCT noteCategory FROM tblnotes WHERE department_id='$department_id' AND sub_department_id='$sub_department_id' LIMIT 2000000000");
                                while($categoryRow = mysqli_fetch_array($categoryQuery)) {
                                    $categoryName = $categoryRow['noteCategory'];
                                ?>
                                    <div class="folder-item" data-category="<?php echo htmlentities($categoryName); ?>">
                                        <div class="folder-icon">
                                            <i class="fas fa-folder"></i>
                                        </div>
                                        <div class="folder-name">
                                            <?php echo htmlentities($categoryName); ?>
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
            <?php include_once('includes/footer.php'); ?>
        </div>
    </div>

    <!-- Modal for showing filtered data -->
    <div id="dataModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            
            <div class="date-filter-container">
                <label for="filter">Filter by date:</label><br>
                <input type="radio" name="dateFilter" value="today" checked> Today
                <input type="radio" name="dateFilter" value="last7days"> Last 7 Days
                <input type="radio" name="dateFilter" value="next7days"> Next 7 Days
                <input type="radio" name="dateFilter" value="all"> All Data
            </div>

            <div id="modalData">
                <!-- Filtered data will be loaded here -->
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
    <script>
        $(document).ready(function() {
            var selectedCategory = '';
            var defaultFilter = 'last7days'; // Default filter: last 7 days

            // When a folder (category) is clicked
            $(".folder-item").click(function() {
                selectedCategory = $(this).data('category');
                
                // Show the modal with data for this category only
                showFilteredData(selectedCategory, defaultFilter);

                // Hide main table outside modal
                $(".table-container").hide();
                $("#dataModal").show();
                $("body").css("overflow", "hidden"); // Disable body scroll
                $("#layoutSidenav").hide(); // Hide the sidebar
            });

            // Close the modal
            $(".close").click(function() {
                $("#dataModal").hide();
                $(".table-container").show(); // Show the main table again
                $("body").css("overflow", "auto");
                $("#layoutSidenav").show();
            });

            // Function to show filtered data in the modal
            function showFilteredData(category, dateFilter) {
                $.ajax({
                    url: 'get_folder_data.php', // Fetch filtered data based on category and date
                    type: 'GET',
                    data: { 
                        category: category,
                        dateFilter: dateFilter 
                    },
                    success: function(data) {
                        if (data.trim() === "") {
                            $('#modalData').html('<div class="no-data">No data available for the selected filter.</div>');
                        } else {
                            $('#modalData').html('<table class="modal-table"><thead><tr><th>#</th><th>Title</th><th>Category</th><th>Date</th><th>Description</th><th>Created By</th><th>Actions</th></tr></thead><tbody>' + data + '</tbody></table>');
                        }
                    }
                });
            }

            // Date filtering inside the modal
            $("input[name='dateFilter']").change(function() {
                var selectedFilter = $("input[name='dateFilter']:checked").val();
                showFilteredData(selectedCategory, selectedFilter); // Re-load the filtered data based on selection
            });
        });
    </script>
</body>
</html>

<?php } ?>
