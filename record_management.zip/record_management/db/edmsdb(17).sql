-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Feb 12, 2025 at 09:29 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `edmsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `name`) VALUES
(1, 'PD'),
(2, 'APD(Ops)'),
(3, 'APD(Admin)');

-- --------------------------------------------------------

--
-- Table structure for table `sub_departments`
--

CREATE TABLE `sub_departments` (
  `id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sub_departments`
--

INSERT INTO `sub_departments` (`id`, `department_id`, `name`) VALUES
(1, 2, 'DPD(Personalization)'),
(2, 2, 'DPD(DBA)'),
(3, 3, 'DPD(Admin)'),
(4, 3, 'DPD(Asset)'),
(5, 3, 'DPD(Procurement)'),
(6, 1, 'DPD(Communication)'),
(7, 3, 'DPD(Finance)'),
(8, 1, 'DPD(Evaluation and Monitoring)'),
(9, 3, 'DPD(Security and Common Services)'),
(10, 2, 'DPD(ICT)'),
(11, 2, 'DPD(Software Management)'),
(12, 1, 'APD(Ops)'),
(13, 1, 'APD(Admin)'),
(14, 1, 'PD');

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

CREATE TABLE `tblcategory` (
  `id` int(11) NOT NULL,
  `categoryName` varchar(125) CHARACTER SET utf16 COLLATE utf16_general_ci DEFAULT NULL,
  `createdBy` int(5) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT current_timestamp(),
  `sub_department_id` int(11) DEFAULT NULL,
  `department_id` int(11) DEFAULT NULL,
  `sub_department` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`id`, `categoryName`, `createdBy`, `creationDate`, `sub_department_id`, `department_id`, `sub_department`) VALUES
(1, 'a', 22, '2025-02-05 13:23:37', 6, 1, NULL),
(2, 'r', 22, '2025-02-05 13:29:25', 6, 1, NULL),
(3, 'w', 22, '2025-02-05 13:38:29', 6, 1, NULL),
(4, 'abd', 22, '2025-02-05 13:51:02', 6, 1, NULL),
(5, 'dd', 22, '2025-02-05 14:30:25', 6, 1, NULL),
(6, 'sajeeb', 22, '2025-02-05 15:21:13', 6, 1, NULL),
(7, 'Al Noman', 22, '2025-02-05 15:28:24', 6, 1, NULL),
(8, 'test', 15, '2025-02-02 08:10:55', 8, 1, NULL),
(9, 't', 15, '2025-02-02 08:39:12', 2, 2, NULL),
(10, 'admin', 15, '2025-02-02 08:57:11', 3, 3, NULL),
(11, 'admin', 15, '2025-02-02 09:07:16', 3, 3, NULL),
(12, 'com', 15, '2025-02-02 09:32:44', 6, 1, NULL),
(13, 'Development', 15, '2025-02-02 09:38:33', 11, 2, NULL),
(14, 'cse', 15, '2025-02-02 09:46:32', 10, 2, NULL),
(15, 'as', 15, '2025-02-02 10:30:08', 4, 3, NULL),
(16, 'fin', 15, '2025-02-02 10:35:46', 7, 3, NULL),
(17, 'as', 15, '2025-02-02 10:36:41', 4, 3, NULL),
(18, 'Code is cute', 15, '2025-02-02 10:38:29', 9, 3, NULL),
(19, 'procure', 15, '2025-02-02 10:39:59', 5, 3, NULL),
(20, 'DBA', 15, '2025-02-02 11:33:16', 2, 2, NULL),
(21, 'evaluation', 2, '2025-02-03 01:52:23', 8, 1, NULL),
(22, 'tesg', 23, '2025-02-04 00:25:31', 8, 1, NULL),
(23, 'pd', 25, '2025-02-04 01:08:12', 14, 1, NULL),
(24, 'pd', 25, '2025-02-04 01:09:59', 8, 1, NULL),
(26, 'Noman', 22, '2025-02-04 22:23:21', 6, 1, NULL),
(27, 'News', 22, '2025-02-04 22:27:17', 6, 1, NULL),
(28, 'Newspaper', 22, '2025-02-04 22:51:25', 6, 1, NULL),
(29, 'aa', 22, '2025-02-04 22:54:05', 6, 1, NULL),
(30, 'aaa', 22, '2025-02-04 23:11:29', 6, 1, NULL),
(31, 'check', 22, '2025-02-04 23:17:12', 6, 1, NULL),
(32, 'ch', 22, '2025-02-04 23:25:23', 6, 1, NULL),
(33, 'manage', 22, '2025-02-04 23:34:26', 6, 1, NULL),
(34, 'soft', 20, '2025-02-05 15:42:08', 11, 2, NULL),
(35, 'Official', 22, '2025-02-06 06:00:34', 6, 1, NULL),
(36, 'File', 55, '2025-02-06 06:04:55', 2, 2, NULL),
(37, 'maliha1218', 22, '2025-02-06 09:44:19', 6, 1, NULL),
(38, 'mou56', 22, '2025-02-06 10:17:45', 6, 1, NULL);

--
-- Triggers `tblcategory`
--
DELIMITER $$
CREATE TRIGGER `update_noteCategory` AFTER UPDATE ON `tblcategory` FOR EACH ROW BEGIN
    UPDATE tblnotes 
    SET noteCategory = NEW.categoryName 
    WHERE department_id = NEW.department_id 
    AND sub_department_id = NEW.sub_department_id
    AND noteCategory = OLD.categoryName; -- Ensures only existing ones are updated
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tblfolders`
--

CREATE TABLE `tblfolders` (
  `id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `folder_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblnotes`
--

CREATE TABLE `tblnotes` (
  `id` int(11) NOT NULL,
  `cat_id` varchar(255) DEFAULT NULL,
  `noteCategory` varchar(255) NOT NULL,
  `noteTitle` varchar(255) DEFAULT NULL,
  `date` varchar(125) DEFAULT NULL,
  `noteDescription` mediumtext DEFAULT NULL,
  `createdBy` int(5) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT current_timestamp(),
  `filePath` varchar(255) DEFAULT NULL,
  `department_id` int(11) NOT NULL,
  `sub_department_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblnotes`
--

INSERT INTO `tblnotes` (`id`, `cat_id`, `noteCategory`, `noteTitle`, `date`, `noteDescription`, `createdBy`, `creationDate`, `filePath`, `department_id`, `sub_department_id`) VALUES
(6, '6', 'sajeeb', 'sajeeb title', '2025-02-05', 'sajeeb des', 22, '2025-02-05 15:21:35', NULL, 1, 6),
(8, '8', 'admin', 'যুক্তরাজ্যে দাসত্ব আইনে নিরাপত্তা চাইতে পারবেন না অভিবাসনপ্রত্যাশীরা', '2025-02-20', 'ব্রিটিশ প্রধানমন্ত্রী কিয়ার স্টারমারের সরকার অভিবাসনপ্রত্যাশীদের দাসত্বের নতুন ধরনসহ মানবাধিকার আইনের আওতায় নিরাপত্তা দেওয়া নিষিদ্ধ করে রাখতে চায়। দেশটির কয়েকজন মন্ত্রী এই পদক্ষেপের সমালোচনা করেছেন, যা চাপে ফেলছে স্টারমার সরকারকে।\r\n\r\nগত বছরের জুলাই মাসে ক্ষমতায় আসে লেবার পার্টি। এর আগের কনজারভেটিভ সরকারের প্রস্তাব অনুযায়ী, তারাও এই বিশেষ নিষেধাজ্ঞা বহাল রাখবে। যে অভিবাসনপ্রত্যাশীদের যুক্তরাজ্য থেকে বের করে দেওয়া হতো, তাঁরা অনেক ক্ষেত্রে নব্য দাসত্ব আইনের আবহে নিরাপত্তা দাবি করতেন, যাতে তাঁদের যুক্তরাজ্য থেকে বহিষ্কার না করা যায়।', 15, '2025-02-02 08:59:50', 'uploads/1738508390_app2.png', 3, 3),
(9, '9', 'admin', 'দ্য নিউইয়র্ক টাইমসসহ চার গণমাধ্যমকে পেন্টাগন থেকে সরিয়ে দিচ্ছেন ট্রাম্প', '2025-02-15', 'যুক্তরাষ্ট্রের প্রতিরক্ষা সদর দপ্তর পেন্টাগন থেকে দ্য নিউইয়র্ক টাইমসসহ চারটি গণমাধ্যমের কার্যালয় সরিয়ে দিচ্ছে প্রেসিডেন্ট ডোনাল্ড ট্রাম্পের প্রশাসন। প্রতিষ্ঠানগুলোর জন্য বরাদ্দকৃত এসব জায়গায় অন্যদের স্থান দেওয়া হবে।\r\n\r\nগত শুক্রবার দিনের শেষে এ সিদ্ধান্ত ঘোষণা করা হয়েছে। নজিরবিহীন এ পদক্ষেপ গ্রহণ করার পেছনে যুক্তি হিসেবে অন্যদের জায়গা বরাদ্দের চাহিদার কথা উল্লেখ করা হয়।\r\n\r\n‘নিউ অ্যানুয়াল মিডিয়া রোটেশন প্রোগ্রাম’ নিয়ে একটি নথিতে এ বিষয়ে বলা হয়েছে, দ্য নিউইয়র্ক টাইমস ছাড়াও ন্যাশনাল পাবলিক রেডিও (এনপিআর), কমক্যাস্ট করপোরেশনের মালিকানাধীন এনবিসি নিউজ এবং পলিটিকো—এ তিন গণমাধ্যমকে পেন্টাগন থেকে সরিয়ে দেবে ট্রাম্প প্রশাসন। প্রতিষ্ঠানগুলোকে অবশ্যই ১৪ ফেব্রুয়ারির মধ্যে তাদের জায়গা ছেড়ে দিতে হবে।\r\n\r\nএই গণমাধ্যমগুলোর পরিবর্তে পেন্টাগনে কার্যালয় খোলার জায়গা পাবে নিউইয়র্ক পোস্ট, ওয়ান আমেরিকা নিউজ নেটওয়ার্ক, ব্রেইটবার্ট নিউজ নেটওয়ার্ক ও হাফপোস্ট নিউজ।\r\n\r\nট্রাম্প প্রশাসনের ঘোষণার প্রতিক্রিয়ায় এনবিসি নিউজের একজন মুখপাত্র ই–মেইলে বলেছেন, ‘কয়েক দশক ধরে আমরা পেন্টাগন থেকে খবর সম্প্রচার করছি। এখন সেই সম্প্রচার বুথে আমাদের প্রবেশের সুযোগ বাতিল করার এ সিদ্ধান্তে আমরা হতাশ।’\r\n\r\nএই মুখপাত্র আরও বলেন, ‘এ সিদ্ধান্ত জাতীয় জনস্বার্থ–সংশ্লিষ্ট খবর সংগ্রহ ও সম্প্রচারে আমাদের সক্ষমতায় বড় ধরনের প্রতিবন্ধকতা তৈরি করবে। তা সত্ত্বেও আমরা যে সততা ও দৃঢ়তাকে ধারণ করে সব সময় প্রতিবেদন করে গেছি, সামনের দিনগুলোতেও তা সেভাবেই অব্যাহত রাখব।’', 15, '2025-02-02 09:08:26', 'uploads/1738508906_Abdulla_Al_Noman - Copy.pptx', 3, 3),
(11, '11', 'com', 'Communication-13', '2025-02-02', 'com-11', 15, '2025-02-02 09:37:49', 'uploads/1738510669_app4.png', 1, 6),
(12, '12', 'cse', 'cse-gh', '2025-02-02', 'cse-eee', 15, '2025-02-02 09:47:05', 'uploads/1738511225_cms8.png', 2, 10),
(13, '13', 'cse-DBA', 'cse-gh', '2025-02-02', 'cse-eee', 15, '2025-02-02 09:47:05', 'uploads/1738511225_cms8.png', 2, 2),
(14, '14', 'TEST', 'cse-gh', '2025-02-02', 'cse-eee', 15, '2025-02-02 09:47:05', 'uploads/1738511225_cms8.png', 1, 8),
(15, '15', 'TEST ict', 'cse-gh', '2025-02-02', 'cse-eee', 15, '2025-02-02 09:47:05', 'uploads/1738511225_cms8.png', 2, 10),
(16, '16', 'cse-DBA', 'noman', '2025-02-21', 'abdulla', 15, '2025-02-02 10:19:36', 'uploads/1738513176_app3.png', 2, 2),
(17, '17', 'as', 'as-1', '2025-02-21', 'as-4', 15, '2025-02-02 10:30:39', 'uploads/1738513839_app11.png', 3, 4),
(18, '18', 'fin', 'fin-1', '2025-03-07', 'fin-4', 15, '2025-02-02 10:36:14', 'uploads/1738514174_cms3.png', 3, 7),
(19, '19', 'as', 'noman', '2025-02-13', 'sumon', 15, '2025-02-02 10:37:14', 'uploads/1738514234_pro2.png', 3, 4),
(20, '20', 'Code is cute', 'Programming', '2025-02-19', 'logic', 15, '2025-02-02 10:39:27', 'uploads/1738514367_PMA_Software.pptx', 3, 9),
(21, '21', 'procure', 'test-procurement', '2025-02-02', 'test-procurement', 15, '2025-02-02 10:40:33', 'uploads/1738514433_pro4.png', 3, 5),
(22, '22', 'DBA', 'Introduction of DBMS (Database Management System)', '2025-02-19', 'A Database Management System (DBMS) is a software solution designed to efficiently manage, organize, and retrieve data in a structured manner. It serves as a critical component in modern computing, enabling organizations to store, manipulate, and secure their data effectively. From small applications to enterprise systems, DBMS plays a vital role in supporting data-driven decision-making and operational efficiency.\r\n\r\nIn this article, we will explain the key concepts, benefits, and types of Database Management Systems (DBMS). We’ll also cover how DBMS solutions work, why they’re important for modern applications, and what features they offer to ensure data integrity, security, and efficient retrieval.', 15, '2025-02-02 11:34:37', 'uploads/1738517677_cms5.png', 2, 2),
(23, '23', 'evaluation', 'evaluation-1', '2025-02-03', 'evaluation-2', 2, '2025-02-03 01:53:10', 'uploads/1738569190_app11.png', 1, 8),
(24, '24', 'tesg', 'eee', '2025-02-04', 'ttt', 23, '2025-02-04 00:26:12', 'uploads/1738650372_app3.png', 1, 8),
(26, '26', 'pd', 'pd-1', '2025-02-19', 'pd', 25, '2025-02-04 01:10:25', 'uploads/1738653025_app2.png', 1, 8),
(27, '13', 'Development', 'as', '2025-02-21', 'fgh', 20, '2025-02-05 15:42:36', NULL, 2, 11),
(28, '34', 'soft', 'Allah is kind', '2025-02-28', 'fgtr', 20, '2025-02-05 15:43:34', NULL, 2, 11),
(29, '35', 'Official', 'Code is Cute', '2025-02-27', 'Logic development', 22, '2025-02-06 06:01:39', NULL, 1, 6),
(30, '36', 'File', 'File management refers to the systematic organization', '2025-02-06', 'File management refers to the systematic organization, storage, and retrieval of digital files. It plays a crucial role in maintaining an efficient workflow and ensuring data integrity, security, and accessibility. In the context of businesses and organizations, file management involves categorizing and labeling files in a way that facilitates quick search and retrieval.\r\n\r\nEffective file management starts with a well-defined directory structure. This involves organizing files into logical folders and subfolders, often based on categories such as project names, departments, or file types. Naming conventions also play a key role in ensuring consistency and ease of searching. Files should be named clearly, avoiding special characters, and should include relevant information such as the project, date, or version number.', 55, '2025-02-06 06:08:14', NULL, 2, 2),
(31, '37', 'maliha1218', 'maliha1218', '2025-02-06', 'rrrr', 22, '2025-02-06 09:45:11', NULL, 1, 6),
(32, NULL, '31', 'ttt', '2025-02-06', 'dasda', 22, '2025-02-06 09:56:58', NULL, 1, 6),
(33, '38', 'mou56', '1111', '2025-02-05', 'tttt', 22, '2025-02-06 10:18:21', NULL, 1, 6),
(34, '32', 'ch', 'ertre', '2025-02-01', 'tretre', 22, '2025-02-06 10:21:13', 'uploads/WhatsApp Image 2024-08-28 at 10.49.07 AM.jpeg', 1, 6),
(35, '26', 'Noman', 'noman', '2025-02-06', 'noman', 22, '2025-02-06 10:23:00', 'uploads/PDFMailer (3).pdf', 1, 6);

-- --------------------------------------------------------

--
-- Table structure for table `tblnoteshistory`
--

CREATE TABLE `tblnoteshistory` (
  `id` int(11) NOT NULL,
  `noteId` int(11) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `noteDetails` mediumtext DEFAULT NULL,
  `postingDate` timestamp NULL DEFAULT current_timestamp(),
  `filePath` varchar(255) DEFAULT NULL,
  `department_id` int(11) NOT NULL,
  `sub_department_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblnoteshistory`
--

INSERT INTO `tblnoteshistory` (`id`, `noteId`, `userId`, `noteDetails`, `postingDate`, `filePath`, `department_id`, `sub_department_id`) VALUES
(3, 2, 1, 'Note Details. Note DetailsNote DetailsNote DetailsNote DetailsNote DetailsNote DetailsNote DetailsNote DetailsNote DetailsNote DetailsNote DetailsNote DetailsNote DetailsNote DetailsNote DetailsNote Details', '2022-04-03 07:21:09', NULL, 0, 0),
(5, 3, 1, 'This is for testing.This is for testing.This is for testing.This is for testing.This is for testing.This is for testing.This is for testing.This is for testing.This is for testing.This is for testing.This is for testing.This is for testing.This is for testing.This is for testing.This is for testing.This is for testing.This is for testing.This is for testing.This is for testing.This is for testing.', '2022-04-03 07:23:26', NULL, 0, 0),
(13, 6, 2, 'dsfdsfdff', '2025-02-03 03:15:46', NULL, 0, 0),
(14, 6, 2, 'zdffgdf', '2025-02-03 03:16:55', NULL, 0, 0),
(22, 11, NULL, 'gg', '2025-02-04 10:26:11', NULL, 1, 6);

-- --------------------------------------------------------

--
-- Table structure for table `tblregistration`
--

CREATE TABLE `tblregistration` (
  `id` int(11) NOT NULL,
  `firstName` varchar(150) DEFAULT NULL,
  `lastName` varchar(150) DEFAULT NULL,
  `emailId` varchar(150) DEFAULT NULL,
  `mobileNumber` bigint(30) DEFAULT NULL,
  `userPassword` varchar(255) DEFAULT NULL,
  `regDate` timestamp NULL DEFAULT current_timestamp(),
  `department_id` int(11) NOT NULL,
  `sub_department_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblregistration`
--

INSERT INTO `tblregistration` (`id`, `firstName`, `lastName`, `emailId`, `mobileNumber`, `userPassword`, `regDate`, `department_id`, `sub_department_id`) VALUES
(1, 'Anuj', 'kumar', 'ak@gmail.com', 1425362514, 'f925916e2754e5e03f75dd58a5733251', '2022-04-02 12:17:37', 0, 0),
(2, 'Ali Hasan', 'Khan', 'a@gmail.com', 111, '698d51a19d8a121ce581499d7b701668', '2022-04-03 09:51:23', 0, 0),
(3, 'maliha', 'mustafij', 'maliha1218@gmail.com', 1684422703, '81dc9bdb52d04dc20036dbd8313ed055', '2023-09-21 07:11:57', 0, 0),
(4, 'test', 'test', 'test@gmail.com', 0, '698d51a19d8a121ce581499d7b701668', '2025-01-23 05:57:59', 0, 0),
(5, 'mm', 'mm', 'm@gmail.com', 123456789, 'b3cd915d758008bd19d0f2428fbb354a', '2025-01-27 03:12:32', 2, 2),
(6, 'mm', 'mm', 'm@gmail.com', 123456789, 'b3cd915d758008bd19d0f2428fbb354a', '2025-01-27 03:14:37', 2, 2),
(7, 'mm', 'mm', 'm@gmail.com', 123456789, 'b3cd915d758008bd19d0f2428fbb354a', '2025-01-27 03:16:53', 2, 2),
(8, 'MD', 'SHAHABUDDIN', 'shahabuddin.scs@gmail.com', 1713484379, 'c20ad4d76fe97759aa27a0c99bff6710', '2025-01-27 03:28:08', 1, 3),
(9, 'T', 'T', 't@gmail.com', 123, '698d51a19d8a121ce581499d7b701668', '2025-01-27 03:29:46', 1, 7),
(10, 'ma', 'ma', 'ma@gmail.com', 1684422703, '$2y$10$ZP9V0jjfx/1GDtzjSPwYH.CrwF7RspTmv7CqugqK9ZP1tBUQ2Zuzu', '2025-01-28 03:14:09', 1, 6),
(11, 'moutushi', 'moutushi', 'moutushi@gmail.com', 1684422703, 'fcea920f7412b5da7be0cf42b8c93759', '2025-01-28 03:16:31', 2, 2),
(12, 'himel', 'vai', 'himel@gmail.com', 1684422705, 'fcea920f7412b5da7be0cf42b8c93759', '2025-01-28 03:27:24', 3, 9),
(13, 'zohir', 'alo', 'alo@gmail.com', 1684422709, '01cfcd4f6b8770febfb40cb906715822', '2025-01-28 03:30:31', 3, 7),
(14, 'tr', 'trr', 'trr@gmail.com', 1684422999, 'a971658e3a70c1f39e66c3b07efc5872', '2025-01-28 03:44:22', 2, 2),
(15, 'Rinky', 'Apu', 'rinky@gmail.com', 1195113230, '827ccb0eea8a706c4c34a16891f84e7b', '2025-01-28 04:11:27', 2, 2),
(16, 'aa', 'pd-1', 'pd@gmail.com', 1165113230, '37f1fc6cee7436912b393ddf539a1888', '2025-01-28 04:43:43', 1, 6),
(17, 'pro', 'pro-1', 'pro@gmail.com', 1165113230, 'a4f64d2ebd09667c12c31138a45a5dd5', '2025-01-28 05:23:58', 3, 5),
(18, 'dba', 'pd-1', 'ict@gmail.com', 9876545671, '1db6543d7501c27c865bede2b3df24b0', '2025-01-28 05:26:54', 2, 10),
(19, 'dd', 'bb', 'comm@gmail.com', 1234545432, 'd64910715d567b6e63e1c0c7d4564c78', '2025-01-29 09:31:52', 1, 6),
(20, 'soft', 'dd', 'soft@gmail.com', 1195113230, '78969c8101f013f659833943f2c4b910', '2025-01-29 17:08:22', 2, 11),
(21, 'adt', 'adt', 'adt@gmail.com', 9876545671, 'ad92fae524df3eafcd2aef9a305a90a4', '2025-02-04 05:47:44', 3, 3),
(22, 'c', 'vv', 'com1@gmail.com', 1234545432, '8f760e1ccf1e71663931a9e30bafad34', '2025-02-04 06:19:22', 1, 6),
(23, 'evaluation', 'sdfd', 'evaluation@gmail.com', 1195113230, '863988c83a3d27d6aff7a0013f9cacfa', '2025-02-04 06:20:46', 1, 8),
(24, 'evvv', 'evvv', 'evvv@gmail.com', 444444, '403bb23c7152062e01a1fcd706d83e58', '2025-02-04 06:27:20', 1, 8),
(25, 'DF', 'FG', 'pd1@gmail.com', 9876545671, '1ce3a93c22c9c2b9e1e303df9e140c55', '2025-02-04 07:02:43', 1, 14),
(26, 'aa', 'bb', 'sumon@gmail.com', 1234545432, 'd09c2706e819b25ad98970cb513fb83e', '2025-02-04 07:11:10', 1, 14),
(27, 'security', 'security', 'security@gmail.com', 6576786586, 'b3a02e39ee2d4fb572054b36dffaff1e', '2025-02-04 09:32:50', 1, 14),
(28, 'de', 'de', 'de@gmail.com', 2456657467, '5f02f0889301fd7be1ac972c11bf3e7d', '2025-02-04 09:43:31', 1, 14),
(55, 'Abdulla Al', 'Noman', 'noman@gmail.com', 1195113230, '827ccb0eea8a706c4c34a16891f84e7b', '2025-02-06 06:03:25', 2, 2),
(56, 'dba', 'dba1', 'db@gmail.com', 5666576767867, '0d1f9600dd82e5c5793a8a9d7e3bb295', '2025-02-12 03:23:19', 2, 2),
(57, 'rinki', 'rinki', 'rinki@gmail.com', 23645666653765, '515357efc8d02479a60f3d2ecf903d3d', '2025-02-12 03:51:33', 2, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sub_departments`
--
ALTER TABLE `sub_departments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department_id` (`department_id`);

--
-- Indexes for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sub_category_id` (`sub_department_id`),
  ADD KEY `department_id` (`department_id`),
  ADD KEY `sub_department_id` (`sub_department`);

--
-- Indexes for table `tblfolders`
--
ALTER TABLE `tblfolders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblnotes`
--
ALTER TABLE `tblnotes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department_id` (`department_id`),
  ADD KEY `sub_department_id` (`sub_department_id`);

--
-- Indexes for table `tblnoteshistory`
--
ALTER TABLE `tblnoteshistory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblregistration`
--
ALTER TABLE `tblregistration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblcategory`
--
ALTER TABLE `tblcategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `tblnotes`
--
ALTER TABLE `tblnotes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `tblnoteshistory`
--
ALTER TABLE `tblnoteshistory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tblregistration`
--
ALTER TABLE `tblregistration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
