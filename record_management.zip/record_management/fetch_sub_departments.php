<?php
$conn = new mysqli('localhost', 'root', '', 'edmsdb');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$department_id = $_GET['department_id'];

$query = "SELECT * FROM sub_departments WHERE department_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $department_id);
$stmt->execute();
$result = $stmt->get_result();

$sub_departments = [];
while ($row = $result->fetch_assoc()) {
    $sub_departments[] = $row;
}

echo json_encode($sub_departments);
?>
