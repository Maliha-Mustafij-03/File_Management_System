<?php
include_once('includes/config.php');

// Get department and sub-department IDs from the URL
$dept_id = isset($_GET['dept_id']) ? $_GET['dept_id'] : '';
$sub_dept_id = isset($_GET['sub_dept_id']) ? $_GET['sub_dept_id'] : '';

// Query to fetch categories based on department and sub-department
$query = "SELECT id, categoryName FROM tblcategory WHERE department_id = '$dept_id' AND sub_department_id = '$sub_dept_id'";
$result = mysqli_query($con, $query);

// Check if there are any categories
$categories = [];
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $categories[] = $row;
    }
}

// Return categories as JSON
echo json_encode($categories);
?>
