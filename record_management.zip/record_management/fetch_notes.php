<?php
include_once('includes/config.php');

// Fetch department_id and sub_department_id from URL
$department_id = $_GET['department_id'] ?? null;
$sub_department_id = $_GET['sub_department_id'] ?? null;

if (!$department_id || !$sub_department_id) {
    echo "<p style='color: red; font-weight: bold; text-align: center;'>Invalid request. Department or Sub-department not specified.</p>";
    exit;
}

// Fetch search option from URL
$search_option = $_GET['search_option'] ?? 'all';
$category = $_GET['category'] ?? null;

// Pagination setup
$limit = 10; // Number of notes per page
$page = isset($_GET['page']) ? $_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Filter query based on selected search option
if ($search_option === 'today') {
    $date_condition = "AND date = CURDATE()";
} elseif ($search_option === '7_days') {
    $date_condition = "AND date BETWEEN CURDATE() - INTERVAL 7 DAY AND CURDATE()";
} elseif ($search_option === 'next_7_days') {
    $date_condition = "AND date BETWEEN CURDATE() AND CURDATE() + INTERVAL 7 DAY";
} else {
    $date_condition = ''; // No filter for 'all'
}

if (!$category) {
    // Fetch categories if category is not set
    $query = "SELECT DISTINCT noteCategory FROM tblnotes WHERE department_id = ? AND sub_department_id = ?";
    $stmt = $con->prepare($query);
    $stmt->bind_param("ii", $department_id, $sub_department_id);
    $stmt->execute();
    $categories = $stmt->get_result();
} else {
    // Fetch notes if a category is clicked
    $query = "SELECT noteTitle, noteDescription, date, filePath FROM tblnotes WHERE department_id = ? AND sub_department_id = ? AND noteCategory = ? $date_condition LIMIT ?, ?";
    $stmt = $con->prepare($query);
    $stmt->bind_param("iisii", $department_id, $sub_department_id, $category, $offset, $limit);
    $stmt->execute();
    $notes_result = $stmt->get_result();

    // Count total rows for pagination
    $count_query = "SELECT COUNT(*) AS total FROM tblnotes WHERE department_id = ? AND sub_department_id = ? AND noteCategory = ? $date_condition";
    $count_stmt = $con->prepare($count_query);
    $count_stmt->bind_param("iis", $department_id, $sub_department_id, $category);
    $count_stmt->execute();
    $count_result = $count_stmt->get_result();
    $total_rows = $count_result->fetch_assoc()['total'];
    $total_pages = ceil($total_rows / $limit);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notes</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        /* Basic Styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 20px;
            text-align: center;
        }

        .container {
            width: 90%;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px #2c3e50;
        }

        h2,
        h3 {
            color: #2d572c;
            font-size: 24px;
            font-weight: 700;
            letter-spacing: 1px;
            margin-bottom: 20px;
        }

        .folder {
            background: linear-gradient(145deg, rgb(191, 174, 112), rgb(141, 171, 144));
            color: rgb(18, 98, 27);
            padding: 20px;
            margin: 15px;
            display: inline-block;
            border-radius: 12px;
            cursor: pointer;
            text-align: center;
            width: 140px;
            height: 120px;
            transition: background-color 0.3s, transform 0.3s, box-shadow 0.3s;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            position: relative;
        }

        .folder:hover {
            background: linear-gradient(145deg, #f8f8f8, #ffffff);
            transform: scale(1.05);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.2);
        }

        .folder-title {
            font-size: 14px;
            text-align: center;
            margin-top: 10px;
            font-weight: bold;
            color: rgb(18, 98, 27);
            letter-spacing: 1px;
        }

        .folder .folder-icon {
            font-size: 20px;
            display: block;
            margin-bottom: 10px;
            text-align: center;
        }

        /* Popup Close Button */
        .popup-close {
            background: red;
            color: white;
            padding: 8px;
            border: none;
            cursor: pointer;
            float: right;
            font-size: 18px;
        }

        .popup-close:hover {
            background: darkred;
        }

        /* Table Styles */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            padding: 12px;
            text-align: left;
            border: 1px solid #bdc3c7;
        }

        th {
            background-color: #ecf0f1;
            color: #2c3e50;
        }

        td {
            background-color: #ffffff;
            color: #34495e;
        }

        .download-btn {
            padding: 10px 15px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }

        .download-btn:hover {
            background-color: #2980b9;
        }

        /* Pagination Styles */
        .pagination {
            margin-top: 20px;
            display: flex;
            justify-content: center;
        }

        .pagination a {
            padding: 8px 16px;
            background-color: #3498db;
            color: white;
            text-decoration: none;
            margin: 0 5px;
            border-radius: 5px;
        }

        .pagination a:hover {
            background-color: #2980b9;
        }

        .no-data-message {
            color: #e74c3c;
            font-weight: bold;
        }
    </style>

    <style>
        /* Back to Dashboard Button (Right Side) */
        .back-to-dashboard {
            position: fixed;
            top: 50px;
            right: 120px;
            background-color: rgb(98, 121, 139);

            color: white;
            font-size: 12px;
            font-weight: 300;
            text-decoration: none;
            padding: 10px 15px;
            border-radius: 30px;
            box-shadow: 0 4px 6px rgba(55, 50, 50, 0.1);
            transition: background-color 0.3s, transform 0.3s;
            display: inline-block;
        }

        .back-to-dashboard:hover {
            background-color: rgb(171, 214, 168);
            transform: translateY(-2px);
        }

        .back-to-dashboard:active {
            background-color: #1f6b8c;
            transform: translateY(2px);
        }
    </style>


</head>

<body>
    <div class="container">



        <?php if (!$category): ?>
            <!-- Display Categories if no category is clicked yet -->
            <h3>Select a Folder to View Documents</h3>
            <a href="dashboard.php" class="back-to-dashboard">Go Dashboard</a>
            <?php if ($categories->num_rows > 0): ?>
                <?php while ($row = $categories->fetch_assoc()) { ?>
                    <div class="folder" onclick="window.location.href='fetch_notes.php?department_id=<?= $department_id ?>&sub_department_id=<?= $sub_department_id ?>&category=<?= urlencode($row['noteCategory']) ?>'">
                        <span class="folder-icon"><i class="fas fa-folder"></i></span>
                        <span class="folder-title"><?= htmlspecialchars($row['noteCategory']) ?></span>
                    </div>
                <?php } ?>
            <?php else: ?>
                <h2 class="no-data-message">No categories found!</h2>
            <?php endif; ?>
        <?php else: ?>

            <!-- Close Button to go back to folders -->
            <button class="popup-close" onclick="window.location.href='fetch_notes.php?department_id=<?= $department_id ?>&sub_department_id=<?= $sub_department_id ?>'">X</button>

            <!-- Search Bar for Selecting Date Range -->
            <div class="search-bar">
                <form method="get" action="fetch_notes.php">
                    <input type="hidden" name="department_id" value="<?= $department_id ?>">
                    <input type="hidden" name="sub_department_id" value="<?= $sub_department_id ?>">
                    <input type="hidden" name="category" value="<?= urlencode($category) ?>">

                    <select name="search_option" onchange="this.form.submit()">
                        <option value="all" <?= $search_option === 'all' ? 'selected' : '' ?>>All Data</option>
                        <option value="today" <?= $search_option === 'today' ? 'selected' : '' ?>>Today</option>
                        <option value="7_days" <?= $search_option === '7_days' ? 'selected' : '' ?>>Last 7 Days</option>
                        <option value="next_7_days" <?= $search_option === 'next_7_days' ? 'selected' : '' ?>>Next 7 Days</option>
                    </select>
                </form>
            </div>

            <!-- Display Notes -->
            <?php if ($notes_result->num_rows > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Date</th>
                            <th>Download</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $notes_result->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['noteTitle']) ?></td>
                                <td><?= htmlspecialchars($row['noteDescription']) ?></td>
                                <td><?= date('d-m-Y', strtotime($row['date'])) ?></td>
<td>
                                    <?php if (!empty($row['filePath'])): ?>
                                        <a href="<?= htmlspecialchars($row['filePath']) ?>" target="_blank" class="download-btn">Download</a>
                                    <?php else: ?>
                                        No file available
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>

                <!-- Pagination Controls -->
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="fetch_notes.php?department_id=<?= $department_id ?>&sub_department_id=<?= $sub_department_id ?>&category=<?= urlencode($category) ?>&page=<?= $page - 1 ?>&search_option=<?= $search_option ?>">Previous</a>
                    <?php endif; ?>
                    <?php if ($page < $total_pages): ?>
                        <a href="fetch_notes.php?department_id=<?= $department_id ?>&sub_department_id=<?= $sub_department_id ?>&category=<?= urlencode($category) ?>&page=<?= $page + 1 ?>&search_option=<?= $search_option ?>">Next</a>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <p class="no-data-message">No notes found for the selected category.</p>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</body>

</html>