<?php
session_start();
include_once('includes/config.php');

if (!isset($_SESSION["edmsid"]) || strlen($_SESSION["edmsid"]) == 0) {
    header('location:logout.php');
    exit();
}

if (!isset($_GET['categoryName'])) {
    echo "Invalid category!";
    exit();
}

$categoryId = intval($_GET['category_id']);
?>

<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="utf-8" />
    <title>নোট সমূহ</title>
</head>
<body>
    <h2>নোট তালিকা</h2>
    <ul>
        <?php
        $query = $con->prepare("SELECT id, noteTitle FROM tblnotes WHERE noteCategory = ?");
        $query->bind_param("i", $categoryId);
        $query->execute();
        $result = $query->get_result();

        while ($row = $result->fetch_assoc()) {
            echo "<li><a href='view-note.php?id=" . $row['id'] . "'>" . htmlentities($row['noteTitle']) . "</a></li>";
        }
        ?>
    </ul>
</body>
</html>
