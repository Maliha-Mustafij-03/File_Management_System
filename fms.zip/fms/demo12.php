<?php
session_start();
include_once('includes/config.php');

// Fetch department and sub-department data after login
if (isset($_SESSION['edmsid'])) {
    $department_id = $_SESSION['department_id'];
    $sub_department_id = $_SESSION['sub_department_id'];
}
?>

<!DOCTYPE html>
<html lang="bn">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project Organogram</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            background-color: #ffffff; /* White background for a clean, professional look */
            color: #2c3e50; /* Darker text color for better readability */
            font-family: 'Helvetica Neue', Arial, sans-serif; /* Sleek and modern font */
            text-align: center;
            margin: 0;
            padding: 0;
        }

        h1 {
            background-color: #34495e; /* Dark blue background */
            color: white;
            padding: 20px;
            font-size: 2.5em;
            margin-bottom: 20px;
            font-weight: bold;
            border-radius: 5px;
        }

        .chart {
            display: flex;
            flex-direction: column;
            align-items: center;
            position: relative;
            padding: 20px;
        }

        .box {
            background-color: #3b7a57; /* A rich green for active buttons */
            padding: 15px 25px;
            margin: 10px;
            border-radius: 8px;
            display: inline-block;
            color: white;
            font-weight: bold;
            border: 2px solid #2c3e50;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.2s ease;
        }

        .sub-box {
            background-color: #d3e0dc; /* Light grey for sub-boxes */
            color: #2c3e50;
            border: 2px solid #95a5a6;
            padding: 10px 20px;
            margin: 10px;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.2s ease;
        }

        .box:hover,
        .sub-box:hover {
            background-color: #2e9d49; /* Lighter green on hover */
            transform: scale(1.05); /* Slightly enlarges the button on hover */
        }

        .line {
            width: 2px;
            height: 50px;
            background-color: #34495e; /* Dark grey for lines */
            margin: 10px auto;
        }

        .horizontal-line {
            width: 100px;
            height: 2px;
            background-color: #34495e;
            margin: 10px auto;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
        }

        .container div {
            flex: 1;
            min-width: 180px;
            margin: 15px;
            display: flex;
            justify-content: center;
        }

        .popup {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 70%;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.2);
            z-index: 1000;
            text-align: left;
            color: #2c3e50;
            font-size: 16px;
        }

        .popup h2 {
            font-size: 18px;
            margin-bottom: 15px;
            font-weight: bold;
        }

        .popup-close {
            background: #e74c3c; /* Red for close button */
            color: white;
            padding: 8px;
            border: none;
            cursor: pointer;
            float: right;
            font-weight: bold;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .popup-close:hover {
            background: #c0392b; /* Darker red on hover */
        }

        .inactive {
            background-color: #bdc3c7; /* Grey color for inactive buttons */
            color: #7f8c8d; /* Lighter text color */
            border-color: #95a5a6; /* Slightly darker border */
            cursor: not-allowed; /* Indicating that the button is disabled */
            opacity: 0.6; /* Slightly faded for a disabled look */
        }

        @media screen and (max-width: 768px) {
            .container {
                flex-direction: column; /* Stack the boxes vertically on smaller screens */
            }
        }
    </style>
</head>

<body>
    <h1>Project Organogram</h1>
    <div class="chart">
        <!-- PD Box -->
        <div class="box <?php echo ($department_id == 1 && $sub_department_id == 14) ? 'active' : 'inactive'; ?>"
            onclick="toggleSubMenu('director', this)">PD</div>

        <div class="line"></div>

        <div class="container">
            <!-- APD OPS and ADMIN -->
            <div class="box <?php echo ($department_id == 1 && $sub_department_id == 14) || ($department_id == 1 && $sub_department_id == 12) ? 'active' : 'inactive'; ?>"
                onclick="toggleSubMenu('operations', this)">APD (OPS)</div>
            <div class="horizontal-line"></div>

            <div class="box <?php echo ($department_id == 1 && $sub_department_id == 14) || ($department_id == 1 && $sub_department_id == 13) ? 'active' : 'inactive'; ?>"
                onclick="toggleSubMenu('admin_finance', this)">APD (ADMIN)</div>
        </div>

        <div class="line"></div>

        <div class="container">
            <!-- DPD Communication and Evaluation -->
            <div class="box <?php echo ($department_id == 1 && $sub_department_id == 14) || ($department_id == 1 && $sub_department_id == 6) ? 'active' : 'inactive'; ?>"
                onclick="fetchNotes(1, 6)">DPD (Communication)</div>
            <div class="horizontal-line"></div>

            <div class="box <?php echo ($department_id == 1 && $sub_department_id == 14) || ($department_id == 1 && $sub_department_id == 8) ? 'active' : 'inactive'; ?>"
                onclick="fetchNotes(1, 8)">DPD (Evaluation and Monitoring)</div>
        </div>

        <div class="line"></div>

        <div class="container">
            <!-- DPD Personalization, DBA, ICT, etc. -->
            <div class="box <?php echo ($department_id == 1 && $sub_department_id == 14) || ($department_id == 2 && $sub_department_id == 1) ? 'active' : 'inactive'; ?>"
                onclick="fetchNotes(2, 1)">DPD (Personalization)</div>
            <div class="box <?php echo ($department_id == 1 && $sub_department_id == 14) || ($department_id == 2 && $sub_department_id == 2) ? 'active' : 'inactive'; ?>"
                onclick="fetchNotes(2, 2)">DPD (DBA)</div>
            <div class="box <?php echo ($department_id == 1 && $sub_department_id == 14) || ($department_id == 2 && $sub_department_id == 10) ? 'active' : 'inactive'; ?>"
                onclick="fetchNotes(2, 10)">DPD (ICT)</div>
            <div class="box <?php echo ($department_id == 1 && $sub_department_id == 14) || ($department_id == 2 && $sub_department_id == 11) ? 'active' : 'inactive'; ?>"
                onclick="fetchNotes(2, 11)">DPD (Software Management)</div>
            <div class="box <?php echo ($department_id == 1 && $sub_department_id == 14) || ($department_id == 3 && $sub_department_id == 3) ? 'active' : 'inactive'; ?>"
                onclick="fetchNotes(3, 3)">DPD (Admin)</div>
        </div>

        <div class="line"></div>

        <div class="container">
            <!-- DPD Finance, Asset, Procurement, etc. -->
            <div class="box <?php echo ($department_id == 1 && $sub_department_id == 14) || ($department_id == 3 && $sub_department_id == 7) ? 'active' : 'inactive'; ?>"
                onclick="fetchNotes(3, 7)">DPD (Finance)</div>
            <div class="box <?php echo ($department_id == 1 && $sub_department_id == 14) || ($department_id == 3 && $sub_department_id == 4) ? 'active' : 'inactive'; ?>"
                onclick="fetchNotes(3, 4)">DPD (Asset)</div>
            <div class="box <?php echo ($department_id == 1 && $sub_department_id == 14) || ($department_id == 3 && $sub_department_id == 9) ? 'active' : 'inactive'; ?>"
                onclick="fetchNotes(3, 9)">DPD (Security and Common Services)</div>
            <div class="box <?php echo ($department_id == 1 && $sub_department_id == 14) || ($department_id == 3 && $sub_department_id == 5) ? 'active' : 'inactive'; ?>"
                onclick="fetchNotes(3, 5)">DPD (Procurement)</div>
        </div>
    </div>

    <!-- Popup for Notes -->
    <div id="notesPopup" class="popup">
        <button class="popup-close" onclick="closePopup()">X</button>
        <h2>Record Data</h2>
        <div class="popup-content" id="notesContent"></div>
    </div>

    <script>
        function toggleSubMenu(id, element) {
            var submenu = document.getElementById(id);
            submenu.style.display = submenu.style.display === "flex" ? "none" : "flex";
            element.classList.toggle("active");
        }

        function fetchNotes(departmentId, subDepartmentId) {
            var button = event.target;
            if (button.classList.contains('inactive')) {
                return; // Prevent action if button is inactive
            }

            $.ajax({
                url: 'fetch_notes.php',
                method: 'GET',
                data: {
                    department_id: departmentId,
                    sub_department_id: subDepartmentId
                },
                success: function(response) {
                    $('#notesContent').html(response);
                    $('#notesPopup').fadeIn();
                }
            });
        }

        function closePopup() {
            $('#notesPopup').fadeOut();
        }
    </script>
</body>

</html>
