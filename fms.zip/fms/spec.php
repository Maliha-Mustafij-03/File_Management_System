<?php
session_start();
include_once('includes/config.php');

// Check if session variables are set, else set them to null to avoid errors
$role = $_SESSION['role'] ?? null; // Use null coalescing operator to prevent undefined index

$has_full_access = false;

// Check if the user is PD (Assuming PD role or specific department ID for PD)
if ($role === 'PD') {
    $has_full_access = true;
}

// Check if search term is provided
$searchTerm = isset($_GET['search']) ? $_GET['search'] : '';

// Search query (no department or sub-department restrictions, all data can be viewed)
$query = "SELECT * FROM tblnotes WHERE (noteTitle LIKE ? OR noteCategory LIKE ? OR noteDescription LIKE ?)";
$stmt = $con->prepare($query);

// Add wildcards to search term for partial matching
$searchTermWildcard = '%' . $searchTerm . '%';
$stmt->bind_param("sss", $searchTermWildcard, $searchTermWildcard, $searchTermWildcard);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>ই-ডাটা</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>

    <style>
        /* Colorful Styling */
        body {
            background-color: #f0f8ff;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .breadcrumb-item a {
            color: #007bff;
        }
        .breadcrumb-item.active {
            color: #ff6347;
        }
        .card-header {
            background: linear-gradient(90deg, #00c6ff 0%, #0072ff 100%);
            color: white;
            font-size: 20px;
            font-weight: bold;
            border-radius: 10px 10px 0 0;
        }
        .card-body {
            background-color: #f7f7f7;
            padding: 2rem;
            border-radius: 0 0 10px 10px;
        }
        .btn-primary {
            background: linear-gradient(90deg, #56ccf2 0%, #2f80ed 100%);
            border-color: #2f80ed;
            font-weight: bold;
        }
        .btn-primary:hover {
            background: linear-gradient(90deg, #00b4d8 0%, #2f80ed 100%);
            border-color: #1f69c1;
        }
        .btn-danger {
            background-color: #ff4d4d;
            border-color: #ff4d4d;
            font-weight: bold;
        }
        .btn-danger:hover {
            background-color: #ff1a1a;
            border-color: #ff1a1a;
        }
        .table th {
            background-color: #ffecb3;
            color: #333;
        }
        .table td {
            background-color: #ffffff;
            color: #333;
        }
        .modal-content {
            background: #f9f9f9;
            border-radius: 10px;
        }
        .modal-header {
            background-color: #2f80ed;
            color: white;
        }
        .modal-footer button {
            border-radius: 5px;
        }
    </style>
</head>
<body class="sb-nav-fixed">
    <?php include_once('includes/header.php'); ?>
    <div id="layoutSidenav">
        <?php include_once('includes/leftbar.php'); ?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">অনুসন্ধান ফলাফল</h1>
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item"><a href="index.html">ড্যাশবোর্ড</a></li>
                        <li class="breadcrumb-item active">অনুসন্ধান ফলাফল</li>
                    </ol>
                    <div class="card mb-4">
                        <div class="card-header">
                            <i class="fas fa-table me-1"></i>
                            অনুসন্ধান ফলাফল
                        </div>
                        <div class="card-body">
                            <?php 
                            if (isset($result) && $result->num_rows > 0) {
                                ?>
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>স্মারক নং</th>
                                            <th>ফাইলের নাম</th>
                                            <th>বিষয়</th>
                                            <th>তারিখ</th>
                                            <th>ফাইল</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php while ($row = $result->fetch_assoc()) { ?>
                                        <tr>
                                            <td><?php echo htmlentities($row['noteTitle']); ?></td>
                                            <td><?php echo htmlentities($row['noteCategory']); ?></td>
                                            <td><?php echo htmlentities($row['noteDescription']); ?></td>
                                            <td><?php echo htmlentities($row['date']); ?></td>
                                            <td>
                                                <?php 
                                                $filePath = htmlentities($row['filePath']);
                                                if (!empty($filePath)) {
                                                    echo '<a href="' . $filePath . '" target="_blank">ফাইল দেখুন</a>';
                                                } else {
                                                    echo 'কোন ফাইল যুক্ত করা হয়নি';
                                                }
                                                ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                    </tbody>
                                </table>
                            <?php 
                            } else {
                                echo "<p>কোনো ফলাফল পাওয়া যায়নি।</p>";
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </main>
            <?php include_once('includes/footer.php'); ?>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
</body>
</html>
