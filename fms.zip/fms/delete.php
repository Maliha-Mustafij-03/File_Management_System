<?php
include_once('includes/config.php');

// Make sure the note ID is passed
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $note_id = $_GET['id'];

    // Prepare the DELETE statement for tblnotes
    $deleteQuery = "DELETE FROM tblnotes WHERE id = ?";
    $stmt = mysqli_prepare($con, $deleteQuery);

    if ($stmt) {
        // Bind the note_id to the prepared statement
        mysqli_stmt_bind_param($stmt, "i", $note_id);

        // Execute the DELETE query
        if (mysqli_stmt_execute($stmt)) {
            // Optionally, delete related history from tblnoteshistory
            $deleteHistoryQuery = "DELETE FROM tblnoteshistory WHERE noteId = ?";
            $stmtHistory = mysqli_prepare($con, $deleteHistoryQuery);

            if ($stmtHistory) {
                // Bind the note_id to the history query
                mysqli_stmt_bind_param($stmtHistory, "i", $note_id);

                // Execute the DELETE query for history
                mysqli_stmt_execute($stmtHistory);
                mysqli_stmt_close($stmtHistory);
            }

            // Redirect with success message
            echo "<script>alert('Note deleted successfully!');</script>";
            echo "<script>window.location.href='manage-notes.php';</script>";
        } else {
            // Handle deletion failure
            echo "<script>alert('Failed to delete the note.');</script>";
            echo "<script>window.location.href='manage-notes.php';</script>";
        }

        // Close the prepared statement for the main note deletion
        mysqli_stmt_close($stmt);
    } else {
        // Handle query preparation error
        echo "<script>alert('Failed to prepare the deletion query.');</script>";
        echo "<script>window.location.href='manage-notes.php';</script>";
    }
} else {
    // Handle case where note ID is missing
    echo "<script>alert('Note ID is missing.');</script>";
    echo "<script>window.location.href='manage-notes.php';</script>";
}
?>
