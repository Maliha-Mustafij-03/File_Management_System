<?php
// Include database connection
include_once('includes/config.php'); 

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['searchdata'])) {
    $searchdata = mysqli_real_escape_string($con, $_POST['searchdata']); // Escape special characters

    // SQL query to search across multiple fields
    $query = "SELECT * FROM tblnotes WHERE 
              noteCategory LIKE ? OR 
              noteTitle LIKE ? OR 
              noteDescription LIKE ?";

    // Prepare the SQL query
    $stmt = $con->prepare($query);

    // Add wildcards to the search term for partial matching
    $searchTerm = "%" . $searchdata . "%";

    // Bind the parameters for the query (3 parameters: noteCategory, noteTitle, noteDescription)
    $stmt->bind_param("sss", $searchTerm, $searchTerm, $searchTerm);

    // Execute the query
    $stmt->execute();

    // Get the result
    $result = $stmt->get_result();

    // Check if any results are returned
    if ($result->num_rows > 0) {
        echo '<h2>Search Results for: ' . htmlspecialchars($searchdata) . '</h2>';
        echo '<table class="table table-striped">';
        echo '<thead>';
        echo '<tr><th>Title</th><th>Category</th><th>Description</th><th>Date</th><th>File</th></tr>';
        echo '</thead><tbody>';

        // Loop through each result and display it
        while ($row = $result->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . htmlspecialchars($row['noteTitle']) . '</td>';
            echo '<td>' . htmlspecialchars($row['noteCategory']) . '</td>';
            echo '<td>' . htmlspecialchars($row['noteDescription']) . '</td>';
            echo '<td>' . htmlspecialchars($row['date']) . '</td>';
            echo '<td><a href="' . htmlspecialchars($row['filePath']) . '" target="_blank">Download</a></td>';
            echo '</tr>';
        }

        echo '</tbody></table>';
    } else {
        // If no results found
        echo '<p>No results found for "' . htmlspecialchars($searchdata) . '"</p>';
    }

    // Close the prepared statement and the database connection
    $stmt->close();
    $con->close();
} else {
    // If the form was not submitted correctly
    echo '<p>Please enter a search term.</p>';
}
?>
