          <div id="layoutAuthentication_footer">
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">সত্ত্ব &copy; বাংলাদেশ নির্বাচন কমিশন,আইডিয়া-২ প্রকল্প
                          
                        </div>
                    </div>
                </footer>
            </div>