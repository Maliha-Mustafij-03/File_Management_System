<?php
session_start();
include_once('includes/config.php');

// Check if the user is logged in
if (strlen($_SESSION["edmsid"]) == 0) {
    header('location:logout.php');
    exit();
}

$message = "";
$alertType = "";

// Get the logged-in user's department and sub-department from tblregistration
$loggedInUserId = $_SESSION["edmsid"];
$userQuery = mysqli_query($con, "SELECT department_id, sub_department_id FROM tblregistration WHERE id = '$loggedInUserId'");
$user = mysqli_fetch_assoc($userQuery);
$department_id = $user['department_id'];
$sub_department_id = $user['sub_department_id'];

// Handling form submission
if (isset($_POST['submit'])) {
    $category = mysqli_real_escape_string($con, $_POST['category']);
    $ntitle = mysqli_real_escape_string($con, $_POST['notetitle']);
    $ndate = mysqli_real_escape_string($con, $_POST['date']);
    $ndescription = mysqli_real_escape_string($con, $_POST['notediscription']);
    $createdby = intval($_SESSION['edmsid']);
    
    // Fetch category name based on selected category ID
    $categoryQuery = mysqli_query($con, "SELECT categoryName FROM tblcategory WHERE id = '$category'");
    $categoryData = mysqli_fetch_assoc($categoryQuery);
    $noteCategory = $categoryData['categoryName']; // Get the category name

    // Handle file upload
    $filePath = "";
    if (isset($_FILES['fileupload']) && $_FILES['fileupload']['error'] == 0) {
        // Specify the directory where the file will be stored
        $targetDir = "uploads/";  // Folder where files will be uploaded
        $fileName = basename($_FILES["fileupload"]["name"]);
        $targetFilePath = $targetDir . $fileName;

        // Check if the file is a valid type (for example, image or document)
        $allowedTypes = ["image/jpeg", "image/png", "application/pdf"];
        if (in_array($_FILES['fileupload']['type'], $allowedTypes)) {
            // Upload the file to the server
            if (move_uploaded_file($_FILES['fileupload']['tmp_name'], $targetFilePath)) {
                $filePath = $targetFilePath;
            } else {
                $message = "Error uploading file.";
                $alertType = "danger";
            }
        } else {
            $message = "Invalid file type. Only JPG, PNG, and PDF are allowed.";
            $alertType = "danger";
        }
    }

    // Insert Data
    $sql = "INSERT INTO tblnotes (cat_id, noteCategory, noteTitle, date, noteDescription, createdBy, department_id, sub_department_id, filePath) 
            VALUES ('$category', '$noteCategory', '$ntitle', '$ndate', '$ndescription', '$createdby', '$department_id', '$sub_department_id', '$filePath')";

    if (mysqli_query($con, $sql)) {
        $message = "Data inserted successfully!";
        $alertType = "success";
    } else {
        $message = "Error inserting data: " . mysqli_error($con);
        $alertType = "danger";
    }
}
?>

<!DOCTYPE html>
<html lang="bn">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    

    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
   <title>ই-ডাটা | নতুন ডাটা</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
    <?php include_once('includes/header.php'); ?>

    <div id="layoutSidenav">
        <?php include_once('includes/leftbar.php'); ?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4 text-primary">নতুন ডাটা</h1>
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item"><a href="dashboard.php">হোমপেজ</a></li>
                        <li class="breadcrumb-item active">নতুন ডাটা</li>
                    </ol>

                    <div class="card">
                        <div class="card-header">
                            <h4>নোট সাবমিট করুন</h4>
                        </div>
                        <div class="card-body">
                            <?php if ($message): ?>
                                <div class="alert alert-<?= $alertType ?> alert-dismissible fade show" role="alert">
                                    <?= $message ?>
                                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                </div>
                            <?php endif; ?>

                            <form method="post" enctype="multipart/form-data">
                                <!-- Department and Sub-Department (Prefetched based on logged-in user) -->
                                <div class="d-flex mb-3">
                                    <div class="me-3">
                                        <label for="department_id" class="form-label">বিভাগ</label>
                                        <select class="form-select" name="department_id" id="department_id" disabled>
                                            <option value="<?= $department_id ?>"><?= getDepartmentName($department_id) ?></option>
                                        </select>
                                    </div>
                                    <div class="me-3">
                                        <label for="sub_department_id" class="form-label">উপ-বিভাগ</label>
                                        <select class="form-select" name="sub_department_id" id="sub_department_id" disabled>
                                            <option value="<?= $sub_department_id ?>"><?= getSubDepartmentName($sub_department_id) ?></option>
                                        </select>
                                    </div>
                                </div>

                                <!-- Category Dropdown (Dynamic based on department and sub-department) -->
                                <div class="mb-3">
                                    <label for="category" class="form-label">ক্যাটেগরি</label>
                                    <select class="form-select" name="category" id="category" required>
                                        <option value="">ক্যাটেগরি নির্বাচন করুন</option>
                                    </select>
                                </div>

                                <!-- Other fields -->
                                <div class="mb-3">
                                    <label for="notetitle" class="form-label">নোট শিরোনাম</label>
                                    <input type="text" class="form-control" name="notetitle" id="notetitle" required>
                                </div>
                                <div class="mb-3">
                                    <label for="date" class="form-label">তারিখ</label>
                                    <input type="date" class="form-control" name="date" id="date" required>
                                </div>
                                <div class="mb-3">
                                    <label for="notediscription" class="form-label">বিবরণ</label>
                                    <textarea class="form-control" name="notediscription" id="notediscription" rows="3" required></textarea>
                                </div>

                                <!-- File Upload -->
                                <div class="mb-3">
                                    <label for="fileupload" class="form-label">ফাইল আপলোড করুন</label>
                                    <input type="file" class="form-control" name="fileupload" id="fileupload">
                                </div>

                                <button type="submit" name="submit" class="btn btn-primary w-100">সাবমিট</button>
                            </form>
                        </div>
                    </div>
                </div>
            </main>
            <?php include_once('includes/footer.php'); ?>
        </div>
    </div>

    <script>
        // Fetch categories dynamically based on department and sub-department
        document.addEventListener('DOMContentLoaded', function () {
            var deptId = document.getElementById('department_id').value;
            var subDeptId = document.getElementById('sub_department_id').value;
            fetchCategories(deptId, subDeptId);
        });

        function fetchCategories(deptId, subDeptId) {
            if (!deptId || !subDeptId) {
                return; // Don't fetch if either department or sub-department is not selected
            }

            // Fetch categories from the database based on department and sub-department
            var xhr = new XMLHttpRequest();
            xhr.open('GET', 'get_categories.php?dept_id=' + deptId + '&sub_dept_id=' + subDeptId, true);
            xhr.onload = function () {
                if (xhr.status === 200) {
                    var categories = JSON.parse(xhr.responseText);
                    var categorySelect = document.getElementById('category');
                    categorySelect.innerHTML = '<option value="">ক্যাটেগরি নির্বাচন করুন</option>';

                    // Populate the category dropdown
                    categories.forEach(function (category) {
                        var option = document.createElement('option');
                        option.value = category.id;
                        option.textContent = category.categoryName;
                        categorySelect.appendChild(option);
                    });
                }
            };
            xhr.send();
        }
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>

<?php
// Helper functions to fetch department and sub-department names
function getDepartmentName($id) {
    global $con;
    $query = "SELECT name FROM departments WHERE id = '$id'";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_assoc($result);
    return $row['name'];
}

function getSubDepartmentName($id) {
    global $con;
    $query = "SELECT name FROM sub_departments WHERE id = '$id'";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_assoc($result);
    return $row['name'];
}
?>
