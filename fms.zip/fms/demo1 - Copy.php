<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>প্রকল্পের অর্গানোগ্রাম</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: #ffffff;
        }
        .chart {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-top: 20px;
        }
        .box, .sub-box {
            background-color: #2d572c;
            color: white;
            padding: 15px;
            border-radius: 5px;
            margin: 10px;
            width: 300px;
            text-align: center;
            font-weight: bold;
            cursor: pointer;
            border: 2px solid white;
        }
        .sub-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            display: none;
        }
        .box.active, .sub-box.active {
            background-color: rgb(30, 145, 30);
        }
    </style>
</head>
<body>
    <div class="chart">
        <div class="box" onclick="toggleSubMenu('director', this)">
            <a href="manage-notes.php" class="link-box">PD</a>
        </div>
        <div id="director" class="sub-container">
            <div class="sub-box" onclick="toggleSubMenu('admin_finance', this)">APD(Admin)</div>
            <div class="sub-box" onclick="toggleSubMenu('operations', this)">APD(Ops)</div>
        </div>
    </div>

    <div id="admin_finance" class="sub-container">
        <div class="sub-box" onclick="fetchFiles(8, 1)">DPD(Evaluation and Monitoring)</div>
        <div class="sub-box" onclick="fetchFiles(3, 3)">DPD(Admin)</div>
        <div class="sub-box" onclick="fetchFiles(7, 3)">DPD(Finance)</div>
        <div class="sub-box" onclick="fetchFiles(4, 3)">DPD(Asset)</div>
    </div>

    <div id="operations" class="sub-container">
        <div class="sub-box" onclick="fetchFiles(5, 3)">DPD(Procurement)</div>
        <div class="sub-box" onclick="fetchFiles(1, 2)">DPD(Personalization)</div>
        <div class="sub-box" onclick="fetchFiles(2, 2)">DPD(DBA)</div>
        <div class="sub-box" onclick="fetchFiles(10, 2)">DPD(ICT)</div>
        <div class="sub-box" onclick="fetchFiles(11, 2)">DPD(Software Management)</div>
    </div>

    <script>
        function toggleSubMenu(id, element) {
            var submenu = document.getElementById(id);
            if (submenu.style.display === "none" || submenu.style.display === "") {
                submenu.style.display = "flex";
                element.classList.add("active");
            } else {
                submenu.style.display = "none";
                element.classList.remove("active");
            }
        }

        function fetchFiles(departmentId, subDepartmentId) {
            $.ajax({
                url: 'fetch_notes.php',
                method: 'GET',
                data: { department_id: departmentId, sub_department_id: subDepartmentId },
                success: function(response) {
                    alert('Fetched files for department: ' + departmentId + ' and sub-department: ' + subDepartmentId);
                }
            });
        }
    </script>
</body>
</html>
