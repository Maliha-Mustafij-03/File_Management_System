<?php
session_start();
include_once('includes/config.php');

if(strlen($_SESSION["department_id"])==0 || strlen($_SESSION["sub_department_id"])==0) {
    header('location:logout.php');
} else {
    // For deleting    
    if ($_GET['del']) {
        $catid = $_GET['id'];
        $userid = $_SESSION["edmsid"];
        mysqli_query($con, "DELETE FROM tblcategory WHERE id='$catid' AND createdBy='$userid'");
        echo "<script>window.location.href='manage-categories.php'</script>";
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>ই-ডাটা</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
</head>

<body class="sb-nav-fixed">
    <?php include_once('includes/header.php'); ?>

    <div id="layoutSidenav">
        <?php include_once('includes/leftbar.php'); ?>

        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4" style="font-size: 32px; font-weight: 700;">নতুন ফাইলের নাম সংযোজন</h1>
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item"><a href="index.html">হোম পেজ</a></li>
                        <li class="breadcrumb-item active">নতুন ফাইলের নাম সংযোজন</li>
                    </ol>

                    <div class="card mb-4">
                        <div class="card-header">
                            <i class="fas fa-table me-1"></i>
                            ফাইলের নামসমূহ
                        </div>
                        <div class="card-body">
                            <table id="datatablesSimple">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>ফাইলের নাম</th>
                                        <th>ফাইল তৈরী করার তারিখ</th>
                                        <th>কাজ</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    // Get the department and sub-department for the user
                                    $userid = $_SESSION["edmsid"];
                                    $department_id = $_SESSION["department_id"];
                                    $sub_department_id = $_SESSION["sub_department_id"];

                                    // Fetch department name
                                    $query_dept = mysqli_query($con, "SELECT name FROM departments WHERE id='$department_id'");
                                    $dept_row = mysqli_fetch_array($query_dept);
                                    $department_name = $dept_row['name'];

                                    // Fetch sub-department name
                                    $query_sub_dept = mysqli_query($con, "SELECT name FROM sub_departments WHERE id='$sub_department_id'");
                                    $sub_dept_row = mysqli_fetch_array($query_sub_dept);
                                    $sub_department_name = $sub_dept_row['name'];

                                    // Query to get categories for the user, department, and sub-department
                                    $query = mysqli_query($con, "SELECT id, categoryName, creationDate FROM tblcategory WHERE createdBy='$userid' AND department_id='$department_id' AND sub_department_id='$sub_department_id'");
                                    $cnt = 1;
                                    while ($row = mysqli_fetch_array($query)) {
                                    ?>
                                        <tr>
                                            <td><?php echo htmlentities($cnt); ?></td>
                                            <td><?php echo htmlentities($row['categoryName']); ?> (<?php echo $department_name; ?> - <?php echo $sub_department_name; ?>)</td>
                                            <td><?php echo htmlentities($row['creationDate']); ?></td>
                                            <td>
                                                <div class="action-icons">
                                                    <a href="edit-category.php?id=<?php echo $row['id']; ?>"><i class="fas fa-edit"></i></a>
                                                    <a href="manage-categories.php?id=<?php echo $row['id']; ?>&del=delete" onClick="return confirm('আপনি কি ডাটা মুছে ফেলতে চান?')"><i class="fa fa-trash" aria-hidden="true"></i></a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php $cnt = $cnt + 1; } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
            <?php include_once('includes/footer.php'); ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
    <script src="js/datatables-simple-demo.js"></script>
</body>

</html>

<?php } ?>
