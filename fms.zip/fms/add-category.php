<?php
session_start();
include_once('includes/config.php');

// Check if session exists for edmsid
if (!isset($_SESSION["edmsid"]) || strlen($_SESSION["edmsid"]) == 0) {
    header('location:logout.php');
    exit();
}

$createdby = $_SESSION["edmsid"];
$loggedInDept = isset($_SESSION["department_id"]) ? $_SESSION["department_id"] : '';
$loggedInSubDept = isset($_SESSION["sub_department_id"]) ? $_SESSION["sub_department_id"] : '';

if (isset($_POST['submit'])) {
    $category = isset($_POST['category']) ? mysqli_real_escape_string($con, $_POST['category']) : '';
    $department = !empty($loggedInDept) ? $loggedInDept : (isset($_POST['department']) ? mysqli_real_escape_string($con, $_POST['department']) : '');
    $sub_category = !empty($loggedInSubDept) ? $loggedInSubDept : (isset($_POST['sub_department_id']) ? mysqli_real_escape_string($con, $_POST['sub_department_id']) : '');

    if (empty($sub_category)) {
        echo "<script>alert('অনুগ্রহ করে একটি সাব-ভাগ নির্বাচন করুন।');</script>";
    } else {
        // Check if sub_category exists
        $check_sub_category_query = mysqli_query($con, "SELECT id FROM sub_departments WHERE id = '$sub_category'");

        if (mysqli_num_rows($check_sub_category_query) > 0) {
            // Insert into tblcategory
            $sql = "INSERT INTO tblcategory (categoryName, sub_department_id, department_id, createdBy) 
                    VALUES ('$category', '$sub_category', '$department', '$createdby')";

            if (mysqli_query($con, $sql)) {
                echo "<script>alert('ফাইলের নাম সফলতার সাথে যোগ হয়েছে');</script>";
                echo "<script>window.location.href='manage-categories.php'</script>";
            } else {
                echo "<script>alert('ডাটা সংরক্ষণে ত্রুটি হয়েছে: " . mysqli_error($con) . "');</script>";
            }
        } else {
            echo "<script>alert('Invalid Sub-Category selected. Please try again.');</script>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
     <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>ই-ডাটা</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
    <?php include_once('includes/header.php'); ?>
    <div id="layoutSidenav">
        <?php include_once('includes/leftbar.php'); ?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid">
                    <h1 class="mt-4">ফাইলের নাম সংযোজন করুন</h1>
                    <div class="card">
                        <div class="card-header">ফাইলের নাম সংযোজন</div>
                        <div class="card-body">
                            <form method="post">
                                <!-- Department Selection -->
                                <div class="row mb-3">
                                    <div class="col-2">বিভাগ</div>
                                    <div class="col-4">
                                        <select name="department" id="department" class="form-control" required <?php echo (!empty($loggedInDept)) ? 'disabled' : ''; ?>>

                                            <option value="">Select Department</option>
                                            <?php
                                            $dept_query = mysqli_query($con, "SELECT * FROM departments");
                                            while ($row = mysqli_fetch_array($dept_query)) {
                                                $selected = ($row['id'] == $loggedInDept) ? 'selected' : '';
                                                echo "<option value='" . $row['id'] . "' $selected>" . $row['name'] . "</option>";
                                            }
                                            ?>
                                        </select>
                                        <?php

                                        if (!empty($loggedInDept)) {
                                            echo "<input type='hidden' name='department' value='$loggedInDept'>";
                                        }


                                        ?>
                                    </div>
                                </div>

                                <!-- Sub-Department Selection -->
                                <div class="row mb-3">
                                    <div class="col-2">সাব-ভাগ</div>
                                    <div class="col-4">
                                        <select name="sub_department_id" id="sub-department" class="form-control" required <?php echo (!empty($loggedInSubDept)) ? 'disabled' : ''; ?>>

                                            <option value="">Select Sub-Department</option>
                                            <?php
                                            if (!empty($loggedInDept)) {
                                                $subDeptQuery = mysqli_query($con, "SELECT * FROM sub_departments WHERE department_id = '$loggedInDept'");
                                                while ($row = mysqli_fetch_array($subDeptQuery)) {
                                                    $selected = ($row['id'] == $loggedInSubDept) ? 'selected' : '';
                                                    echo "<option value='" . $row['id'] . "' $selected>" . $row['name'] . "</option>";
                                                }
                                            }
                                            ?>
                                        </select>
                                        <?php
                                        if (!empty($loggedInSubDept)) {
                                            echo "<input type='hidden' name='sub_department_id' value='$loggedInSubDept'>";
                                        }
                                        ?>

                                    </div>
                                </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
                                <!-- Category Name Input -->
                                <div class="row mb-3">
                                    <div class="col-2">ফাইলের নাম</div>
                                    <div class="col-4">
                                        <input type="text" name="category" class="form-control" placeholder="ফাইলের নাম দিন" required>
                                    </div>
                                </div>

                                <!-- Submit Button -->
                                <div class="row">
                                    <div class="col-2">
                                        <button type="submit" name="submit" class="btn">জমা দিন</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- AJAX for Dynamic Sub-Department Loading -->
    <script>
        $(document).ready(function() {
            $('#department').change(function() {
                var departmentId = $(this).val();
                var subDeptDropdown = $('#sub-department');
                subDeptDropdown.prop('disabled', true);
                subDeptDropdown.empty();
                subDeptDropdown.append('<option value="">Select Sub-Department</option>');

                if (departmentId) {
                    $.ajax({
                        url: 'get_sub_departments.php',
                        type: 'GET',
                        data: {
                            department_id: departmentId
                        },
                        success: function(response) {
                            if (response) {
                                subDeptDropdown.prop('disabled', false);
                                subDeptDropdown.append(response);
                            }
                        }
                    });
                }
            });
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>