<?php session_start();
include_once('includes/config.php');
if(isset($_POST['login'])) {
    $emailcon=$_POST['logindetail'];
    $password=md5($_POST['userpassword']);
    $query=mysqli_query($con,"SELECT mobileNumber,emailId,id,department_id,sub_department_id FROM tblregistration WHERE (emailId='$emailcon' || mobileNumber='$emailcon') && userPassword='$password' ");
    $ret=mysqli_fetch_array($query);
    if($ret>0) {
        $_SESSION['edmsid']=$ret['id'];
        $_SESSION['uemail']=$ret['emailId'];
        $_SESSION['department_id']=$ret['department_id']; // Store department_id
        $_SESSION['sub_department_id']=$ret['sub_department_id']; // Store sub-department_id
        echo "<script>window.location.href='dashboard.php'</script>";
    }
    else{
        echo "<script>alert('Invalid details');</script>";
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>রেকর্ড সংগ্রহ</title>
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">

    <style>
        /* Global Styles */
        body {
            background: url('assets/img/banner.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;  /* Increased max-width to make the card bigger */
            margin-top: 50px;
            z-index: 1;
        }

        /* Card Styling */
        .card {
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 4px 25px rgba(0, 0, 0, 0.1);
            padding: 40px; /* Increased padding */
            background-color: rgba(255, 255, 255, 0.9); /* White background with transparency */
        }

        .card-header {
            background-color: #28a745;
            color: white;
            padding: 30px;
            text-align: center;
            font-size: 30px; /* Increased font size */
        }

        .card-body {
            padding: 40px; /* Increased padding */
            background-color: #f9f9f9;
        }

        .card-footer {
            background-color: #f1f1f1;
            text-align: center;
            padding: 20px;
        }

        .form-floating input, .form-floating label {
            border-radius: 8px;
            padding: 15px; /* Increased padding */
        }

        .form-floating input {
            border: 1px solid #ccc;
            font-size: 18px; /* Increased font size */
        }

        .form-floating input:focus {
            border-color: #28a745;
            box-shadow: 0 0 8px rgba(40, 167, 69, 0.5);
        }

        .btn-primary {
            background-color: #28a745;
            border: none;
            padding: 15px 25px; /* Increased padding */
            font-size: 18px; /* Increased font size */
            border-radius: 8px;
            width: 100%;
        }

        .btn-primary:hover {
            background-color: #218838;
        }

        .small {
            font-size: 16px; /* Increased font size */
        }

        .small a {
            color: #28a745;
            text-decoration: none;
        }

        .small a:hover {
            text-decoration: underline;
        }

        .footer-link {
            text-align: center;
            padding: 10px;
            font-size: 14px;
        }
    </style>
</head>

<body>
    <div id="layoutAuthentication">
        <div id="layoutAuthentication_content">
            <main>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-8">  <!-- Increased the width of the column -->
                            <div class="card shadow-lg border-0 rounded-lg mt-5">
                                <div class="card-header">
                                    <h3 class="font-weight-light my-4">ডিজিটাল ফাইল ম্যানেজমেন্ট সিস্টেম</h3>
                                    <p class="font-weight-light">ইউজার লগ ইন</p>
                                </div>
                                <div class="card-body">
                                    <form method="post">
                                        <div class="form-floating mb-3">
                                            <input class="form-control" id="inputEmail" type="text" name="logindetail" placeholder="নিবন্ধনকৃত ই-মেইল আইডি/মোবাইল নাম্বার" required />
                                            <label for="inputEmail">ই-মেইল অ্যাড্রেস/মোবাইল নাম্বার</label>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <input class="form-control" id="inputPassword" type="password" placeholder="পাসওয়ার্ড" name="userpassword" required />
                                            <label for="inputPassword">পাসওয়ার্ড</label>
                                        </div>

                                        <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
                                            <a class="small" href="password-recovery.php">পাসওয়ার্ড ভুলে গেছেন?</a>
                                            <button class="btn btn-primary" type="submit" name="login">লগ ইন</button>
                                        </div>
                                    </form>
                                </div>
                                <div class="card-footer text-center py-3">
                                    <div class="small"><a href="registration.php">নতুন অ্যাকাউন্ট প্রয়োজন? নিবন্ধন করুন</a></div>
                                    <hr />
                                    <div class="small"><a href="index.php">হোমপেইজে ফেরত যান</a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
        <?php include_once('includes/footer.php'); ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
</body>

</html>
