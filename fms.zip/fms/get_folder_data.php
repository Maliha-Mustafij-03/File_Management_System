<?php
include_once('includes/config.php');

$category = $_GET['category'];
$dateFilter = $_GET['dateFilter'];

// Date filter logic
$condition = "";
if ($dateFilter == 'today') {
    $condition = "AND DATE(creationDate) = CURDATE()";
} elseif ($dateFilter == 'last7days') {
    $condition = "AND creationDate >= CURDATE() - INTERVAL 7 DAY";
} elseif ($dateFilter == 'next7days') {
    $condition = "AND creationDate <= CURDATE() + INTERVAL 7 DAY";
}

$query = mysqli_query($con, "SELECT * FROM tblnotes WHERE noteCategory = '$category' $condition");
if (mysqli_num_rows($query) > 0) {
    while($row = mysqli_fetch_array($query)) {
        echo "<tr>";
        echo "<td>" . htmlentities($row['id']) . "</td>";
        echo "<td>" . htmlentities($row['noteTitle']) . "</td>";
        echo "<td>" . htmlentities($row['noteCategory']) . "</td>";
        echo "<td>" . htmlentities($row['creationDate']) . "</td>";
        echo "<td>" . htmlentities($row['noteDescription']) . "</td>";
        echo "<td>" . htmlentities($row['createdBy']) . "</td>";
        echo "<td><a href='delete.php?id=" . $row['id'] . "'>Delete</a></td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='7'>No data found for the selected filter.</td></tr>";
}
?>
