<?php
if (isset($_GET['file'])) {
    $file = $_GET['file'];

    // Ensure the file exists
    $filePath = __DIR__ . '/../uploads/' . $file;
    if (file_exists($filePath)) {
        // Set headers to force download
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($file) . '"');
        header('Content-Length: ' . filesize($filePath));

        // Read and output the file
        readfile($filePath);
        exit();
    } else {
        echo "File not found.";
    }
} else {
    echo "No file specified.";
}
?>
