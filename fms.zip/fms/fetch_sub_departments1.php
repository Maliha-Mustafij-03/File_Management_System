<?php
include_once('includes/config.php');

if (isset($_GET['department_id'])) {
    $departmentId = $_GET['department_id'];

    // Fetch sub-departments based on department_id
    $query = "SELECT * FROM sub_departments WHERE department_id = '$departmentId'";
    $result = mysqli_query($con, $query);

    // Check if there are sub-departments
    if (mysqli_num_rows($result) > 0) {
        echo '<option value="">-- Select Sub-department --</option>';
        while ($row = mysqli_fetch_assoc($result)) {
            echo '<option value="' . $row['id'] . '">' . $row['name'] . '</option>';
        }
    } else {
        echo '<option value="">No sub-departments available</option>';
    }
} else {
    echo '<option value="">-- Select Sub-department --</option>';
}
?>
