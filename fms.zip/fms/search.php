<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dropdown Filter</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    /* General Styles */
    <style>
        body {
            background-color: #f4f6f9;
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
        }

        /* Filter Container */
        .filter-container {
            max-width: 700px;
            margin: 60px auto;
            background: #ffffff;
            padding: 45px;
            border-radius: 16px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.12);
            transition: transform 0.3s ease-in-out;
        }

        .filter-container:hover {
            transform: translateY(-3px);
        }

        /* Heading */
        h1 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 35px;
            font-size: 2.2rem;
            font-weight: 700;
        }

        /* Form Elements */
        .form-label {
            font-weight: 600;
            color: #495057;
            font-size: 1.1rem;
            margin-bottom: 8px;
        }

        select {
            width: 100%;
            height: 50px;
            font-size: 1rem;
            border-radius: 8px;
            border: 1px solid #ced4da;
            padding: 10px;
            background: #fff;
            transition: all 0.3s ease-in-out;
        }

        select:focus {
            border-color: #007bff;
            outline: none;
            box-shadow: 0 0 8px rgba(0, 123, 255, 0.2);
        }

        /* Button */
        .btn1 {
            width: 100px;
            height: 40px;
            font-size: 0.9rem;
            font-weight: 600;
            color: #ffffff;
            background: #007bff;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background 0.3s ease-in-out, transform 0.2s ease-in-out;
        }

        .btn1:hover {
            background: #0056b3;
            transform: scale(1.05);
        }

        .btn1:active {
            background: #004085;
            transform: scale(0.98);
        }

        /* Results Section */
        #results {
            margin-top: 30px;
            font-size: 1.1rem;
            padding: 20px;
            border: 1px solid #e0e0e0;
            border-radius: 10px;
            background: #f8f9fa;
            text-align: center;
        }

        /* Responsive Styles */
        @media (max-width: 768px) {
            .filter-container {
                max-width: 90%;
                padding: 35px;
            }

            h1 {
                font-size: 2rem;
            }

            select,
            .btn1 {
                height: 45px;
                font-size: 1rem;
            }

            .form-label {
                font-size: 1rem;
            }
        }
    </style>
</head>

<body>
    <div class="filter-container">
        <h1>Search Filter</h1>
        <form id="search-form">
            <!-- Row for department and sub-department -->
            <div class="row mb-4">
                <div class="col-md-6">
                    <label for="department" class="form-label">Department:</label>
                    <select id="department" name="department" class="form-select form-control-lg">
                        <option value="">Select Department</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label for="sub-department" class="form-label">Sub Department:</label>
                    <select id="sub-department" name="sub_department" class="form-select form-control-lg" disabled>
                        <option value="">Select Sub-Department</option>
                    </select>
                </div>
            </div>

            <!-- Row for the button -->
            <div class="row">
                <!-- <div class="col-12 d-grid">
                    <button type="button" id="filter-button" class="btn btn-primary">Filter</button>
                </div> -->
                <div class="d-flex justify-content-center mt-4">
                    <button type="button" id="filter-button" class="btn1 btn-primary">Filter</button>
                </div>
            </div>
        </form>

        <h2 class="mt-4">Results:</h2>
        <div id="results" class="alert alert-secondary" role="alert">
            No results to display.
        </div>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        $(document).ready(function() {
            // Static data for departments and sub-departments
            const departments = [{
                    id: "pd",
                    name: "PD",
                    sub_departments: [{
                            id: "dpd_monitoring",
                            name: "DPD (Monitoring & Evaluation)"
                        },
                        {
                            id: "dpd_communication",
                            name: "DPD (Communication)"
                        },
                    ]
                },
                {
                    id: "apd_ops",
                    name: "APD (Ops)",
                    sub_departments: [{
                            id: "dpd_personalization",
                            name: "DPD (Personalization)"
                        },
                        {
                            id: "dpd_database",
                            name: "DPD (Database Administration)"
                        },
                        {
                            id: "dpd_ict",
                            name: "DPD (ICT)"
                        },
                        {
                            id: "dpd_software",
                            name: "DPD (Software Management)"
                        }
                    ]
                },
                {
                    id: "apd_admin",
                    name: "APD (Admin & Finance)",
                    sub_departments: [{
                            id: "dpd_admin",
                            name: "DPD (Admin)"
                        },
                        {
                            id: "dpd_finance",
                            name: "DPD (Finance)"
                        },
                        {
                            id: "dpd_asset",
                            name: "DPD (Asset)"
                        },
                        {
                            id: "dpd_security",
                            name: "DPD (Security & Common Service)"
                        },
                        {
                            id: "dpd_procurement",
                            name: "DPD (Procurement)"
                        }
                    ]
                }
            ];

            // Populate departments dropdown
            let departmentDropdown = $('#department');
            departments.forEach(department => {
                departmentDropdown.append(new Option(department.name, department.id));
            });

            // Populate sub-departments based on selected department
            $('#department').change(function() {
                let departmentId = $(this).val();
                let subDepartmentDropdown = $('#sub-department');

                subDepartmentDropdown.html('<option value="">Select Sub-Department</option>').prop('disabled', true);

                if (departmentId) {
                    let selectedDepartment = departments.find(dept => dept.id === departmentId);
                    selectedDepartment.sub_departments.forEach(subDept => {
                        subDepartmentDropdown.append(new Option(subDept.name, subDept.id));
                    });
                    subDepartmentDropdown.prop('disabled', false);
                }
            });

            // Filter results
            $('#filter-button').click(function() {
                let departmentId = $('#department').val();
                let subDepartmentId = $('#sub-department').val();

                if (!departmentId) {
                    $('#results').html('Please select a department.').removeClass('alert-success alert-danger').addClass('alert-warning');
                    return;
                }

                if (!subDepartmentId) {
                    $('#results').html('Please select a sub-department.').removeClass('alert-success alert-danger').addClass('alert-warning');
                    return;
                }

                let selectedDepartment = departments.find(dept => dept.id === departmentId);
                let selectedSubDepartment = selectedDepartment.sub_departments.find(subDept => subDept.id === subDepartmentId);

                $('#results').html(
                    `You selected: <strong>${selectedDepartment.name}</strong> -> <strong>${selectedSubDepartment.name}</strong>`
                ).removeClass('alert-warning alert-danger').addClass('alert-success');
            });
        });
    </script>
</body>

</html>