<?php
session_start();
include_once('includes/config.php');

// Check if the user is logged in
if (strlen($_SESSION["edmsid"]) == 0) {
    header('location:logout.php');
} else {
    if (isset($_POST['submit'])) {
        // Capture form data
        $category = mysqli_real_escape_string($con, $_POST['category']);
        $sub_category = isset($_POST['sub_category']) ? mysqli_real_escape_string($con, $_POST['sub_category']) : '';
        $createdby = $_SESSION["edmsid"];

        // If sub-category is empty, use the session value
        if (empty($sub_category)) {
            $sub_category = $_SESSION['sub_department_id']; // Use session sub-department ID
        }

        // Validate sub-category
        $check_sub_category_query = mysqli_query($con, "SELECT id FROM sub_departments WHERE id = '$sub_category' AND department_id = '{$_SESSION['department_id']}'");
        if (mysqli_num_rows($check_sub_category_query) > 0) {
            // Insert data into the table
            $sql = mysqli_query($con, "INSERT INTO tblcategory (categoryName, sub_category_id, createdBy) VALUES ('$category', '$sub_category', '$createdby')");
            if ($sql) {
                echo "<script>alert('ফাইলের নাম সফলতার সাথে যোগ হয়েছে');</script>";
                echo "<script>window.location.href='manage-categories.php'</script>";
            } else {
                echo "<script>alert('ডাটা সংরক্ষণে ত্রুটি হয়েছে: " . mysqli_error($con) . "');</script>";
            }
        } else {
            echo "<script>alert('Invalid Sub-Category selected. Please try again.');</script>";
        }
    }
}

// Get the department and sub-department for the logged-in user
$department_id = $_SESSION['department_id'];
$sub_department_id = $_SESSION['sub_department_id'];

// Fetch department and sub-department data
$departments_query = mysqli_query($con, "SELECT d.id as department_id, d.name as department_name, sd.id as sub_department_id, sd.name as sub_department_name
    FROM departments d
    LEFT JOIN sub_departments sd ON d.id = sd.department_id
    WHERE d.id = '$department_id' ORDER BY d.name, sd.name");

$departments_data = [];
while ($row = mysqli_fetch_assoc($departments_query)) {
    $departments_data[$row['department_id']]['name'] = $row['department_name'];
    if (!empty($row['sub_department_id'])) {
        $departments_data[$row['department_id']]['sub_departments'][] = [
            'id' => $row['sub_department_id'],
            'name' => $row['sub_department_name']
        ];
    }
}
?>

<!DOCTYPE html>
<html lang="bn">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>ই-ডাটা</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
    <?php include_once('includes/header.php'); ?>
    <div id="layoutSidenav">
        <?php include_once('includes/leftbar.php'); ?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">ফাইলের নাম সংযোজন করুন</h1>
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item"><a href="index.html">ড্যাশবোর্ড</a></li>
                        <li class="breadcrumb-item active">ফাইলের নাম সংযোজন করুন</li>
                    </ol>
                    <div class="card mb-4">
                        <div class="card-body">
                            <form method="post">
                                <!-- Department Field (Disabled) -->
                                <div class="row mb-3">
                                    <div class="col-2">বিভাগ</div>
                                    <div class="col-4">
                                        <select name="department" id="department" class="form-control" disabled>
                                            <option value="<?php echo $department_id; ?>"><?php echo htmlspecialchars($departments_data[$department_id]['name'] ?? 'Unknown Department'); ?></option>
                                        </select>
                                    </div>
                                </div>

                                <!-- Sub-Department Field (Disabled) -->
                                <div class="row mb-3">
                                    <div class="col-2">সাব-বিভাগ</div>
                                    <div class="col-4">
                                        <select name="sub_category" id="sub-department" class="form-control" disabled>
                                            <option value="">সাব-বিভাগ নির্বাচন করুন</option>
                                            <?php
                                            if (!empty($departments_data[$department_id]['sub_departments'])) {
                                                foreach ($departments_data[$department_id]['sub_departments'] as $subDept) {
                                                    $selected = ($sub_department_id == $subDept['id']) ? 'selected' : '';
                                                    echo "<option value='{$subDept['id']}' {$selected}>{$subDept['name']}</option>";
                                                }
                                            } else {
                                                echo "<option value='' disabled>কোনো সাব-বিভাগ নেই</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <!-- Category (File Name) Field -->
                                <div class="row mb-3">
                                    <div class="col-2">ফাইলের নাম</div>
                                    <div class="col-4">
                                        <input type="text" name="category" class="form-control" placeholder="ফাইলের নাম দিন" required>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-2">
                                        <button type="submit" name="submit" class="btn btn-primary">জমা দিন</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </main>
            <?php include_once('includes/footer.php'); ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
</body>

</html>
