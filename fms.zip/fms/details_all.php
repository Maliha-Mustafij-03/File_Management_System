<?php
// Start session and include configuration file
session_start();
error_reporting(0);
include_once('includes/config.php');

// Database connection setup
$conn = new mysqli('localhost', 'root', '', 'edmsdb');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all departments and sub-departments (no filtering by session)
$departments = [];
$query = "SELECT d.id AS department_id, d.name AS department_name, 
                 s.id AS sub_id, s.name AS sub_name 
          FROM departments d 
          LEFT JOIN sub_departments s ON d.id = s.department_id";
$result = $conn->query($query);

while ($row = $result->fetch_assoc()) {
    // Initialize department if not already set
    if (!isset($departments[$row['department_id']])) {
        $departments[$row['department_id']] = [
            'id' => $row['department_id'],
            'name' => $row['department_name'],
            'sub_departments' => []
        ];
    }

    // Add sub-department if available
    if (!empty($row['sub_id'])) {
        $departments[$row['department_id']]['sub_departments'][] = [
            'id' => $row['sub_id'],
            'name' => $row['sub_name']
        ];
    }
}

// Fetch all notes from the database (no department or sub-department condition)
$notes_query = "SELECT * FROM tblnotes";
$notes_result = $conn->query($notes_query);

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>ই-ডাটা | ড্যাশবোর্ড</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/fontawesome-free/css/all.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <style>
        body {
            background-color: #f4f5f7;
        }

        .org-tree {
            padding-left: 0;
            list-style-type: none;
        }

        .org-tree li {
            margin: 10px 0;
        }

        .org-tree button {
            background-color: #1f65ab;
            border: none;
            color: #fff;
            font-size: 1.2rem;
            text-align: left;
            width: 40%;
            padding: 12px 15px;
            border-radius: 8px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .org-tree button:hover {
            background-color: #f8c210;
            transform: scale(1.05);
            box-shadow: 0px 6px 10px rgba(0, 0, 0, 0.15);
        }

        .org-tree button:active {
            background-color: #ffffff;
            transform: scale(0.98);
            box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.1);
        }

        .sub-department {
            margin-left: 30px;
            display: none;
            background-color: #ffffff;
            padding-left: 10px;
            padding-top: 5px;
            border-radius: 5px;
        }

        .active-sub-department {
            display: block;
        }

        .card {
            background-color: #343a40;
            color: #fff;
            border-radius: 8px;
            box-shadow: 0px 6px 15px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background-color: #179338;
        }

        .card-body {
            background: linear-gradient(-45deg, #f9a8d4, #a1c4fd, #fbc2eb, #f6d9b7);
            background-size: 400% 400%;
            animation: gradientAnimation 10s ease infinite;
        }

        @keyframes gradientAnimation {
            0% {
                background-position: 0% 50%;
            }

            50% {
                background-position: 100% 50%;
            }

            100% {
                background-position: 0% 50%;
            }
        }

        .card a {
            color: #f8c210;
        }

        .card-footer a:hover {
            color: #fff;
        }

        .table-striped tbody tr:nth-child(odd) {
            background-color: #ffffff;
        }

        .table-striped tbody tr:nth-child(even) {
            background-color: #f4f5f7;
        }

        .table-striped th {
            background-color: #4bbf6b;
            color: #fff;
        }

        .table-striped td {
            color: #333;
        }

        .btn-primary {
            background-color: #179338;
            border-color: #179338;
        }

        .btn-primary:hover {
            background-color: #148f2e;
            border-color: #148f2e;
        }

        .btn-danger {
            background-color: #dc3545;
            border-color: #dc3545;
        }

        .btn-danger:hover {
            background-color: #c82333;
            border-color: #c82333;
        }
    </style>
</head>

<body class="sb-nav-fixed">
    <?php include_once('includes/header.php'); ?>
    <div id="layoutSidenav">
        <?php include_once('includes/leftbar.php'); ?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">ড্যাশবোর্ড</h1>
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item active">ড্যাশবোর্ড</li>
                    </ol>
                    <hr />

                    <!-- Organogram for departments and sub-departments -->
                    <div class="row">
                        <?php
                        // Get the department and sub-department data from session
                        $listedcategories = mysqli_num_rows($notes_result); // Get total count of notes
                        $totalnotes = mysqli_num_rows($notes_result); // Get total notes count
                        ?>

                        <div class="col-lg-6 col-xl-4 mb-4">
                            <div class="card bg-primary text-white h-100">
                                <div class="card-header">
                                    <i class="fas fa-file-alt"></i> ফাইলের নাম
                                </div>
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div class="me-3">
                                            <div class="text-white-75 small">সকল বিভাগের ফাইল সংখ্যা</div>
                                            <div class="text-lg fw-bold"><?php echo $listedcategories; ?></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-footer">
                                   <!--  <a href="category-manage.php">বিস্তারিত দেখুন</a> -->
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-6 col-xl-4 mb-4">
                            <div class="card bg-success text-white h-100">
                                <div class="card-header">
                                    <i class="fas fa-database"></i> সর্বমোট এন্ট্রি করা ডাটা
                                </div>
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div class="me-3">
                                            <div class="text-white-75 small">এন্ট্রি সংখ্যা</div>
                                            <div class="text-lg fw-bold"><?php echo $totalnotes; ?></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <a href="spec.php">বিস্তারিত দেখুন</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Notes table -->
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card mb-4">
                                <div class="card-header">
                                    <i class="fas fa-table me-1"></i> নোটস ডাটাবেজ
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-hover">
                                            <thead>
                                                <tr>
                                                    <th>ID</th>
                                                    <th>নোট শিরোনাম</th>
                                                    <th>বিভাগ</th>
                                                    <th>সাব-বিভাগ</th>
                                                    <th>তারিখ</th>
                                                    <th>নোট বর্ণনা</th>
                                                    <th>ফাইল পাথ</th>
                                                    <th>অ্যাকশন</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                // Display all notes without any session-based filtering
                                                while ($row = $notes_result->fetch_assoc()) {
                                                    $filePath = $row['filePath'];
                                                ?>
                                                    <tr>
                                                        <td><?php echo $row['id']; ?></td>
                                                        <td><?php echo $row['noteTitle']; ?></td>
                                                        <td><?php echo $row['department_id']; ?></td>
                                                        <td><?php echo $row['sub_department_id']; ?></td>
                                                        <td><?php echo $row['date']; ?></td>
                                                        <td><?php echo $row['noteDescription']; ?></td>
                                                        <td>
                                                            <?php if ($filePath) { ?>
                                                                <a href="<?php echo $filePath; ?>" target="_blank"><?php echo $filePath; ?></a>
                                                            <?php } else { ?>
                                                                No File
                                                            <?php } ?>
                                                        </td>
                                                        <td>
                                                            <a href="view-note-all.php?noteid=<?php echo $row['id'] ?>" class="btn btn-primary">বিস্তারিত</a>
                                                            <a href="edit-note-all.php?noteid=<?php echo $row['id'] ?>" class="btn btn-primary">এডিট</a>
                                                            <!-- <a href="delete-note.php?id=<?php echo $row['id']; ?>"
                                                                class="btn btn-danger"
                                                                onclick="return confirm('আপনি কি এই নোটটি মুছে ফেলতে চান?');">মুছে ফেলুন</a> -->
                                                        </td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </main>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
</body>

</html>
