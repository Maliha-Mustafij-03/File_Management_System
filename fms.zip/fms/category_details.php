<?php
// Start the session and include the database connection
session_start();

// Include your database connection file
include_once('includes/config.php');

// Check if session exists for user ID
if (!isset($_SESSION["edmsid"])) {
    // Redirect to login page if session does not exist
    header('Location: login.php');
    exit;
}

// Get the category from the URL
$category = isset($_GET['category']) ? $_GET['category'] : '';

// Fetch records based on the selected category
$userid = $_SESSION["edmsid"];
$categoryQuery = mysqli_query($con, "SELECT * FROM tblnotes WHERE createdBy='$userid' AND noteCategory='$category'");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Category Details</title>
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
</head>
<body class="sb-nav-fixed">
    <?php include_once('includes/header.php'); ?>
    <div id="layoutSidenav">
        <?php include_once('includes/leftbar.php'); ?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Category: <?php echo htmlentities($category); ?></h1>
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                        <li class="breadcrumb-item active"><?php echo htmlentities($category); ?> Details</li>
                    </ol>
                    <div class="card mb-4">
                        <div class="card-header">
                            <i class="fas fa-table me-1"></i> <?php echo htmlentities($category); ?> Details
                        </div>
                        <div class="card-body">
                            <?php if (mysqli_num_rows($categoryQuery) > 0) { ?>
                                <div class="folder-container">
                                    <?php while ($row = mysqli_fetch_array($categoryQuery)) { ?>
                                        <div class="folder-item">
                                            <div class="folder-icon">
                                                <i class="fas fa-file-alt"></i>
                                            </div>
                                            <div class="folder-name">
                                                <?php echo htmlentities($row['noteTitle']); ?>
                                            </div>
                                            <div class="folder-description">
                                                <?php echo htmlentities($row['noteDescription']); ?>
                                            </div>
                                        </div>
                                    <?php } ?>
                                </div>
                            <?php } else { ?>
                                <p>No records found in this category.</p>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </main>
            <?php include_once('includes/footer.php'); ?>
        </div>
    </div>
</body>
</html>
