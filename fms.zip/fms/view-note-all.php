<?php
session_start();
include_once('includes/config.php');
if(strlen($_SESSION["edmsid"])==0) {
    header('location:logout.php');
} else {

    // For updating the note history (remark)
    if(isset($_POST['submit'])) {
        $nid = $_GET['noteid'];
        $ndetails = $_POST['remark'];
        mysqli_query($con, "INSERT INTO tblnoteshistory(noteId, noteDetails) VALUES('$nid', '$ndetails')");
        echo "<script>alert('রেকর্ড সাফল্যের সাথে সংগৃহীত হয়েছে।');</script>";
        echo "<script>window.location.href='details_all.php'</script>";
    }

    // For deleting note history (remark)
    if($_GET['del']) {
        $nid = $_GET['nhid'];
        mysqli_query($con, "DELETE FROM tblnoteshistory WHERE id ='$nid'");
        echo "<script>alert('তথ্য মুছে গেছে।');</script>";
        echo "<script>window.location.href='details_all.php'</script>";
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>ই-ডাটা</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>

    <style>
        /* Colorful Styling */
        body {
            background-color: #f0f8ff;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .breadcrumb-item a {
            color: #007bff;
        }
        .breadcrumb-item.active {
            color: #ff6347;
        }
        .card-header {
            background: linear-gradient(90deg, #00c6ff 0%, #0072ff 100%);
            color: white;
            font-size: 20px;
            font-weight: bold;
            border-radius: 10px 10px 0 0;
        }
        .card-body {
            background-color: #f7f7f7;
            padding: 2rem;
            border-radius: 0 0 10px 10px;
        }
        .btn-primary {
            background: linear-gradient(90deg, #56ccf2 0%, #2f80ed 100%);
            border-color: #2f80ed;
            font-weight: bold;
        }
        .btn-primary:hover {
            background: linear-gradient(90deg, #00b4d8 0%, #2f80ed 100%);
            border-color: #1f69c1;
        }
        .btn-danger {
            background-color: #ff4d4d;
            border-color: #ff4d4d;
            font-weight: bold;
        }
        .btn-danger:hover {
            background-color: #ff1a1a;
            border-color: #ff1a1a;
        }
        .table th {
            background-color: #ffecb3;
            color: #333;
        }
        .table td {
            background-color: #ffffff;
            color: #333;
        }
        .modal-content {
            background: #f9f9f9;
            border-radius: 10px;
        }
        .modal-header {
            background-color: #2f80ed;
            color: white;
        }
        .modal-footer button {
            border-radius: 5px;
        }
    </style>
</head>
<body class="sb-nav-fixed">
    <?php include_once('includes/header.php'); ?>
    <div id="layoutSidenav">
        <?php include_once('includes/leftbar.php'); ?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">বিস্তারিত রেকর্ড</h1>
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item"><a href="index.html">ড্যাশবোর্ড</a></li>
                        <li class="breadcrumb-item active">বিস্তারিত রেকর্ড</li>
                    </ol>
                    <div class="card mb-4">
                        <div class="card-header">
                            <i class="fas fa-table me-1"></i>
                            বিস্তারিত রেকর্ড
                        </div>
                        <div class="card-body">
                            <table class="table table-bordered">
                                <tbody>
                                    <?php 
                                    $nid = $_GET['noteid'];
                                    $query = mysqli_query($con, "SELECT * FROM tblnotes WHERE id='$nid'");
                                    $cnt = 1;
                                    while($row = mysqli_fetch_array($query)) {
                                    ?>  
                                        <tr style="font-size:18px;">
                                            <th width="250">স্মারক নং</th>
                                            <td><?php echo htmlentities($row['noteTitle']);?></td>
                                        </tr>
                                        <tr>
                                            <th>ফাইলের নাম</th>
                                            <td><?php echo htmlentities($row['noteCategory']);?></td>
                                        </tr>
                                        <tr>
                                            <th>ফাইল</th>
                                            <td>
                                                <?php 
                                                    $filePath = htmlentities($row['filePath']);
                                                    if (!empty($filePath)) {
                                                        echo '<a href="'.$filePath.'" target="_blank">ফাইল দেখুন</a>';
                                                    } else {
                                                        echo 'কোন ফাইল যুক্ত করা হয়নি';
                                                    }
                                                ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>এন্ট্রি করার তারিখ</th>
                                            <td><?php echo htmlentities($row['creationDate']);?></td>
                                        </tr>
                                        <tr>
                                            <th>বিষয়</th>
                                            <td><?php echo htmlentities($row['noteDescription']);?></td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>

                            <table class="table table-bordered">
                                <tr>
                                    <th>নোট</th>
                                    <th width="200">তারিখ</th>
                                    <th></th>
                                </tr>
                                <?php 
                                $ret = mysqli_query($con, "SELECT * FROM tblnoteshistory WHERE noteId='$nid'");
                                while($row = mysqli_fetch_array($ret)) {
                                ?>
                                    <tr>
                                        <td><?php echo htmlentities($row['noteDetails']);?></td>
                                        <td><?php echo htmlentities($row['postingDate']);?></td>
                                        <td>
                                            <a href="view-note-all.php?nhid=<?php echo $row['id']?>&del=delete" onClick="return confirm('আপনি কি তথ্য মুছে ফেলতে চান?')" class="btn btn-danger">মুছুন</a>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </table>

                            <div align="center">
                                <button class="btn btn-primary" type="button" data-bs-toggle="modal" data-bs-target="#exampleModal">প্রয়োজনে নোট</button>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
            <?php include_once('includes/footer.php'); ?>
        </div>
    </div>

    <!-- Modal for remark -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <form method="post" name="takeaction">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">বিস্তারিত</h5>
                        <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p>
                            <textarea class="form-control" required name="remark" placeholder="নোট লিখুন" rows="5"></textarea>
                        </p>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">বন্ধ</button>
                        <button class="btn btn-primary" type="submit" name="submit">সংরক্ষন</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
</body>
</html>
<?php } ?>
