<?php
session_start();
include_once('includes/config.php');

if(strlen($_SESSION["edmsid"]) == 0) {
    header('location:logout.php');
    exit();
}

$message = "";
$alertType = "";

if(isset($_POST['submit'])) {
    $category = mysqli_real_escape_string($con, $_POST['category']);
    $ntitle = mysqli_real_escape_string($con, $_POST['notetitle']);
    $ndate = mysqli_real_escape_string($con, $_POST['date']);
    $ndescription = mysqli_real_escape_string($con, $_POST['notediscription']);
    $department_id = intval($_POST['department_id']);
    $sub_department_id = intval($_POST['sub_department_id']);
    $createdby = intval($_SESSION['edmsid']);

    $checkDept = mysqli_query($con, "SELECT id FROM departments WHERE id = '$department_id'");
    if(mysqli_num_rows($checkDept) == 0) {
        $message = "Error: Department does not exist.";
        $alertType = "danger";
    }

    $checkSubDept = mysqli_query($con, "SELECT id FROM sub_departments WHERE id = '$sub_department_id' AND department_id = '$department_id'");
    if(mysqli_num_rows($checkSubDept) == 0) {
        $message = "Error: Sub-department does not exist.";
        $alertType = "danger";
    }

    $filePath = "";
    if(isset($_FILES['fileupload']) && $_FILES['fileupload']['error'] == 0) {
        $fileTmpPath = $_FILES['fileupload']['tmp_name'];
        $fileName = basename($_FILES['fileupload']['name']);
        $uploadDirectory = 'uploads/';
        $newFilePath = $uploadDirectory . time() . '_' . $fileName;

        if(move_uploaded_file($fileTmpPath, $newFilePath)) {
            $filePath = $newFilePath;
        } else {
            $message = "Error: File upload failed.";
            $alertType = "danger";
        }
    }

    $sql = "INSERT INTO tblnotes (noteCategory, noteTitle, date, noteDescription, createdBy, filePath, department_id, sub_department_id) 
            VALUES ('$category', '$ntitle', '$ndate', '$ndescription', '$createdby', '$filePath', '$department_id', '$sub_department_id')";

    if(mysqli_query($con, $sql)) {
        $message = "Data inserted successfully!";
        $alertType = "success";
    } else {
        $message = "Error inserting data: " . mysqli_error($con);
        $alertType = "danger";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Note</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .container { max-width: 600px; margin-top: 50px; }
        .hidden { display: none; }
    </style>
</head>
<body>

<div class="container">
    <h2 class="text-center mb-4">Submit a Note</h2>

    <?php if($message): ?>
    <div class="alert alert-<?= $alertType ?> alert-dismissible fade show" role="alert">
        <?= $message ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data" class="p-4 border rounded shadow">
        <div class="mb-3">
            <label for="category" class="form-label">Category</label>
            <input type="text" class="form-control" name="category" id="category" required>
        </div>

        <div class="mb-3">
            <label for="notetitle" class="form-label">Note Title</label>
            <input type="text" class="form-control" name="notetitle" id="notetitle" required>
        </div>

        <div class="mb-3">
            <label for="date" class="form-label">Date</label>
            <input type="date" class="form-control" name="date" id="date" required>
        </div>

        <div class="mb-3">
            <label for="notediscription" class="form-label">Description</label>
            <textarea class="form-control" name="notediscription" id="notediscription" rows="3" required></textarea>
        </div>

        <div class="mb-3">
            <label for="department_id" class="form-label">Department</label>
            <select class="form-select" name="department_id" id="department_id" required>
                <option value="">Select Department</option>
                <?php
                $deptQuery = mysqli_query($con, "SELECT id, name FROM departments");
                while ($row = mysqli_fetch_assoc($deptQuery)) {
                    echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
                }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="sub_department_id" class="form-label">Sub-Department</label>
            <select class="form-select" name="sub_department_id" id="sub_department_id" required>
                <option value="">Select Sub-Department</option>
                <?php
                $subDeptQuery = mysqli_query($con, "SELECT id, name, department_id FROM sub_departments");
                while ($row = mysqli_fetch_assoc($subDeptQuery)) {
                    echo "<option value='" . $row['id'] . "' data-department-id='" . $row['department_id'] . "'>" . $row['name'] . "</option>";
                }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="fileupload" class="form-label">Upload File</label>
            <input type="file" class="form-control" name="fileupload" id="fileupload">
            <div class="mt-2">
                <img id="filePreview" class="img-fluid hidden" style="max-height: 150px;">
            </div>
        </div>

        <button type="submit" name="submit" class="btn btn-primary w-100">Submit</button>
    </form>
</div>

<script>
document.getElementById('department_id').addEventListener('change', function() {
    var deptId = this.value;
    var subDeptOptions = document.getElementById('sub_department_id').getElementsByTagName('option');
    for (var i = 0; i < subDeptOptions.length; i++) {
        var option = subDeptOptions[i];
        option.style.display = (option.getAttribute('data-department-id') === deptId || deptId === "") ? 'block' : 'none';
    }
});

document.getElementById('fileupload').addEventListener('change', function(event) {
    var file = event.target.files[0];
    if(file) {
        var reader = new FileReader();
        reader.onload = function(e) {
            var preview = document.getElementById('filePreview');
            preview.src = e.target.result;
            preview.classList.remove('hidden');
        };
        reader.readAsDataURL(file);
    }
});
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
